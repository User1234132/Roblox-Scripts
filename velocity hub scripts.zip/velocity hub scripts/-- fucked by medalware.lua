-- fucked by medalware
-- shitty flick script
local players = game:GetService("Players")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local teleportService = game:GetService("TeleportService")
local coreGui = game:GetService("CoreGui")
local currentCamera = workspace.CurrentCamera
local localPlayer = players.LocalPlayer

local velocityHUBWindow = loadstring(game:HttpGet("https://sirius.menu/rayfield"))():CreateWindow({
  Name = "Velocity HUB",
  LoadingTitle = "Velocity HUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = true, FolderName = "VelocityHub" },
  KeySystem = false,
})

local mainTab = velocityHUBWindow:CreateTab("Main")
local aimbotTab = velocityHUBWindow:CreateTab("Aimbot")
local espTab = velocityHUBWindow:CreateTab("ESP")
local playerTab = velocityHUBWindow:CreateTab("Player")
local v1 = false

mainTab:CreateToggle({
  Name = "Hop server when your friend joins",
  Callback = function(value) v1 = value end,
})

players.PlayerAdded:Connect(function(player)
  if v1 and localPlayer:IsFriendsWith(player.UserId) then
    teleportService:Teleport(game.PlaceId)
  end
end)

mainTab:CreateButton({
  Name = "Rejoin Server",
  Callback = function() teleportService:Teleport(game.PlaceId, localPlayer) end,
})

mainTab:CreateButton({
  Name = "Hop Server",
  Callback = function() teleportService:Teleport(game.PlaceId) end,
})

local v2 = false
local autoShoot = false

local instance = Instance.new("ScreenGui", localPlayer.PlayerGui)
instance.IgnoreGuiInset = true
instance.ResetOnSpawn = false

local instance2 = Instance.new("Frame", instance)
instance2.AnchorPoint = Vector2.new(0.5, 0.5)
instance2.Position = UDim2.fromScale(0.5, 0.5)
instance2.Size = UDim2.fromOffset(240, 240)
instance2.BackgroundTransparency = 1
instance2.Visible = false

Instance.new("UICorner", instance2).CornerRadius = UDim.new(1, 0)

local instance3 = Instance.new("UIStroke", instance2)
instance3.Thickness = 1
instance3.Color = Color3.fromRGB(255, 0, 0)

local f1

local function f2()
  local huge = math.huge
  local getMouseLocation = userInputService:GetMouseLocation()
  local v3

  for index, value2 in ipairs(players:GetPlayers()) do
    if value2 ~= localPlayer and value2.Character and value2.Character:FindFirstChild("Head")
      and value2.Character:FindFirstChild("Humanoid") and value2.Character.Humanoid.Health > 0
      and f1(value2.Character.Head) then
      local v4, v5 = currentCamera:WorldToViewportPoint(value2.Character.Head.Position)

      if v5 then
        local magnitude = (Vector2.new(v4.X, v4.Y) - getMouseLocation).Magnitude

        if magnitude < 120 and magnitude < huge then
          v3 = value2
          huge = magnitude
        end
      end
    end
  end

  return v3
end

function f1(p1)
  local position = currentCamera.CFrame.Position
  local position2 = p1.Position

  local raycastParams = RaycastParams.new()
  raycastParams.FilterDescendantsInstances = { localPlayer.Character }
  raycastParams.FilterType = Enum.RaycastFilterType.Blacklist

  local raycast = workspace:Raycast(position, position2 - position, raycastParams)
  return not raycast or raycast.Instance:IsDescendantOf(p1.Parent)
end

aimbotTab:CreateToggle({
  Name = "Auto Aim (Head Only)",
  Callback = function(value3) v2 = value3 end,
})

aimbotTab:CreateToggle({
  Name = "Show FOV Circle",
  Callback = function(value4) instance2.Visible = value4 end,
})

aimbotTab:CreateToggle({
  Name = "Auto Shoot",
  Callback = function(value5) autoShoot = value5 end,
})

runService.Heartbeat:Connect(function()
  if not v2 then
    return
  else
    local v6 = f2()

    if v6 and v6.Character and v6.Character:FindFirstChild("Head") then
      currentCamera.CFrame = CFrame.new(
        currentCamera.CFrame.Position, v6.Character.Head.Position
      )

      if autoShoot then
        mouse1press()
        task.wait(0.03)
        mouse1release()
      end
    end

    return
  end
end)

local localPlayer2 = players.LocalPlayer
local v7 = { Enabled = false, Color = Color3.fromRGB(255, 0, 0), ShowName = true }

local velocityESP = Instance.new("Folder")
velocityESP.Name = "VelocityESP"
velocityESP.Parent = coreGui

local v8 = {}

local function f3(key)
  if v8[key] then
    for index2, value6 in ipairs(v8[key]) do
      if value6 and value6.Destroy then
        value6:Destroy()
      end
    end

    v8[key] = nil
  end
end

local v9 = {}
local f4

local function f5()
  for index3, value7 in ipairs(players:GetPlayers()) do
    if value7 ~= localPlayer2 then
      f4(value7)
    end
  end
end

function f4(key2)
  if not v7.Enabled then
    return
  elseif key2 == localPlayer2 then
    return
  elseif not key2.Character then
    return
  else
    f3(key2)
    local character = key2.Character
    local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
    local v10 = not humanoidRootPart
    local humanoid = character:FindFirstChild("Humanoid")

    if v10 or not humanoid or humanoid.Health <= 0 then
      return
    else
      local v11 = {}

      local highlight = Instance.new("Highlight")
      highlight.Adornee = character
      highlight.FillColor = v7.Color
      highlight.OutlineColor = v7.Color
      highlight.FillTransparency = 0.45
      highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
      highlight.Parent = velocityESP

      table.insert(v11, highlight)

      if v7.ShowName then
        local billboardGui = Instance.new("BillboardGui")
        billboardGui.Size = UDim2.fromScale(4, 1)
        billboardGui.StudsOffset = Vector3.new(0, 3, 0)
        billboardGui.AlwaysOnTop = true
        billboardGui.Adornee = humanoidRootPart
        billboardGui.Parent = velocityESP

-- https://discord.gg/AwGHNh7Z7T
        local textLabel = Instance.new("TextLabel")
        textLabel.BackgroundTransparency = 1
        textLabel.Size = UDim2.fromScale(1, 1)
        textLabel.Text = key2.Name
        textLabel.Font = Enum.Font.GothamBold
        textLabel.TextScaled = true
        textLabel.TextColor3 = v7.Color
        textLabel.Parent = billboardGui

        table.insert(v11, billboardGui)
      end

      v8[key2] = v11
      return
    end
  end
end

local function f6(value8)
  if v9[value8] then
    for key3, value9 in pairs(v9[value8]) do
      value9:Disconnect()
    end
  end

  v9[value8] = {}
  local characterAdded = value8.CharacterAdded

  table.insert(v9[value8], characterAdded:Connect(function()
    task.wait(0.3)
    f4(value8)
  end))

  local characterRemoving = value8.CharacterRemoving
  table.insert(v9[value8], characterRemoving:Connect(function() f3(value8) end))

  if value8.Character then
    task.spawn(function()
      task.wait(0.3)
      f4(value8)
    end)
  end
end

for index4, value10 in ipairs(players:GetPlayers()) do
  f6(value10)
end

players.PlayerAdded:Connect(f6)
players.PlayerRemoving:Connect(function(player2) f3(player2) end)

espTab:CreateToggle({
  Name = "Highlight ESP",
  CurrentValue = false,
  Callback = function(value11)
    v7.Enabled = value11

    if value11 then
      f5()
    else
      for key4, value12 in pairs(v8) do
        f3(key4)
      end
    end
  end,
})

local function f7()
  for key5, value13 in pairs(v8) do
    for index5, value14 in ipairs(value13) do
      if value14:IsA("Highlight") then
        value14.FillColor = v7.Color
        value14.OutlineColor = v7.Color
      elseif value14:IsA("BillboardGui") then
        local textLabel2 = value14:FindFirstChildOfClass("TextLabel")

        if textLabel2 then
          textLabel2.TextColor3 = v7.Color
        end
      end
    end
  end
end

espTab:CreateSlider({
  Name = "Color Red",
  Range = { 0, 255 },
  Increment = 1,
  CurrentValue = 255,
  Callback = function(value15)
    v7.Color = Color3.fromRGB(value15, v7.Color.G * 255, v7.Color.B * 255)
    f7()
  end,
})

espTab:CreateSlider({
  Name = "Color Green",
  Range = { 0, 255 },
  Increment = 1,
  CurrentValue = 0,
  Callback = function(value16)
    v7.Color = Color3.fromRGB(v7.Color.R * 255, value16, v7.Color.B * 255)
    f7()
  end,
})

espTab:CreateSlider({
  Name = "Color Blue",
  Range = { 0, 255 },
  Increment = 1,
  CurrentValue = 0,
  Callback = function(value17)
    v7.Color = Color3.fromRGB(v7.Color.R * 255, v7.Color.G * 255, value17)
    f7()
  end,
})

local function f8()
  return (localPlayer2.Character or localPlayer2.CharacterAdded:Wait()):WaitForChild("Humanoid")
end

playerTab:CreateSlider({
  Name = "WalkSpeed",
  Range = { 16, 50 },
  Increment = 1,
  CurrentValue = 16,
  Callback = function(value18) f8().WalkSpeed = value18 end,
})

playerTab:CreateSlider({
  Name = "JumpPower",
  Range = { 50, 100 },
  Increment = 1,
  CurrentValue = 50,
  Callback = function(value19) f8().JumpPower = value19 end,
})

local v12 = false
local instance4, instance5

playerTab:CreateToggle({
  Name = "Fly",
  Callback = function(value20)
    v12 = value20

    local humanoidRootPart2 = localPlayer2.Character
      and localPlayer2.Character:FindFirstChild("HumanoidRootPart")

    if not humanoidRootPart2 then
      return
    end

    if value20 then
      instance4 = Instance.new("BodyVelocity", humanoidRootPart2)
      instance4.MaxForce = Vector3.new(10000, 10000, 10000)

      instance5 = Instance.new("BodyGyro", humanoidRootPart2)
      instance5.MaxTorque = Vector3.new(10000, 10000, 10000)
    else
      if instance4 then
        instance4:Destroy()
      end

      if instance5 then
        instance5:Destroy()
      end
    end
  end,
})

runService.RenderStepped:Connect(function()
  if v12 and instance4 then
    instance4.Velocity = currentCamera.CFrame.LookVector * 30
  end
end)

local noclip = false
playerTab:CreateToggle({ Name = "Noclip", Callback = function(value21) noclip = value21 end })

runService.Stepped:Connect(function()
  if not noclip then
    return
  else
    local character2 = localPlayer2.Character

    if not character2 then
      return
    end

    for index6, value22 in ipairs(character2:GetDescendants()) do
      if value22:IsA("BasePart") then
        value22.CanCollide = false
      end
    end

    return
  end
end)
