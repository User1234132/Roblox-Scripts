-- FUCKED BY MEDALWARE
local players = game:GetService("Players")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local replicatedStorage = game:GetService("ReplicatedStorage")
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local verifyKey = true
local enterKey = ""

local keySystemWindow = rayfield:CreateWindow({
  Name = "Key System",
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false },
  Discord = { Enabled = false, Invite = "", RememberJoins = true },
  KeySystem = false,
})

local keySystemTab = keySystemWindow:CreateTab("Key System", 4483362458)
keySystemTab:CreateSection("VelocityHUB Access")
keySystemTab:CreateLabel("Enter the key below to access VelocityHUB.")
keySystemTab:CreateLabel("The key is available in our Discord server.")

keySystemTab:CreateInput({
  Name = "Enter Key",
  PlaceholderText = "Enter your key here...",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) enterKey = value end,
})

keySystemTab:CreateButton({
  Name = "Verify Key",
  Callback = function()
    if enterKey == "VELOCITY_2026" then
      verifyKey = true

      rayfield:Notify({
        Title = "Key Verified",
        Content = "Correct key! Opening VelocityHUB...",
        Duration = 3,
      })

      task.wait(0.5)
      keySystemWindow:Destroy()
    else
      rayfield:Notify({
        Title = "Wrong Key",
        Content = "The key you entered is incorrect.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateButton({
  Name = "Copy Discord Link",
  Callback = function()
    if setclipboard then
      setclipboard("https://discord.gg/QVTsmm352y")

      rayfield:Notify({
        Title = "Discord Link Copied",
        Content = "The Discord invite link has been copied to your clipboard.",
        Duration = 3,
      })
    else
      rayfield:Notify({
        Title = "Clipboard Error",
        Content = "Your executor does not support clipboard copying.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateLabel("Join our Discord to get the key.")

repeat
  task.wait()
until verifyKey

local window = rayfield:CreateWindow({
  Name = "Chicken Farm🐣 | VelocityHUB",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "VelocityHUB",
  ConfigurationSaving = { Enabled = false, FolderName = nil, FileName = "YumurtaHub" },
  Discord = { Enabled = false, Invite = "", RememberJoins = true },
  KeySystem = false,
})

local mainTab = window:CreateTab("Main", 4483362458)
local playerTab = window:CreateTab("Player", 4483362458)

local informationTab = window:CreateTab("Information", 4483362458)
informationTab:CreateSection("Information")

local label = informationTab:CreateLabel("Cash: Yükleniyor...")
local label2 = informationTab:CreateLabel("Rebirth: Yükleniyor...")
local label3 = informationTab:CreateLabel("Chickens: Yükleniyor...")
local label4 = informationTab:CreateLabel("Egg Multiplier: Yükleniyor...")
local label5 = informationTab:CreateLabel("Current Likes: Yükleniyor...")
local label6 = informationTab:CreateLabel("Eggs: Yükleniyor...")
local label7 = informationTab:CreateLabel("Position: Yükleniyor...")

task.spawn(function()
  while task.wait(0.5) do
    local localPlayer = players.LocalPlayer

    if localPlayer:FindFirstChild("PlayerGui") and localPlayer.PlayerGui:FindFirstChild("Main")
      and localPlayer.PlayerGui.Main:FindFirstChild("Currencies") then
      local cash = localPlayer.PlayerGui.Main.Currencies:FindFirstChild("Cash")

      if cash and cash:FindFirstChild("List") and cash.List:FindFirstChild("Amount") then
        label:Set("Cash: " .. tostring(cash.List.Amount.Text))
      end
    end

    local leaderstats = localPlayer:FindFirstChild("leaderstats")

    if leaderstats then
      local rebirth = leaderstats:FindFirstChild("Rebirth")

      if rebirth then
        label2:Set("Rebirth: " .. tostring(rebirth.Value))
      end

      local chickens = leaderstats:FindFirstChild("Chickens")

      if chickens then
        label3:Set("Chickens: " .. tostring(chickens.Value))
      end
    end

    local values = replicatedStorage:FindFirstChild("Values")

    if values then
      local eggMultiplier = values:FindFirstChild("EggMultiplier")

      if eggMultiplier then
        label4:Set("Egg Multiplier: " .. tostring(eggMultiplier.Value))
      end

      local currentLIKES = values:FindFirstChild("CURRENT_LIKES")

      if currentLIKES then
        label5:Set("Current Likes: " .. tostring(currentLIKES.Value))
      end
    end

    if localPlayer:FindFirstChild("PlayerGui") and localPlayer.PlayerGui:FindFirstChild("Main")
      and localPlayer.PlayerGui.Main:FindFirstChild("Eggs") then
      local amount = localPlayer.PlayerGui.Main.Eggs:FindFirstChild("Amount")

      if amount and amount:FindFirstChild("Amt") then
        label6:Set("Eggs: " .. tostring(amount.Amt.Text))
      end
    end

    local character = localPlayer.Character

    if character and character:FindFirstChild("HumanoidRootPart") then
      local position = character.HumanoidRootPart.Position

      label7:Set(string.format(
        "Position: X: %d, Y: %d, Z: %d", math.floor(position.X), math.floor(position.Y),
        math.floor(position.Z)
      ))
    else
      label7:Set("Position: Bilinmiyor")
    end
  end
end)

playerTab:CreateSection("Player Modifiers")

playerTab:CreateSlider({
  Name = "Player Speed",
  Range = { 16, 100 },
  Increment = 1,
  Suffix = "WalkSpeed",
  CurrentValue = 16,
  Flag = "SpeedSlider",
  Callback = function(value2)
    local localPlayer2 = players.LocalPlayer

    if localPlayer2.Character and localPlayer2.Character:FindFirstChild("Humanoid") then
      localPlayer2.Character.Humanoid.WalkSpeed = value2
    end
  end,
})

playerTab:CreateSlider({
  Name = "Player Jump Power",
  Range = { 50, 500 },
  Increment = 1,
  Suffix = "JumpPower",
  CurrentValue = 50,
  Flag = "JumpSlider",
  Callback = function(value3)
    local localPlayer3 = players.LocalPlayer

    if localPlayer3.Character and localPlayer3.Character:FindFirstChild("Humanoid") then
      localPlayer3.Character.Humanoid.UseJumpPower = true
      localPlayer3.Character.Humanoid.JumpPower = value3
    end
  end,
})

local infiniteJump = false

playerTab:CreateToggle({
  Name = "Infinite Jump",
  CurrentValue = false,
  Flag = "InfJumpToggle",
  Callback = function(value4) infiniteJump = value4 end,
})

userInputService.JumpRequest:Connect(function()
  if infiniteJump then
    local character2 = players.LocalPlayer.Character

    if character2 and character2:FindFirstChildOfClass("Humanoid") then
      character2:FindFirstChildOfClass("Humanoid"):ChangeState(Enum.HumanoidStateType.Jumping)
    end
  end
end)

playerTab:CreateSection("Fly & Movement")
local v1 = false
local flySpeed = 1
local bodyVelocity, bodyGyro

playerTab:CreateToggle({
  Name = "Fly",
  CurrentValue = false,
  Flag = "FlyToggle",
  Callback = function(value5)
    v1 = value5
    local character3 = players.LocalPlayer.Character

    if v1 and character3 and character3:FindFirstChild("HumanoidRootPart")
      and character3:FindFirstChild("Humanoid") then
      local humanoidRootPart = character3.HumanoidRootPart
      character3.Humanoid.PlatformStand = true

      bodyVelocity = Instance.new("BodyVelocity")
      bodyVelocity.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
      bodyVelocity.Velocity = Vector3.new(0, 0, 0)
      bodyVelocity.Parent = humanoidRootPart

      bodyGyro = Instance.new("BodyGyro")
      bodyGyro.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
      bodyGyro.P = 10000
      bodyGyro.CFrame = workspace.CurrentCamera.CFrame
      bodyGyro.Parent = humanoidRootPart
    else
      if character3 and character3:FindFirstChild("Humanoid") then
        character3.Humanoid.PlatformStand = false
      end

      if bodyVelocity then
        bodyVelocity:Destroy()
      end

      if bodyGyro then
        bodyGyro:Destroy()
      end
    end
  end,
})

runService.RenderStepped:Connect(function()
  if v1 and bodyVelocity and bodyGyro then
    local currentCamera = workspace.CurrentCamera
    bodyGyro.CFrame = currentCamera.CFrame
    local vector = Vector3.new(0, 0, 0)

    if userInputService:IsKeyDown(Enum.KeyCode.W) then
      vector = vector + currentCamera.CFrame.LookVector
    end

    if userInputService:IsKeyDown(Enum.KeyCode.S) then
      vector = vector - currentCamera.CFrame.LookVector
    end

    if userInputService:IsKeyDown(Enum.KeyCode.A) then
      vector = vector - currentCamera.CFrame.RightVector
    end

    if userInputService:IsKeyDown(Enum.KeyCode.D) then
      vector = vector + currentCamera.CFrame.RightVector
    end

    if userInputService:IsKeyDown(Enum.KeyCode.Space) then
      vector = vector + Vector3.new(0, 1, 0)
    end

    if userInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
      vector = vector - Vector3.new(0, 1, 0)
    end

    bodyVelocity.Velocity = vector * (flySpeed * 50)
  end
end)

playerTab:CreateSlider({
  Name = "Fly Speed",
  Range = { 1, 10 },
  Increment = 1,
  Suffix = "Speed",
  CurrentValue = 1,
  Flag = "FlySpeedSlider",
  Callback = function(value6) flySpeed = value6 end,
})

local noClip = false

playerTab:CreateToggle({
  Name = "NoClip",
  CurrentValue = false,
  Flag = "NoclipToggle",
  Callback = function(value7) noClip = value7 end,
})

runService.Stepped:Connect(function()
  if noClip then
    local character4 = players.LocalPlayer.Character

    if character4 then
      for key, value8 in pairs(character4:GetDescendants()) do
        if value8:IsA("BasePart") and value8.CanCollide then
          value8.CanCollide = false
        end
      end
    end
  end
end)

local v2 = {}

local function f1(p1, key2)
  if p1 and not v2[key2] then
    v2[key2] = {
      CFrame = p1.CFrame,
      Transparency = p1.Transparency,
      CanCollide = p1.CanCollide,
      Size = p1.Size,
    }
  end
end

local function f2(p2, key3)
  if p2 and v2[key3] then
    p2.CFrame = v2[key3].CFrame
    p2.Transparency = v2[key3].Transparency
    p2.CanCollide = v2[key3].CanCollide
    p2.Size = v2[key3].Size

    if p2:FindFirstChild("UI") then
      p2.UI.Enabled = true
    end
  end
end

mainTab:CreateSection("Auto Collect Eggs")
local v3 = false

mainTab:CreateToggle({
  Name = "Auto TP All Eggs To Player",
  CurrentValue = false,
  Flag = "AutoEggsToggle",
  Callback = function(value9)
    v3 = value9

    if v3 then
      task.spawn(function()
        while v3 do
          local character5 = players.LocalPlayer.Character

          if character5 and character5:FindFirstChild("HumanoidRootPart") then
            local humanoidRootPart2 = character5.HumanoidRootPart
            local eggs = workspace:FindFirstChild("Eggs")

            if eggs then
              for key4, value10 in pairs(eggs:GetChildren()) do
                if value10:IsA("Model") then
                  value10:PivotTo(humanoidRootPart2.CFrame)
                elseif value10:IsA("BasePart") then
                  value10.CFrame = humanoidRootPart2.CFrame
                end
              end
            end
          end

          task.wait(0.1)
        end
      end)
    end
  end,
})

mainTab:CreateButton({
  Name = "TP All Eggs To Player",
  Callback = function()
    local localPlayer4 = players.LocalPlayer
    local character6 = localPlayer4.Character or localPlayer4.CharacterAdded:Wait()

    if character6 and character6:FindFirstChild("HumanoidRootPart") then
      local humanoidRootPart3 = character6.HumanoidRootPart
      local eggs2 = workspace:FindFirstChild("Eggs")

      if eggs2 then
        for key5, value11 in pairs(eggs2:GetChildren()) do
          if value11:IsA("Model") then
            value11:PivotTo(humanoidRootPart3.CFrame)
          elseif value11:IsA("BasePart") then
            value11.CFrame = humanoidRootPart3.CFrame
          end
        end
      end
    end
  end,
})

mainTab:CreateSection("Auto Merge")

local autoMerge = false

mainTab:CreateToggle({
  Name = "Auto Merge",
  CurrentValue = false,
  Flag = "AutoMergeToggle",
  Callback = function(value12)
    autoMerge = value12
    local localPlayer5 = players.LocalPlayer

    if autoMerge then
      task.spawn(function()
        while autoMerge do
          local character7 = localPlayer5.Character

          if character7 and character7:FindFirstChild("HumanoidRootPart") then
            local humanoidRootPart4 = character7.HumanoidRootPart
            local plots = workspace:FindFirstChild("Plots")

            if plots then
              local findFirstChild = plots:FindFirstChild(localPlayer5.Name)

              if findFirstChild and findFirstChild:FindFirstChild("Buttons")
                and findFirstChild.Buttons:FindFirstChild("MergeChickens") then
                local button = findFirstChild.Buttons.MergeChickens:FindFirstChild("Button")

                if button and button:IsA("BasePart") then
                  f1(button, "Merge")
                  local v4 = math.round(button.Color.R * 255)
                  local v5 = math.round(button.Color.G * 255)
                  local v6 = math.round(button.Color.B * 255)

-- https://discord.gg/AwGHNh7Z7T
                  if v4 == 220 and v5 == 182 and v6 == 43 then
                    local vector2 = Vector3.new(8, 8, 8)

                    button.CanCollide = false
                    button.Transparency = 1
                    button.Size = vector2

                    if button:FindFirstChild("UI") then
                      button.UI.Enabled = false
                    end

                    button.CFrame = humanoidRootPart4.CFrame
                      * CFrame.new(0, math.sin(tick() * 10) * 3, 0)

                    if firetouchinterest then
                      firetouchinterest(humanoidRootPart4, button, 0)
                      task.wait(0.01)
                      firetouchinterest(humanoidRootPart4, button, 1)
                    end
                  else
                    f2(button, "Merge")
                  end
                end
              end
            end
          end

          task.wait(0.1)
        end
      end)
    else
      local plots2 = workspace:FindFirstChild("Plots")

      if plots2 then
        local findFirstChild2 = plots2:FindFirstChild(localPlayer5.Name)

        if findFirstChild2 and findFirstChild2:FindFirstChild("Buttons")
          and findFirstChild2.Buttons:FindFirstChild("MergeChickens") then
          f2(findFirstChild2.Buttons.MergeChickens:FindFirstChild("Button"), "Merge")
        end
      end
    end
  end,
})

mainTab:CreateButton({
  Name = "Instant Merge",
  Callback = function()
    local localPlayer6 = players.LocalPlayer
    local character8 = localPlayer6.Character

    if character8 and character8:FindFirstChild("HumanoidRootPart") then
      local humanoidRootPart5 = character8.HumanoidRootPart
      local plots3 = workspace:FindFirstChild("Plots")

      if plots3 then
        local findFirstChild3 = plots3:FindFirstChild(localPlayer6.Name)

        if findFirstChild3 and findFirstChild3:FindFirstChild("Buttons")
          and findFirstChild3.Buttons:FindFirstChild("MergeChickens") then
          local button2 = findFirstChild3.Buttons.MergeChickens:FindFirstChild("Button")

          if button2 and button2:IsA("BasePart") then
            f1(button2, "Merge")
            local v7 = math.round(button2.Color.R * 255)
            local v8 = math.round(button2.Color.G * 255)
            local v9 = math.round(button2.Color.B * 255)

            if v7 == 220 and v8 == 182 and v9 == 43 then
              local vector3 = Vector3.new(8, 8, 8)

              button2.CanCollide = false
              button2.Transparency = 1
              button2.Size = vector3

              if button2:FindFirstChild("UI") then
                button2.UI.Enabled = false
              end

              button2.CFrame = humanoidRootPart5.CFrame * CFrame.new(0, 3, 0)
              task.wait(0.05)
              button2.CFrame = humanoidRootPart5.CFrame * CFrame.new(0, -3, 0)

              if firetouchinterest then
                firetouchinterest(humanoidRootPart5, button2, 0)
                task.wait(0.01)
                firetouchinterest(humanoidRootPart5, button2, 1)
              end

              task.wait(0.1)
              f2(button2, "Merge")
            end
          end
        end
      end
    end
  end,
})

mainTab:CreateSection("Auto Collect Cash")

local v10 = false

mainTab:CreateToggle({
  Name = "Auto Collect Cash",
  CurrentValue = false,
  Flag = "AutoCashToggle",
  Callback = function(value13)
    v10 = value13
    local localPlayer7 = players.LocalPlayer

    if v10 then
      task.spawn(function()
        while v10 do
          local character9 = localPlayer7.Character

          if character9 and character9:FindFirstChild("HumanoidRootPart") then
            local humanoidRootPart6 = character9.HumanoidRootPart
            local plots4 = workspace:FindFirstChild("Plots")

            if plots4 then
              local findFirstChild4 = plots4:FindFirstChild(localPlayer7.Name)

              if findFirstChild4 and findFirstChild4:FindFirstChild("Buttons")
                and findFirstChild4.Buttons:FindFirstChild("CollectMoney") then
                local button3 = findFirstChild4.Buttons.CollectMoney:FindFirstChild("Button")

                if button3 and button3:IsA("BasePart") then
                  f1(button3, "Cash")
                  local vector4 = Vector3.new(8, 8, 8)

                  button3.CanCollide = false
                  button3.Transparency = 1
                  button3.Size = vector4

                  if button3:FindFirstChild("UI") then
                    button3.UI.Enabled = false
                  end

                  button3.CFrame = humanoidRootPart6.CFrame
                    * CFrame.new(0, math.sin(tick() * 10) * 3, 0)

                  if firetouchinterest then
                    firetouchinterest(humanoidRootPart6, button3, 0)
                    task.wait(0.01)
                    firetouchinterest(humanoidRootPart6, button3, 1)
                  end
                end
              end
            end
          end

          task.wait(0.1)
        end
      end)
    else
      local plots5 = workspace:FindFirstChild("Plots")

      if plots5 then
        local findFirstChild5 = plots5:FindFirstChild(localPlayer7.Name)

        if findFirstChild5 and findFirstChild5:FindFirstChild("Buttons")
          and findFirstChild5.Buttons:FindFirstChild("CollectMoney") then
          f2(findFirstChild5.Buttons.CollectMoney:FindFirstChild("Button"), "Cash")
        end
      end
    end
  end,
})

mainTab:CreateButton({
  Name = "Instant Collect Cash",
  Callback = function()
    local localPlayer8 = players.LocalPlayer
    local character10 = localPlayer8.Character

    if character10 and character10:FindFirstChild("HumanoidRootPart") then
      local humanoidRootPart7 = character10.HumanoidRootPart
      local plots6 = workspace:FindFirstChild("Plots")

      if plots6 then
        local findFirstChild6 = plots6:FindFirstChild(localPlayer8.Name)

        if findFirstChild6 and findFirstChild6:FindFirstChild("Buttons")
          and findFirstChild6.Buttons:FindFirstChild("CollectMoney") then
          local button4 = findFirstChild6.Buttons.CollectMoney:FindFirstChild("Button")

          if button4 and button4:IsA("BasePart") then
            f1(button4, "Cash")
            local vector5 = Vector3.new(8, 8, 8)

            button4.CanCollide = false
            button4.Transparency = 1
            button4.Size = vector5

            if button4:FindFirstChild("UI") then
              button4.UI.Enabled = false
            end

            button4.CFrame = humanoidRootPart7.CFrame * CFrame.new(0, 3, 0)
            task.wait(0.05)
            button4.CFrame = humanoidRootPart7.CFrame * CFrame.new(0, -3, 0)

            if firetouchinterest then
              firetouchinterest(humanoidRootPart7, button4, 0)
              task.wait(0.01)
              firetouchinterest(humanoidRootPart7, button4, 1)
            end

            task.wait(0.1)
            f2(button4, "Cash")
          end
        end
      end
    end
  end,
})

mainTab:CreateSection("Auto Deposit Eggs")

local v11 = false

mainTab:CreateToggle({
  Name = "Auto Deposit Eggs",
  CurrentValue = false,
  Flag = "AutoDepositToggle",
  Callback = function(value14)
    v11 = value14
    local localPlayer9 = players.LocalPlayer

    if v11 then
      task.spawn(function()
        while v11 do
          local character11 = localPlayer9.Character

          if character11 and character11:FindFirstChild("HumanoidRootPart") then
            local humanoidRootPart8 = character11.HumanoidRootPart
            local plots7 = workspace:FindFirstChild("Plots")

            if plots7 then
              local findFirstChild7 = plots7:FindFirstChild(localPlayer9.Name)

              if findFirstChild7 and findFirstChild7:FindFirstChild("Buttons")
                and findFirstChild7.Buttons:FindFirstChild("DepositEggs") then
                local hitbox = findFirstChild7.Buttons.DepositEggs:FindFirstChild("Hitbox")

                if hitbox and hitbox:IsA("BasePart") then
                  f1(hitbox, "Deposit")
                  local vector6 = Vector3.new(8, 8, 8)

                  hitbox.CanCollide = false
                  hitbox.Transparency = 1
                  hitbox.Size = vector6

                  hitbox.CFrame = humanoidRootPart8.CFrame
                    * CFrame.new(0, math.sin(tick() * 10) * 3, 0)

                  if firetouchinterest then
                    firetouchinterest(humanoidRootPart8, hitbox, 0)
                    task.wait(0.01)
                    firetouchinterest(humanoidRootPart8, hitbox, 1)
                  end
                end
              end
            end
          end

          task.wait(0.1)
        end
      end)
    else
      local plots8 = workspace:FindFirstChild("Plots")

      if plots8 then
        local findFirstChild8 = plots8:FindFirstChild(localPlayer9.Name)

        if findFirstChild8 and findFirstChild8:FindFirstChild("Buttons")
          and findFirstChild8.Buttons:FindFirstChild("DepositEggs") then
          f2(findFirstChild8.Buttons.DepositEggs:FindFirstChild("Hitbox"), "Deposit")
        end
      end
    end
  end,
})

mainTab:CreateButton({
  Name = "Instant Deposit Eggs",
  Callback = function()
    local localPlayer10 = players.LocalPlayer
    local character12 = localPlayer10.Character

    if character12 and character12:FindFirstChild("HumanoidRootPart") then
      local humanoidRootPart9 = character12.HumanoidRootPart
      local plots9 = workspace:FindFirstChild("Plots")

      if plots9 then
        local findFirstChild9 = plots9:FindFirstChild(localPlayer10.Name)

        if findFirstChild9 and findFirstChild9:FindFirstChild("Buttons")
          and findFirstChild9.Buttons:FindFirstChild("DepositEggs") then
          local hitbox2 = findFirstChild9.Buttons.DepositEggs:FindFirstChild("Hitbox")

          if hitbox2 and hitbox2:IsA("BasePart") then
            f1(hitbox2, "Deposit")
            local vector7 = Vector3.new(8, 8, 8)

            hitbox2.CanCollide = false
            hitbox2.Transparency = 1
            hitbox2.Size = vector7
            hitbox2.CFrame = humanoidRootPart9.CFrame * CFrame.new(0, 3, 0)

            task.wait(0.05)
            hitbox2.CFrame = humanoidRootPart9.CFrame * CFrame.new(0, -3, 0)

            if firetouchinterest then
              firetouchinterest(humanoidRootPart9, hitbox2, 0)
              task.wait(0.01)
              firetouchinterest(humanoidRootPart9, hitbox2, 1)
            end

            task.wait(0.1)
            f2(hitbox2, "Deposit")
          end
        end
      end
    end
  end,
})

mainTab:CreateSection("Auto Upgrade")

local autoUpgrade = false

mainTab:CreateToggle({
  Name = "Auto Upgrade",
  CurrentValue = false,
  Flag = "AutoUpgradeToggle",
  Callback = function(value15)
    autoUpgrade = value15
    local localPlayer11 = players.LocalPlayer

    if autoUpgrade then
      task.spawn(function()
        while autoUpgrade do
          local character13 = localPlayer11.Character

          if character13 and character13:FindFirstChild("HumanoidRootPart") then
            local humanoidRootPart10 = character13.HumanoidRootPart
            local plots10 = workspace:FindFirstChild("Plots")

            if plots10 then
              local findFirstChild10 = plots10:FindFirstChild(localPlayer11.Name)

              if findFirstChild10 and findFirstChild10:FindFirstChild("Buttons")
                and findFirstChild10.Buttons:FindFirstChild("UpgradeProcess") then
                local button5 = findFirstChild10.Buttons.UpgradeProcess:FindFirstChild("Button")

                if button5 and button5:IsA("BasePart") then
                  f1(button5, "Upgrade")
                  local vector8 = Vector3.new(8, 8, 8)

                  button5.CanCollide = false
                  button5.Transparency = 1
                  button5.Size = vector8

                  if button5:FindFirstChild("UI") then
                    button5.UI.Enabled = false
                  end

                  button5.CFrame = humanoidRootPart10.CFrame
                    * CFrame.new(0, math.sin(tick() * 10) * 3, 0)

                  if firetouchinterest then
                    firetouchinterest(humanoidRootPart10, button5, 0)
                    task.wait(0.01)
                    firetouchinterest(humanoidRootPart10, button5, 1)
                  end
                end
              end
            end
          end

          task.wait(0.1)
        end
      end)
    else
      local plots11 = workspace:FindFirstChild("Plots")

      if plots11 then
        local findFirstChild11 = plots11:FindFirstChild(localPlayer11.Name)

        if findFirstChild11 and findFirstChild11:FindFirstChild("Buttons")
          and findFirstChild11.Buttons:FindFirstChild("UpgradeProcess") then
          f2(findFirstChild11.Buttons.UpgradeProcess:FindFirstChild("Button"), "Upgrade")
        end
      end
    end
  end,
})

mainTab:CreateButton({
  Name = "Instant Upgrade",
  Callback = function()
    local localPlayer12 = players.LocalPlayer
    local character14 = localPlayer12.Character

    if character14 and character14:FindFirstChild("HumanoidRootPart") then
      local humanoidRootPart11 = character14.HumanoidRootPart
      local plots12 = workspace:FindFirstChild("Plots")

      if plots12 then
        local findFirstChild12 = plots12:FindFirstChild(localPlayer12.Name)

        if findFirstChild12 and findFirstChild12:FindFirstChild("Buttons")
          and findFirstChild12.Buttons:FindFirstChild("UpgradeProcess") then
          local button6 = findFirstChild12.Buttons.UpgradeProcess:FindFirstChild("Button")

          if button6 and button6:IsA("BasePart") then
            f1(button6, "Upgrade")
            local vector9 = Vector3.new(8, 8, 8)

            button6.CanCollide = false
            button6.Transparency = 1
            button6.Size = vector9

            if button6:FindFirstChild("UI") then
              button6.UI.Enabled = false
            end

            button6.CFrame = humanoidRootPart11.CFrame * CFrame.new(0, 3, 0)
            task.wait(0.05)
            button6.CFrame = humanoidRootPart11.CFrame * CFrame.new(0, -3, 0)

            if firetouchinterest then
              firetouchinterest(humanoidRootPart11, button6, 0)
              task.wait(0.01)
              firetouchinterest(humanoidRootPart11, button6, 1)
            end

            task.wait(0.1)
            f2(button6, "Upgrade")
          end
        end
      end
    end
  end,
})