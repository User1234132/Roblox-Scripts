-- FUCKED BY MEDALWARE

local players = game:GetService("Players")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local localPlayer = players.LocalPlayer
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local verifyKey = true

local keySYSTEMWindow = rayfield:CreateWindow({
  Name = "KEY SYSTEM",
  LoadingTitle = "Authentication",
  LoadingSubtitle = "Enter Key",
  ConfigurationSaving = { Enabled = false },
})

local keyTab = keySYSTEMWindow:CreateTab("KEY", 4483362458)

keyTab:CreateButton({
  Name = "📋Copy Key Link",
  Callback = function()
    setclipboard("https://discord.com/invite/aGCBvr2zf9")
    rayfield:Notify({ Title = "Copied📋", Content = "Discord link copied!", Duration = 3 })
  end,
})

local key = ""

keyTab:CreateInput({
  Name = "🔑KEY",
  PlaceholderText = "🖊️Write Key",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) key = value end,
})

keyTab:CreateButton({
  Name = "✅Verify Key",
  Callback = function()
    if key == "VELOCITY_2026" then
      verifyKey = true
      keySYSTEMWindow:Destroy()
    else
      rayfield:Notify({ Title = "😭Error", Content = "❌Wrong Key", Duration = 3 })
    end
  end,
})

repeat
  task.wait()
until verifyKey

local window = rayfield:CreateWindow({
  Name = "VelocityHUB | Slap Battles OP Script",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "Pls Wait...",
  ConfigurationSaving = { Enabled = false },
})

local mainTab = window:CreateTab("Main", 4483362458)
local espTab = window:CreateTab("ESP", 4483362458)
local autoFarmTab = window:CreateTab("Auto Farm", 4483362458)
local tpTab = window:CreateTab("TP", 4483362458)
local evilBrazilTab = window:CreateTab("Evil Brazil", 4483362458)
local hitboxSize = 5
local showHitbox = false
Color3.fromRGB(255, 0, 0)
mainTab:CreateSection("Auto Slap")
local connect, hitbox

mainTab:CreateToggle({
  Name = "Auto Slap",
  CurrentValue = false,
  Callback = function(value2)
    local character, humanoidRootPart

    if value2 then
      character = localPlayer.Character or localPlayer.CharacterAdded:Wait()
      humanoidRootPart = character:WaitForChild("HumanoidRootPart")

      hitbox = Instance.new("Part")
      hitbox.Size = Vector3.new(hitboxSize, hitboxSize, hitboxSize)
      hitbox.Anchored = true
      hitbox.CanCollide = false
      hitbox.Transparency = showHitbox and 0.5 or 1
      hitbox.Color = Color3.fromRGB(255, 0, 0)
      hitbox.Name = "Hitbox"
      hitbox.Parent = workspace

      connect = runService.Heartbeat:Connect(function()
        if not character or not humanoidRootPart then
          return
        end

        hitbox.CFrame = humanoidRootPart.CFrame

        for key2, value3 in pairs(workspace:GetPartsInPart(hitbox)) do
          local getPlayerFromCharacter = players:GetPlayerFromCharacter((value3:FindFirstAncestorOfClass("Model")))

          if getPlayerFromCharacter and getPlayerFromCharacter ~= localPlayer then
            local tool = character:FindFirstChildOfClass("Tool")

            if tool then
              tool:Activate()
            end

            break
          end
        end
      end)
    else
      if connect then
        connect:Disconnect()
      end

      if hitbox then
        hitbox:Destroy()
      end
    end
  end,
})

mainTab:CreateSlider({
  Name = "Hitbox Size",
  Range = { 0, 15 },
  Increment = 1,
  CurrentValue = 5,
  Callback = function(value4)
    hitboxSize = value4

    if hitbox then
      hitbox.Size = Vector3.new(value4, value4, value4)
    end
  end,
})

mainTab:CreateToggle({
  Name = "Show Hitbox",
  CurrentValue = false,
  Callback = function(value5)
    showHitbox = value5

    if hitbox then
      hitbox.Transparency = value5 and 0.5 or 1
    end
  end,
})

mainTab:CreateSection("Fall Protection")

local part

mainTab:CreateToggle({
  Name = "Anti Fall Lobby",
  CurrentValue = false,
  Callback = function(value6)
    if value6 then
      part = Instance.new("Part")
      part.Size = Vector3.new(1000, 3, 1000)
      part.Position = Vector3.new(0, -10, 0)
      part.Anchored = true
      part.Transparency = 0.5
      part.Parent = workspace
    elseif part then
      part:Destroy()
    end
  end,
})

local part2

mainTab:CreateToggle({
  Name = "Anti Fall Slap Race",
  CurrentValue = false,
  Callback = function(value7)
    if value7 then
      part2 = Instance.new("Part")
      part2.Size = Vector3.new(200, 3, 200)
      part2.Position = Vector3.new(3415, 235, -15)
      part2.Anchored = true
      part2.Transparency = 0.5
      part2.Parent = workspace
    elseif part2 then
      part2:Destroy()
    end
  end,
})

espTab:CreateSection("ESP")
local playerESP = false
local v1 = false
local showDistance = false
local showGlove = false
local showSlaps = false
local color = Color3.fromRGB(255, 0, 0)

local function makeTextLabel(character2)
  if not character2 or character2:FindFirstChild("ESP") then
    return
  else
    local head = character2:FindFirstChild("Head")

    if not head then
      return
    else
      local esp = Instance.new("BillboardGui")
      esp.Name = "ESP"
      esp.Size = UDim2.new(0, 120, 0, 40)
      esp.StudsOffset = Vector3.new(0, 2.5, 0)
      esp.AlwaysOnTop = true

      local textLabel = Instance.new("TextLabel")
      textLabel.Size = UDim2.new(1, 0, 1, 0)
      textLabel.BackgroundTransparency = 1
      textLabel.TextScaled = false
      textLabel.TextSize = 14
      textLabel.Font = Enum.Font.Arcade
      textLabel.TextStrokeTransparency = 0
      textLabel.TextColor3 = color
      textLabel.TextYAlignment = Enum.TextYAlignment.Top
      textLabel.Parent = esp

      esp.Adornee = head
      esp.Parent = character2

      return
    end
  end
end

local function makeHighlight()
  for key3, value8 in pairs(players:GetPlayers()) do
    if value8 ~= localPlayer then
      local character3 = value8.Character

      if character3 then
        if playerESP then
          local espH = character3:FindFirstChild("ESP_H")

          local espH2 = espH
          espH2 = espH or Instance.new("Highlight")
          espH2.Name = "ESP_H"
          espH2.FillColor = color
          espH2.OutlineColor = color
          espH2.FillTransparency = 0.5
          espH2.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
          espH2.Parent = character3
        end

        if v1 or showDistance or showGlove or showSlaps then
          makeTextLabel(character3)
          local esp2 = character3:FindFirstChild("ESP")

          if esp2 then
            local textLabel2 = esp2:FindFirstChildOfClass("TextLabel")
            local name = ""

            if v1 then
              name = value8.Name
            end

            if showDistance then
              local character4 = localPlayer.Character

              if character4 and character4:FindFirstChild("HumanoidRootPart")
                and character3:FindFirstChild("HumanoidRootPart") then
                local v2 = math.floor((character4.HumanoidRootPart.Position
                  - character3.HumanoidRootPart.Position).Magnitude)

                name = name ~= "" and name .. "\n" .. v2 .. " studs" or v2 .. " studs"
              end
            end

            if showGlove then
              local leaderstats = value8:FindFirstChild("leaderstats")

              if leaderstats then
                local glove = leaderstats:FindFirstChild("Glove")

                if glove and glove:IsA("StringValue") then
                  name = name ~= "" and name .. "\n" .. glove.Value or glove.Value
                end
              end
            end

            if showSlaps then
              local leaderstats2 = value8:FindFirstChild("leaderstats")

              if leaderstats2 then
                local slaps = leaderstats2:FindFirstChild("Slaps")

                if slaps and slaps:IsA("IntValue") then
                  name = name ~= "" and name .. "\n" .. slaps.Value .. " Slaps"
                    or slaps.Value .. " Slaps"
                end
              end
            end

            textLabel2.Text = name
            textLabel2.TextColor3 = color
          end
        else
          local esp3 = character3:FindFirstChild("ESP")

          if esp3 then
            esp3:Destroy()
          end
        end
      end
    end
  end
end

espTab:CreateToggle({
  Name = "Player ESP",
  CurrentValue = false,
  Callback = function(value9)
    playerESP = value9

    if not value9 then
      for key4, value10 in pairs(players:GetPlayers()) do
        local character5 = value10.Character

        if character5 then
          if character5:FindFirstChild("ESP_H") then
            character5.ESP_H:Destroy()
          end

          if character5:FindFirstChild("ESP") then
            character5.ESP:Destroy()
          end
        end
      end
    end
  end,
})

espTab:CreateToggle({
  Name = "Show Name ESP",
  CurrentValue = false,
  Callback = function(value11) v1 = value11 end,
})

espTab:CreateToggle({
  Name = "Show Distance",
  CurrentValue = false,
  Callback = function(value12) showDistance = value12 end,
})

espTab:CreateToggle({
  Name = "Show Glove",
  CurrentValue = false,
  Callback = function(value13) showGlove = value13 end,
})

espTab:CreateToggle({
  Name = "Show Slaps",
  CurrentValue = false,
  Callback = function(value14) showSlaps = value14 end,
})

espTab:CreateColorPicker({
  Name = "ESP Color",
  Color = color,
  Callback = function(value15) color = value15 end,
})

local function f1(p1)
  local character6 = localPlayer.Character

  if not character6 or not character6:FindFirstChild("HumanoidRootPart") then
    return nil
  else
    local position = character6.HumanoidRootPart.Position
    local v3 = nil
    local huge = math.huge

    for key5, value16 in pairs(players:GetPlayers()) do
      if value16 ~= localPlayer and value16 ~= p1 then
        local character7 = value16.Character

        if character7 and character7:FindFirstChild("HumanoidRootPart") then
          local humanoid = character7:FindFirstChild("Humanoid")

          if humanoid and humanoid.Health > 0 then
            local magnitude = (position - character7.HumanoidRootPart.Position).Magnitude

            if magnitude < huge then
              v3 = value16
              huge = magnitude
            end
          end
        end
      end
    end

    return v3
  end
end

local renderStepped = runService.RenderStepped
local autoFarmZone

local function makePart()
  if workspace:FindFirstChild("AutoFarmZone") then
    autoFarmZone = workspace.AutoFarmZone
    return
  end

  autoFarmZone = Instance.new("Part")
  autoFarmZone.Name = "AutoFarmZone"
  autoFarmZone.Size = Vector3.new(1000, 30, 1000)
  autoFarmZone.Position = Vector3.new(-1201, 328, 0)
  autoFarmZone.Anchored = true
  autoFarmZone.CanCollide = false
  autoFarmZone.Transparency = 1
  autoFarmZone.Parent = workspace
end

renderStepped:Connect(function()
  if playerESP or v1 or showDistance or showGlove or showSlaps then
    makeHighlight()
  end
end)

local v4 = false
autoFarmZone = nil

local function f2(position2)
  local v5 = autoFarmZone.Size / 2
  local position3 = autoFarmZone.Position

  return position2.X > position3.X - v5.X and position2.X < position3.X + v5.X
    and position2.Y > position3.Y - v5.Y and position2.Y < position3.Y + v5.Y
    and position2.Z > position3.Z - v5.Z and position2.Z < position3.Z + v5.Z
end

local v6 = false

autoFarmTab:CreateSection("Auto Farm")

autoFarmTab:CreateToggle({
  Name = "Auto Farm Slap",
  CurrentValue = false,
  Callback = function(value17)
    v4 = value17
    makePart()

    if value17 then
      task.delay(1, function() v6 = true end)

      runService.Heartbeat:Connect(function()
        if not v4 or not v6 then
          return
        else
          local character8 = localPlayer.Character

          if not character8 then
            return
          else
            local humanoid2 = character8:FindFirstChild("Humanoid")
            local humanoidRootPart2 = character8:FindFirstChild("HumanoidRootPart")

            if not humanoid2 or humanoid2.Health <= 0 then
              return
            elseif not humanoidRootPart2 then
              return
            else
              local tool2 = character8:FindFirstChildOfClass("Tool")
              local lobby = workspace:FindFirstChild("Lobby")
              local teleport1 = lobby and lobby:FindFirstChild("Teleport1")
              local v7 = f1()

-- https://discord.gg/AwGHNh7Z7T
              if not v7 or not v7.Character then
                return
              else
                local character9 = v7.Character
                local humanoidRootPart3 = character9:FindFirstChild("HumanoidRootPart")
                local v8 = not humanoidRootPart3
                local humanoid3 = character9:FindFirstChild("Humanoid")

                if v8 or not humanoid3 or humanoid3.Health <= 0 then
                  return
                end

                if f2(humanoidRootPart2.Position) then
                  if teleport1 then
                    humanoidRootPart2.CFrame = teleport1.CFrame + Vector3.new(0, 5, 0)
                  end
                else
                  humanoidRootPart2.CFrame = humanoidRootPart3.CFrame * CFrame.new(0, 0, 3)
                  task.wait(0.1)

                  if tool2 then
                    tool2:Activate()
                  end
                end

                return
              end
            end
          end
        end
      end)
    else
      v6 = false
      v4 = false
    end
  end,
})

local function f3()
  local arena = workspace:FindFirstChild("Arena")

  if not arena then
    return nil
  else
    local island5 = arena:FindFirstChild("island5")

    if not island5 then
      return nil
    end

    return island5:FindFirstChild("Slapples")
  end
end

local function f4(cframe)
  local character10 = localPlayer.Character

  if not character10 then
    return
  else
    local humanoidRootPart4 = character10:FindFirstChild("HumanoidRootPart")

    if not humanoidRootPart4 then
      return
    end

    humanoidRootPart4.CFrame = cframe
    return
  end
end

local v9 = false

local function f5()
  local v10 = f3()

  if not v10 then
    return {}
  else
    local v11 = {}

    for key6, value18 in pairs(v10:GetChildren()) do
      if value18:IsA("Model") then
        if value18.Name == "Slapple" or value18.Name == "GoldenSlapple" then
          local basePart = value18:FindFirstChildWhichIsA("BasePart")

          if basePart then
            table.insert(v11, basePart)
          end
        end
      end
    end

    return v11
  end
end

autoFarmTab:CreateToggle({
  Name = "Auto Farm Island Slaps",
  CurrentValue = false,
  Callback = function(value19)
    v9 = value19

    if value19 then
      task.spawn(function()
        local humanoidRootPart5 = (localPlayer.Character
          or localPlayer.CharacterAdded:Wait()):WaitForChild("HumanoidRootPart")

        while v9 do
          local cframe2 = humanoidRootPart5.CFrame

          for key7, value20 in pairs((f5())) do
            if not v9 then
              break
            end

            if value20 and value20.Parent then
              f4(value20.CFrame + Vector3.new(0, 3, 0))
              task.wait(0.15)
            end
          end

          f4(cframe2)
          task.wait(0.5)
        end
      end)
    else
      v9 = false
    end
  end,
})

autoFarmTab:CreateToggle({
  Name = "Auto Farm Slap Race",
  CurrentValue = false,
  Callback = function(value21)
    local v12

    if value21 then
      v12 = true

      task.spawn(function()
        while v12 do
          local character11 = localPlayer.Character

          if not character11 then
            task.wait()
          else
            local humanoidRootPart6 = character11:FindFirstChild("HumanoidRootPart")
            local humanoid4 = character11:FindFirstChild("Humanoid")

            if not humanoidRootPart6 or not humanoid4 or humanoid4.Health <= 0 then
              task.wait()
            else
              humanoidRootPart6.CFrame = CFrame.new(3422, 252, -13)
              humanoidRootPart6.Velocity = Vector3.zero
              humanoidRootPart6.AssemblyLinearVelocity = Vector3.zero

              local playerGui = localPlayer:FindFirstChild("PlayerGui")
              local component = playerGui and playerGui:FindFirstChild("Component")
              local slapTournament = component and component:FindFirstChild("SlapTournament")

              if slapTournament and slapTournament.Visible then
                local acceptButton = slapTournament:FindFirstChild("AcceptButton")

                if acceptButton and acceptButton:IsA("ImageButton") then
                  pcall(function() acceptButton:Activate() end)
                  pcall(function() acceptButton.MouseButton1Click:Fire() end)

                  pcall(function()
                    for key8, value22 in pairs(getconnections(acceptButton.MouseButton1Click)) do
                      value22:Fire()
                    end
                  end)
                end
              end

              task.wait(0.05)
            end
          end
        end
      end)

      function autoFarmTab.__SlapRaceStop()
        v12 = false
      end
    elseif autoFarmTab.__SlapRaceStop then
      autoFarmTab.__SlapRaceStop()
      autoFarmTab.__SlapRaceStop = nil
    end
  end,
})

local airControl = 0

mainTab:CreateSlider({
  Name = "Air Control",
  Range = { 0, 20 },
  Increment = 1,
  CurrentValue = 0,
  Callback = function(value23) airControl = value23 end,
})

runService.RenderStepped:Connect(function()
  local character12 = localPlayer.Character

  if not character12 then
    return
  else
    local humanoidRootPart7 = character12:FindFirstChild("HumanoidRootPart")
    local v13 = not humanoidRootPart7
    local humanoid5 = character12:FindFirstChild("Humanoid")

    if v13 or not humanoid5 then
      return
    elseif humanoid5.FloorMaterial ~= Enum.Material.Air then
      return
    elseif airControl <= 0 then
      return
    else
      local moveDirection = humanoid5.MoveDirection

      if moveDirection.Magnitude == 0 then
        return
      else
        local v14 = airControl / 7
        local assemblyLinearVelocity = humanoidRootPart7.AssemblyLinearVelocity

        humanoidRootPart7.AssemblyLinearVelocity = Vector3.new(assemblyLinearVelocity.X
          + moveDirection.X * v14, assemblyLinearVelocity.Y, assemblyLinearVelocity.Z
          + moveDirection.Z * v14)

        return
      end
    end
  end
end)

tpTab:CreateSection("Islands")

tpTab:CreateButton({
  Name = "Main Island",
  Callback = function()
    local character13 = localPlayer.Character

    if character13 and character13:FindFirstChild("HumanoidRootPart") then
      character13.HumanoidRootPart.CFrame = CFrame.new(-22, -5, 4)
    end
  end,
})

tpTab:CreateButton({
  Name = "Island 1",
  Callback = function()
    local character14 = localPlayer.Character

    if character14 and character14:FindFirstChild("HumanoidRootPart") then
      character14.HumanoidRootPart.CFrame = CFrame.new(-6, -5, -202)
    end
  end,
})

tpTab:CreateButton({
  Name = "Island 2",
  Callback = function()
    local character15 = localPlayer.Character

    if character15 and character15:FindFirstChild("HumanoidRootPart") then
      character15.HumanoidRootPart.CFrame = CFrame.new(-3, -5, 207)
    end
  end,
})

tpTab:CreateButton({
  Name = "Island 3",
  Callback = function()
    local character16 = localPlayer.Character

    if character16 and character16:FindFirstChild("HumanoidRootPart") then
      character16.HumanoidRootPart.CFrame = CFrame.new(-206, -5, -1)
    end
  end,
})

tpTab:CreateSection("Moai")

tpTab:CreateButton({
  Name = "Island Moai",
  Callback = function()
    local character17 = localPlayer.Character

    if character17 and character17:FindFirstChild("HumanoidRootPart") then
      character17.HumanoidRootPart.CFrame = CFrame.new(233, -16, -3)
    end
  end,
})

tpTab:CreateSection("Special Islands")

tpTab:CreateButton({
  Name = "Cannon Island",
  Callback = function()
    local character18 = localPlayer.Character

    if character18 and character18:FindFirstChild("HumanoidRootPart") then
      character18.HumanoidRootPart.CFrame = CFrame.new(255, 34, 192)
    end
  end,
})

tpTab:CreateButton({
  Name = "Slapple Island",
  Callback = function()
    local character19 = localPlayer.Character

    if character19 and character19:FindFirstChild("HumanoidRootPart") then
      character19.HumanoidRootPart.CFrame = CFrame.new(-357, 51, -14)
    end
  end,
})

tpTab:CreateSection("Brazil")

tpTab:CreateButton({
  Name = "Brazil Portal",
  Callback = function()
    local character20 = localPlayer.Character

    local portal = workspace:FindFirstChild("Lobby")
      and workspace.Lobby:FindFirstChild("brazil")
      and workspace.Lobby.brazil:FindFirstChild("portal")

    if character20 and character20:FindFirstChild("HumanoidRootPart") and portal then
      character20.HumanoidRootPart.CFrame = portal.CFrame + Vector3.new(0, 5, 0)
    end
  end,
})

evilBrazilTab:CreateSection("Part 1")

evilBrazilTab:CreateButton({
  Name = "TP End",
  Callback = function()
    local character21 = localPlayer.Character

    if character21 and character21:FindFirstChild("HumanoidRootPart") then
      character21.HumanoidRootPart.CFrame = CFrame.new(1146, 71, -78)
    end
  end,
})

evilBrazilTab:CreateSection("Part 2")

local color2 = Color3.fromRGB(255, 0, 0)
local highlight

evilBrazilTab:CreateToggle({
  Name = "ESP Screwdriver",
  CurrentValue = false,
  Callback = function(value24)
    if value24 then
      local screwdriver = workspace:FindFirstChild("Screwdriver")

      if screwdriver then
        highlight = Instance.new("Highlight")
        highlight.FillColor = color2
        highlight.OutlineColor = color2
        highlight.FillTransparency = 0.5
        highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        highlight.Parent = screwdriver
      end
    elseif highlight then
      highlight:Destroy()
      highlight = nil
    end
  end,
})

local highlight2

evilBrazilTab:CreateToggle({
  Name = "ESP Stepladder",
  CurrentValue = false,
  Callback = function(value25)
    if value25 then
      local stepladder = workspace:FindFirstChild("Stepladder")

      if stepladder then
        highlight2 = Instance.new("Highlight")
        highlight2.FillColor = color2
        highlight2.OutlineColor = color2
        highlight2.FillTransparency = 0.5
        highlight2.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        highlight2.Parent = stepladder
      end
    elseif highlight2 then
      highlight2:Destroy()
      highlight2 = nil
    end
  end,
})

evilBrazilTab:CreateColorPicker({
  Name = "ESP Color Picker",
  Color = color2,
  Callback = function(value26)
    color2 = value26

    if highlight then
      highlight.FillColor = value26
      highlight.OutlineColor = value26
    end

    if highlight2 then
      highlight2.FillColor = value26
      highlight2.OutlineColor = value26
    end
  end,
})

evilBrazilTab:CreateSection("Part 3")

evilBrazilTab:CreateButton({
  Name = "Get Hammer",
  Callback = function()
    local character22 = localPlayer.Character

    if character22 and character22:FindFirstChild("HumanoidRootPart") then
      character22.HumanoidRootPart.CFrame = CFrame.new(4975, 5321, -199)
    end
  end,
})

evilBrazilTab:CreateButton({
  Name = "Get Grappler",
  Callback = function()
    local character23 = localPlayer.Character

    if character23 and character23:FindFirstChild("HumanoidRootPart") then
      character23.HumanoidRootPart.CFrame = CFrame.new(4975, 5321, -561)
    end
  end,
})

evilBrazilTab:CreateButton({
  Name = "TP End",
  Callback = function()
    local character24 = localPlayer.Character

    if character24 and character24:FindFirstChild("HumanoidRootPart") then
      character24.HumanoidRootPart.CFrame = CFrame.new(4753, 5549, -306)
    end
  end,
})