-- FUCKED BY MEDALWARE 

local players = game:GetService("Players")
local runService = game:GetService("RunService")
local localPlayer = players.LocalPlayer
local playerGui = localPlayer:WaitForChild("PlayerGui")
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local enterKey = ""
local verifyKey = true

local keySystemWindow = rayfield:CreateWindow({
  Name = "Key System",
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false },
  KeySystem = false,
})

local keySystemTab = keySystemWindow:CreateTab("Key System")
keySystemTab:CreateSection("VelocityHUB Key")
keySystemTab:CreateLabel("Enter the key to access VelocityHUB.")
keySystemTab:CreateLabel("The key is available in our Discord server.")

keySystemTab:CreateInput({
  Name = "Enter Key",
  PlaceholderText = "Enter your key here...",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) enterKey = value end,
})

keySystemTab:CreateButton({
  Name = "Verify Key",
  Callback = function()
    if enterKey == "VELOCITY_2026" then
      verifyKey = true

      rayfield:Notify({
        Title = "Key Verified",
        Content = "Correct key! Opening VelocityHUB...",
        Duration = 3,
      })

      task.wait(0.5)
      keySystemWindow:Destroy()
    else
      rayfield:Notify({
        Title = "Wrong Key",
        Content = "The key you entered is incorrect.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateButton({
  Name = "Copy Discord Link",
  Callback = function()
    if setclipboard then
      setclipboard("https://discord.gg/QVTsmm352y")

      rayfield:Notify({
        Title = "Discord Link Copied",
        Content = "The Discord invite link has been copied to your clipboard.",
        Duration = 3,
      })
    else
      rayfield:Notify({
        Title = "Clipboard Error",
        Content = "Your executor does not support clipboard copying.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateLabel("Join our Discord to get the key.")

repeat
  task.wait()
until verifyKey

local function f1(key)
  return key and key:IsA("MeshPart") and key.Parent ~= nil
end

local v1

local function f2(key2)
  local v2 = v1[key2]

  if v2 then
    v2:Destroy()
    v1[key2] = nil
  end
end

local window = rayfield:CreateWindow({
  Name = "Find the Chameleons🦎 | VelocityHUB",
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false },
})

local mainTab = window:CreateTab("Main", 4483362458)
local teleportTab = window:CreateTab("Teleport", 4483362458)
local characters = workspace:FindFirstChild("Characters")
local v3 = false
local v4 = false
local v5 = false
local v6 = false
local v7 = false
local showDistance = false
local v8 = false
local v9 = false
local under = 1

local function f3()
  local character = localPlayer.Character

  if not character then
    return nil
  end

  return character:FindFirstChild("HumanoidRootPart")
end

local color = Color3.fromRGB(255, 0, 0)
local v10 = {}
local radar = nil

local function makeTextLabel(key3)
  if v10[key3] then
    return
  elseif not radar then
    return
  else
    local radarDistance = Instance.new("TextLabel")
    radarDistance.Name = "RadarDistance"
    radarDistance.AnchorPoint = Vector2.new(0.5, 0.5)
    radarDistance.Size = UDim2.fromOffset(90, 24)
    radarDistance.BackgroundTransparency = 1
    radarDistance.Text = "0 studs"
    radarDistance.Font = Enum.Font.Arcade
    radarDistance.TextSize = 14
    radarDistance.TextColor3 = color
    radarDistance.TextStrokeTransparency = 0
    radarDistance.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    radarDistance.Visible = false
    radarDistance.ZIndex = 50
    radarDistance.Parent = radar

    v10[key3] = radarDistance
    return
  end
end

local v11 = 0
local v12 = {}
v1 = {}
local v13 = {}
local chameleonRadar = nil
local radarViewport = nil
local radarCamera = nil

local function f4()
  if chameleonRadar then
    chameleonRadar:Destroy()
    chameleonRadar = nil
  end

  radar = nil
  radarViewport = nil
  radarCamera = nil

  for key4, value2 in pairs(v13) do
    if value2 then
      value2:Destroy()
    end
  end

  v13 = {}

  for key5, value3 in pairs(v10) do
    if value3 then
      value3:Destroy()
    end
  end

  v10 = {}
end

local v14 = {}

local function makeTextLabel2(key6)
  if v14[key6] then
    return
  else
    local chameleonESPDistance = Instance.new("BillboardGui")
    chameleonESPDistance.Name = "ChameleonESPDistance"
    chameleonESPDistance.Adornee = key6
    chameleonESPDistance.AlwaysOnTop = true
    chameleonESPDistance.Size = UDim2.fromOffset(100, 28)
    chameleonESPDistance.StudsOffset = Vector3.new(0, 3, 0)
    chameleonESPDistance.MaxDistance = 170
    chameleonESPDistance.Enabled = false
    chameleonESPDistance.Parent = playerGui

    local distance = Instance.new("TextLabel")
    distance.Name = "Distance"
    distance.Size = UDim2.fromScale(1, 1)
    distance.BackgroundTransparency = 1
    distance.Text = "0 studs"
    distance.Font = Enum.Font.Arcade
    distance.TextSize = 18
    distance.TextColor3 = color
    distance.TextStrokeTransparency = 0
    distance.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    distance.Parent = chameleonESPDistance

    v14[key6] = { Billboard = chameleonESPDistance, Label = distance }
    return
  end
end

local v15 = {}
local v16 = {}
local v17 = {}

local function f5(descendant)
  if not descendant then
    return nil
  else
    local v18 = v15[descendant]

    if v18 and v18.Parent then
      return v18
    else
      local parent = descendant.Parent

      while parent do
        if parent:IsA("MeshPart") then
          v15[descendant] = parent
          return parent
        end

        if parent == characters then
          break
        end

        parent = parent.Parent
      end

      return nil
    end
  end
end

local function f6(p1)
  if not f1(p1) then
    return false
  end

  for index, value4 in ipairs(p1:GetChildren()) do
    if value4:IsA("BillboardGui") then
      v15[value4] = p1

      if value4.Enabled then
        return true
      end
    end
  end

  return false
end

local function f7(key7)
  return v4 and f6(key7)
end

local function f8(key8)
  if not f1(key8) then
    return
  end

  if not v17[key8] then
    v17[key8] = key8.CFrame
  end
end

local function f9(key9)
  return v7 and f6(key9)
end

local f10

local function f11()
  local v19 = {}

  for key10 in pairs(v12) do
    if f1(key10) then
      if not f10(key10) then
        table.insert(v19, key10)
      end
    end
  end

  return v19
end

function f10(p2)
  return v9 and f6(p2)
end

local function f12()
  local v20 = f3()

  if not v20 then
    return nil
  else
    local v21 = nil
    local huge = math.huge

    for key11 in pairs(v12) do
      if f1(key11) then
        if not f10(key11) then
          local magnitude = (key11.Position - v20.Position).Magnitude

          if magnitude < huge then
            huge = magnitude
            v21 = key11
          end
        end
      end
    end

    return v21
  end
end

local function f13(under2)
  local v22 = f3()

  if not v22 then
    return nil
  else
    local v23 = nil
    local huge2 = math.huge

    for key12 in pairs(v12) do
      if f1(key12) then
        if not f10(key12) then
          local rarity = key12:FindFirstChild("Rarity")

          if rarity and rarity:IsA("IntValue") and rarity.Value == under2 then
            local magnitude2 = (key12.Position - v22.Position).Magnitude

            if magnitude2 < huge2 then
              v23 = key12
              huge2 = magnitude2
            end
          end
        end
      end
    end

    return v23
  end
end

local function f14(index2)
  if not f1(index2) then
    return false
  else
    local v24 = f3()

    if not v24 then
      return false
    end

    v24.CFrame = CFrame.new(index2.Position + Vector3.new(0, 3, 0))
    return true
  end
end

local function f15()
  for key13, value5 in pairs(v17) do
    if f1(key13) then
      key13.CFrame = value5
    end
  end
end

local function makeHighlight(key14)
  if not v3 then
    return
  elseif not f1(key14) then
    return
  elseif f7(key14) then
    f2(key14)
    return
  elseif v1[key14] then
    return
  else
    local chameleonESP = Instance.new("Highlight")
    chameleonESP.Name = "ChameleonESP"
    chameleonESP.Adornee = key14
    chameleonESP.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    chameleonESP.FillColor = color
    chameleonESP.OutlineColor = color
    chameleonESP.FillTransparency = 0.5
    chameleonESP.OutlineTransparency = 0
    chameleonESP.Parent = key14

    v1[key14] = chameleonESP
    return
  end
end

local function f16()
  for key15 in pairs(v12) do
    if not f1(key15) then
      v12[key15] = nil
    elseif v3 and not f7(key15) then
      makeHighlight(key15)
    else
      f2(key15)
    end
  end
end

local f17

local function f18()
  if not v3 or not v5 then
    for key16, value6 in pairs(v14) do
      if value6.Billboard then
        value6.Billboard.Enabled = false
      end
    end

    return
  else
    local v25 = f3()

    if not v25 then
      return
    end

    for key17 in pairs(v12) do
      if not f1(key17) then
        f17(key17)
      elseif f7(key17) then
        local v26 = v14[key17]

        if v26 then
          v26.Billboard.Enabled = false
        end
      else
        if not v14[key17] then
          makeTextLabel2(key17)
        end

        local v27 = v14[key17]
        local magnitude3 = (key17.Position - v25.Position).Magnitude

        if magnitude3 > 120 then
          v27.Billboard.Enabled = false
        else
          local v28 = math.clamp(magnitude3 / 120, 0, 1)

          v27.Label.Text = string.format("%.0f studs", magnitude3)
          v27.Label.TextSize = math.clamp(18 - v28 * 8, 10, 18)
          v27.Label.TextColor3 = color
          v27.Billboard.Enabled = true
        end
      end
    end

    return
  end
end

local function f19(key18)
  local v29 = v13[key18]

  if v29 then
    v29:Destroy()
    v13[key18] = nil
  end

  local v30 = v10[key18]

  if v30 then
    v30:Destroy()
    v10[key18] = nil
  end
end

function f17(key19)
  local v31 = v14[key19]

  if v31 then
    if v31.Billboard then
      v31.Billboard:Destroy()
    end

    v14[key19] = nil
  end
end

local function makeTextLabel3()
  f4()

  chameleonRadar = Instance.new("ScreenGui")
  chameleonRadar.Name = "ChameleonRadar"
  chameleonRadar.ResetOnSpawn = false
  chameleonRadar.IgnoreGuiInset = true
  chameleonRadar.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
  chameleonRadar.Parent = playerGui

  radar = Instance.new("Frame")
  radar.Name = "Radar"
  radar.Size = UDim2.fromOffset(350, 350)
  radar.Position = UDim2.new(1, -375, 1, -375)
  radar.BackgroundColor3 = Color3.fromRGB(8, 10, 12)
  radar.BackgroundTransparency = 0.08
  radar.BorderSizePixel = 0
  radar.ClipsDescendants = true
  radar.Parent = chameleonRadar

  local uiCorner = Instance.new("UICorner")
  uiCorner.CornerRadius = UDim.new(1, 0)
  uiCorner.Parent = radar

  local uiStroke = Instance.new("UIStroke")
  uiStroke.Thickness = 3
  uiStroke.Color = Color3.fromRGB(70, 255, 120)
  uiStroke.Transparency = 0.15
  uiStroke.Parent = radar

  radarViewport = Instance.new("ViewportFrame")
  radarViewport.Name = "RadarViewport"
  radarViewport.Size = UDim2.fromScale(1, 1)
  radarViewport.BackgroundTransparency = 1
  radarViewport.BorderSizePixel = 0
  radarViewport.Ambient = Color3.fromRGB(180, 255, 190)
  radarViewport.LightColor = Color3.fromRGB(255, 255, 255)
  radarViewport.LightDirection = Vector3.new(0, -1, 0)
  radarViewport.Parent = radar

  local uiCorner2 = Instance.new("UICorner")
  uiCorner2.CornerRadius = UDim.new(1, 0)
  uiCorner2.Parent = radarViewport

  local radarWorld = Instance.new("WorldModel")
  radarWorld.Name = "RadarWorld"
  radarWorld.Parent = radarViewport

  radarCamera = Instance.new("Camera")
  radarCamera.Name = "RadarCamera"
  radarCamera.FieldOfView = 20
  radarCamera.Parent = radarViewport

  radarViewport.CurrentCamera = radarCamera

  local frame = Instance.new("Frame")
  frame.AnchorPoint = Vector2.new(0.5, 0.5)
  frame.Position = UDim2.fromScale(0.5, 0.5)
  frame.Size = UDim2.fromScale(1, 0)
  frame.BackgroundColor3 = Color3.fromRGB(70, 255, 120)
  frame.BackgroundTransparency = 0.75
  frame.BorderSizePixel = 0
  frame.ZIndex = 5
  frame.Parent = radar

  local frame2 = Instance.new("Frame")
  frame2.AnchorPoint = Vector2.new(0.5, 0.5)
  frame2.Position = UDim2.fromScale(0.5, 0.5)
  frame2.Size = UDim2.fromScale(0, 1)
  frame2.BackgroundColor3 = Color3.fromRGB(70, 255, 120)
  frame2.BackgroundTransparency = 0.75
  frame2.BorderSizePixel = 0
  frame2.ZIndex = 5
  frame2.Parent = radar

  local frame3 = Instance.new("Frame")
  frame3.AnchorPoint = Vector2.new(0.5, 0.5)
  frame3.Position = UDim2.fromScale(0.5, 0.5)
  frame3.Size = UDim2.fromScale(0.5, 0.5)
  frame3.BackgroundTransparency = 1
  frame3.BorderSizePixel = 0
  frame3.ZIndex = 6
  frame3.Parent = radar

  local uiCorner3 = Instance.new("UICorner")
  uiCorner3.CornerRadius = UDim.new(1, 0)
  uiCorner3.Parent = frame3

  local uiStroke2 = Instance.new("UIStroke")
  uiStroke2.Thickness = 1
  uiStroke2.Color = Color3.fromRGB(70, 255, 120)
  uiStroke2.Transparency = 0.55
  uiStroke2.Parent = frame3

  local frame4 = Instance.new("Frame")
  frame4.AnchorPoint = Vector2.new(0.5, 0.5)
  frame4.Position = UDim2.fromScale(0.5, 0.5)
  frame4.Size = UDim2.fromOffset(10, 10)
  frame4.BackgroundColor3 = Color3.fromRGB(80, 255, 130)
  frame4.BorderSizePixel = 0
  frame4.ZIndex = 20
  frame4.Parent = radar

-- https://discord.gg/AwGHNh7Z7T
  local uiCorner4 = Instance.new("UICorner")
  uiCorner4.CornerRadius = UDim.new(1, 0)
  uiCorner4.Parent = frame4

  local uiStroke3 = Instance.new("UIStroke")
  uiStroke3.Thickness = 2
  uiStroke3.Color = Color3.fromRGB(255, 255, 255)
  uiStroke3.Parent = frame4

  local textLabel = Instance.new("TextLabel")
  textLabel.BackgroundTransparency = 1
  textLabel.Size = UDim2.new(1, 0, 0, 25)
  textLabel.Position = UDim2.fromOffset(0, 8)
  textLabel.Text = "CHAMELEON RADAR"
  textLabel.Font = Enum.Font.GothamBold
  textLabel.TextSize = 14
  textLabel.TextColor3 = Color3.fromRGB(100, 255, 140)
  textLabel.ZIndex = 30
  textLabel.Parent = radar
end

local function f20(key20)
  local radarWorld2, clone

  if not v6 then
    return
  elseif not f1(key20) then
    return
  elseif f9(key20) then
    return
  elseif v13[key20] then
    return
  else
    if not radarViewport then
      return
    end

    radarWorld2 = radarViewport:FindFirstChild("RadarWorld")

    if not radarWorld2 then
      return
    end

    clone = nil

    if not pcall(function()
      clone = key20:Clone()

      for index3, value7 in ipairs(clone:GetDescendants()) do
        if value7:IsA("Script") or value7:IsA("LocalScript") or value7:IsA("ModuleScript") or value7:IsA("BillboardGui") then
          value7:Destroy()
        end
      end

      clone.Anchored = true
      clone.CanCollide = false
      clone.CanTouch = false
      clone.CanQuery = false
      clone.CastShadow = false
      clone.Parent = radarWorld2
    end) or not clone then
      return
    end

    v13[key20] = clone

    if showDistance then
      makeTextLabel(key20)
    end

    return
  end
end

local function f21()
  if not v6 then
    return
  elseif not radarCamera then
    return
  else
    local v32 = f3()

    if not v32 then
      return
    end

    radarCamera.CFrame = CFrame.new(v32.Position + Vector3.new(0, 150, 0), v32.Position)

    for key21 in pairs(v12) do
      if f1(key21) and not v13[key21] and not f9(key21) then
        f20(key21)
      end
    end

    for key22, value8 in pairs(v13) do
      if not f1(key22) or not value8 or not value8.Parent then
        f19(key22)
      elseif f9(key22) then
        f19(key22)
      else
        local magnitude4 = (key22.Position - v32.Position).Magnitude

        if magnitude4 > 120 then
          value8.Transparency = 1
        else
          value8.Transparency = key22.Transparency
          value8.CFrame = key22.CFrame
          value8.Size = key22.Size
        end

        if showDistance then
          if not v10[key22] then
            makeTextLabel(key22)
          end

          local v33 = v10[key22]

          if magnitude4 <= 120 then
            local v34 = math.clamp(
              0.5 + (key22.Position.X - v32.Position.X) / 120 * 0.5, 0.08, 0.92
            )

            local v35 = math.clamp(
              0.5 - (key22.Position.Z - v32.Position.Z) / 120 * 0.5, 0.08, 0.92
            )

            v33.Position = UDim2.fromScale(v34, v35)
            v33.Text = string.format("%.0f studs", magnitude4)
            v33.TextSize = math.clamp(18 - magnitude4 / 120 * 8, 10, 18)
            v33.TextColor3 = color
            v33.Visible = true
          else
            v33.Visible = false
          end
        elseif v10[key22] then
          v10[key22].Visible = false
        end
      end
    end

    return
  end
end

local function f22()
  if not v8 then
    return
  else
    local v36 = f3()

    if not v36 then
      return
    else
      local v37 = f11()
      local v38 = #v37

      if v38 == 0 then
        return
      end

      for index4, value9 in ipairs(v37) do
        f8(value9)
      end

      for index5, value10 in ipairs(v37) do
        local v39 = (index5 - 1) / v38 * math.pi * 2
        local v40 = math.cos(v39)
        local v41 = math.sin(v39)
        local vector = Vector3.new(v40 * 7, 2.5, v41 * 7)
        value10.CFrame = CFrame.lookAt(v36.Position + vector, v36.Position)
      end

      return
    end
  end
end

local function f23()
  if not v8 then
    return
  end

  f22()
end

local function f24(key23)
  if not key23:IsA("BillboardGui") then
    return
  end

  if v16[key23] then
    return
  end

  local v42 = f5(key23)

  if not v42 then
    return
  end

  v15[key23] = v42

  v16[key23] = key23:GetPropertyChangedSignal("Enabled"):Connect(function()
    if not f1(v42) then
      return
    end

    if v3 then
      if f7(v42) then
        f2(v42)
      else
        makeHighlight(v42)
      end
    end

    if v6 then
      if f9(v42) then
        f19(v42)
      elseif not v13[v42] then
        f20(v42)
      end
    end

    if v8 and v9 then
      f23()
    end
  end)
end

local function f25(descendant2)
  v12[descendant2] = nil
  v17[descendant2] = nil
  f2(descendant2)
  f17(descendant2)
  f19(descendant2)
end

local function f26(key24)
  if not f1(key24) then
    return
  end

  if v12[key24] then
    return
  end

  v12[key24] = true
  f8(key24)

  for index6, value11 in ipairs(key24:GetChildren()) do
    if value11:IsA("BillboardGui") then
      f24(value11)
    end
  end
end

if characters then
  for index7, value12 in ipairs(characters:GetDescendants()) do
    if value12:IsA("MeshPart") then
      f26(value12)
    elseif value12:IsA("BillboardGui") then
      f24(value12)
    end
  end

  characters.DescendantAdded:Connect(function(descendant3)
    local v43

    if descendant3:IsA("MeshPart") then
      f26(descendant3)

      if v3 then
        makeHighlight(descendant3)
      end

      if v8 then
        task.defer(function()
          f8(descendant3)
          f22()
        end)
      end
    elseif descendant3:IsA("BillboardGui") then
      f24(descendant3)
      v43 = f5(descendant3)

      if v43 then
        v15[descendant3] = v43

        task.defer(function()
          if v3 then
            if f7(v43) then
              f2(v43)
            else
              makeHighlight(v43)
            end
          end

          if v8 and v9 then
            f23()
          end
        end)
      end
    end
  end)

  characters.DescendantRemoving:Connect(function(descendant4)
    if descendant4:IsA("MeshPart") then
      f25(descendant4)
    elseif descendant4:IsA("BillboardGui") then
      local v44 = v15[descendant4]
      local v45 = v16[descendant4]

      if v45 then
        v45:Disconnect()
      end

      v16[descendant4] = nil
      v15[descendant4] = nil

      if v44 and f1(v44) then
        if v3 and not f7(v44) then
          makeHighlight(v44)
        end

        if v6 and not f9(v44) then
          f20(v44)
        end

        if v8 then
          f23()
        end
      end
    end
  end)
end

local function f27()
  for key25, value13 in pairs(v1) do
    if value13 then
      value13.FillColor = color
      value13.OutlineColor = color
    end
  end

  for key26, value14 in pairs(v14) do
    if value14.Label then
      value14.Label.TextColor3 = color
    end
  end

  for key27, value15 in pairs(v10) do
    if value15 then
      value15.TextColor3 = color
    end
  end
end

runService.Heartbeat:Connect(function(delta)
  v11 = v11 + delta

  if v11 < 0.05 then
    return
  end

  v11 = 0

  if v3 and v5 then
    f18()
  end

  if v6 then
    f21()
  end
end)

mainTab:CreateSection("ESP")

mainTab:CreateToggle({
  Name = "ESP All Chameleons",
  CurrentValue = false,
  Flag = "ESPAllChameleons",
  Callback = function(value16)
    v3 = value16
    f16()

    if not value16 then
      for key28, value17 in pairs(v14) do
        value17.Billboard.Enabled = false
      end
    end
  end,
})

mainTab:CreateToggle({
  Name = "Filter Those Found",
  CurrentValue = false,
  Flag = "FilterThoseFound",
  Callback = function(value18)
    v4 = value18
    f16()

    if v5 then
      f18()
    end
  end,
})

mainTab:CreateToggle({
  Name = "Show ESP Distance",
  CurrentValue = false,
  Flag = "ShowESPDistance",
  Callback = function(value19)
    v5 = value19

    if not value19 then
      for key29, value20 in pairs(v14) do
        value20.Billboard.Enabled = false
      end
    end
  end,
})

mainTab:CreateColorPicker({
  Name = "ESP Color",
  Color = color,
  Flag = "ESPColor",
  Callback = function(value21)
    color = value21
    f27()
  end,
})

mainTab:CreateSection("Radar ESP")

mainTab:CreateToggle({
  Name = "Radar All Chameleons",
  CurrentValue = false,
  Flag = "RadarAllChameleons",
  Callback = function(value22)
    v6 = value22

    if v6 then
      makeTextLabel3()

      for key30 in pairs(v12) do
        if f1(key30) and not f9(key30) then
          f20(key30)
        end
      end
    else
      f4()
    end
  end,
})

mainTab:CreateToggle({
  Name = "Filter Radar Those Found",
  CurrentValue = false,
  Flag = "FilterRadarThoseFound",
  Callback = function(value23)
    v7 = value23

    if not v6 then
      return
    end

    for key31 in pairs(v13) do
      if f9(key31) then
        f19(key31)
      end
    end
  end,
})

mainTab:CreateToggle({
  Name = "Show Distance",
  CurrentValue = false,
  Flag = "ShowRadarDistance",
  Callback = function(value24)
    showDistance = value24

    if not value24 then
      for key32, value25 in pairs(v10) do
        value25.Visible = false
      end
    end
  end,
})

teleportTab:CreateSection("Teleport Chameleons to Player")

teleportTab:CreateToggle({
  Name = "Teleport Chameleons to Player",
  CurrentValue = false,
  Flag = "TeleportChameleonsToPlayer",
  Callback = function(value26)
    v8 = value26

    if v8 then
      for key33 in pairs(v12) do
        if f1(key33) then
          f8(key33)
        end
      end

      f22()
    else
      f15()
    end
  end,
})

teleportTab:CreateSection("Teleport to Chameleon")

teleportTab:CreateButton({
  Name = "Teleport to Closest",
  Callback = function()
    local v46 = f12()

    if not v46 then
      return
    end

    f14(v46)
  end,
})

teleportTab:CreateButton({
  Name = "Teleport Random Chameleon",
  Callback = function()
    local v47 = f11()

    if #v47 == 0 then
      return
    end

    f14(v47[math.random(1, #v47)])
  end,
})

teleportTab:CreateDropdown({
  Name = "Under",
  Options = { "Easy", "Normal", "Hard", "Legendary", "Mythic" },
  CurrentOption = { "Easy" },
  MultipleOptions = false,
  Flag = "SelectedChameleonRarity",
  Callback = function(value27)
    local v48

    if typeof(value27) == "table" then
      v48 = value27[1]
    else
      v48 = value27
    end

    if v48 == "Easy" then
      under = 1
    elseif v48 == "Normal" then
      under = 2
    elseif v48 == "Hard" then
      under = 3
    elseif v48 == "Legendary" then
      under = 4
    elseif v48 == "Mythic" then
      under = 5
    end
  end,
})

teleportTab:CreateButton({
  Name = "Teleport Selected Rarity",
  Callback = function()
    local v49 = f13(under)

    if not v49 then
      return
    end

    f14(v49)
  end,
})

teleportTab:CreateSection("Main")

teleportTab:CreateToggle({
  Name = "Filter Those Found",
  CurrentValue = false,
  Flag = "TeleportFilterThoseFound",
  Callback = function(value28)
    v9 = value28

    if v8 then
      f22()
    end
  end,
})