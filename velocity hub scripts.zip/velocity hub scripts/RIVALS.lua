-- FUCKED BY MEDALWARE LEARN TO CODE RIGHT YALL

local players = game:GetService("Players")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local lighting = game:GetService("Lighting")
local currentCamera = workspace.CurrentCamera
local localPlayer = players.LocalPlayer
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local verifyKey = true

local keySYSTEMWindow = rayfield:CreateWindow({
  Name = "KEY SYSTEM",
  LoadingTitle = "Authentication",
  LoadingSubtitle = "Enter Key",
  ConfigurationSaving = { Enabled = false },
})

local keyTab = keySYSTEMWindow:CreateTab("KEY", 4483362458)

keyTab:CreateButton({
  Name = "📋Copy Key Link",
  Callback = function()
    setclipboard("https://discord.com/invite/aGCBvr2zf9")
    rayfield:Notify({ Title = "Copied📋", Content = "Discord link copied!", Duration = 3 })
  end,
})

local key = ""

keyTab:CreateInput({
  Name = "🔑KEY",
  PlaceholderText = "🖊️Write Key",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) key = value end,
})

keyTab:CreateButton({
  Name = "✅Verify Key",
  Callback = function()
    if key == "VELOCITY_2026" then
      verifyKey = true
      keySYSTEMWindow:Destroy()
    else
      rayfield:Notify({ Title = "😭Error", Content = "❌Wrong Key", Duration = 3 })
    end
  end,
})

repeat
  task.wait()
until verifyKey

local window = rayfield:CreateWindow({
  Name = "Velocity HUB | Rivals🔫",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "Pls Follow And Like :)",
  ConfigurationSaving = { Enabled = false },
})

local mainTab = window:CreateTab("Main", 4483362458)
mainTab:CreateSection("Aim Assist")

local aimAssist = false
local aimSmoothness = 0.15
local aimPart = "Head"
local triggerBot = false
local v1 = "Head"

local circle = Drawing.new("Circle")
circle.Visible = false
circle.Radius = 150
circle.Color = Color3.fromRGB(255, 255, 255)
circle.Thickness = 1
circle.Filled = false
circle.NumSides = 100

local raycastParams = RaycastParams.new()
raycastParams.FilterType = Enum.RaycastFilterType.Blacklist

local f1

local function f2(p1)
  if not p1 then
    return false
  else
    local parent = p1.Parent

    if not parent then
      return false
    else
      local humanoid = parent:FindFirstChild("Humanoid")

      if not humanoid or humanoid.Health <= 0 then
        return false
      elseif not f1(p1, parent) then
        return false
      else
        local v2, v3 = currentCamera:WorldToViewportPoint(p1.Position)

        if not v3 then
          return false
        else
          local vector = Vector2.new(
            currentCamera.ViewportSize.X / 2, currentCamera.ViewportSize.Y / 2
          )

          if (Vector2.new(v2.X, v2.Y) - vector).Magnitude > circle.Radius then
            return false
          end

          return true
        end
      end
    end
  end
end

function f1(p2, p3)
  if not p2 or not p3 then
    return false
  else
    raycastParams.FilterDescendantsInstances = { localPlayer.Character, p3 }
    local position = currentCamera.CFrame.Position
    return workspace:Raycast(position, p2.Position - position, raycastParams) == nil
  end
end

local f3

local function f4()
  local viewportSize = currentCamera.ViewportSize
  local vector2 = Vector2.new(viewportSize.X / 2, viewportSize.Y / 2)
  local huge = math.huge
  local v4

  for index, value2 in ipairs(players:GetPlayers()) do
    if value2 ~= localPlayer and value2.Character then
      local character = value2.Character
      local humanoid2 = character:FindFirstChild("Humanoid")

      if humanoid2 and humanoid2.Health > 0 then
        local v5 = f3(character, aimPart)

        if v5 then
          local v6, v7 = currentCamera:WorldToViewportPoint(v5.Position)

          if v7 then
            local magnitude = (Vector2.new(v6.X, v6.Y) - vector2).Magnitude

            if magnitude <= circle.Radius then
              if f1(v5, character) then
                if magnitude < huge then
                  huge = magnitude
                  v4 = v5
                end
              end
            end
          end
        end
      end
    end
  end

  return v4
end

function f3(p4, p5)
  if p5 == "Torso" then
    return p4:FindFirstChild("UpperTorso") or p4:FindFirstChild("Torso")
  end

  if p5 == "Leg" then
    return p4:FindFirstChild("LeftLowerLeg") or p4:FindFirstChild("Left Leg")
  end

  return p4:FindFirstChild("Head")
end

local v8

mainTab:CreateToggle({
  Name = "Aim Assist",
  CurrentValue = false,
  Callback = function(value3)
    aimAssist = value3
    circle.Visible = value3

    if not value3 then
      v8 = nil
    end
  end,
})

mainTab:CreateSlider({
  Name = "Aim Smoothness",
  Range = { 0.05, 1 },
  Increment = 0.05,
  CurrentValue = 0.15,
  Callback = function(value4) aimSmoothness = value4 end,
})

mainTab:CreateDropdown({
  Name = "Aim Part",
  Options = { "Head", "Torso", "Leg" },
  CurrentOption = { "Head" },
  Callback = function(value5) aimPart = value5[1] end,
})

mainTab:CreateSection("Trigger Bot")

mainTab:CreateToggle({
  Name = "Trigger Bot",
  CurrentValue = false,
  Callback = function(value6) triggerBot = value6 end,
})

mainTab:CreateDropdown({
  Name = "Trigger Bot Body Part",
  Options = { "Head", "Torso", "Leg" },
  CurrentOption = { "Head" },
  Callback = function(value7) v1 = value7[1] end,
})

runService.RenderStepped:Connect(function()
  circle.Position = Vector2.new(
    currentCamera.ViewportSize.X / 2, currentCamera.ViewportSize.Y / 2
  )

  if not f2(v8) then
    v8 = f4()
  end

  local v9

  if aimAssist and v8 then
    local position2 = v8.Position

    if aimPart == "Leg" then
      v9 = position2 + Vector3.new(0, -0.5, 0)
    elseif aimPart == "Torso" then
      v9 = position2 + Vector3.new(0, 0.1, 0)
    else
      v9 = position2 + Vector3.new(0, 0.15, 0)
    end

    local cframe = CFrame.new(currentCamera.CFrame.Position, v9)
    currentCamera.CFrame = currentCamera.CFrame:Lerp(cframe, math.clamp(aimSmoothness, 0.01, 1))
    local character2 = localPlayer.Character

    if character2 then
      local humanoidRootPart = character2:FindFirstChild("HumanoidRootPart")

      if humanoidRootPart then
        humanoidRootPart.CFrame = CFrame.lookAt(humanoidRootPart.Position, humanoidRootPart.Position
          + currentCamera.CFrame.LookVector)
      end
    end
  end

  if triggerBot and v8 then
    local v10 = f3(v8.Parent, v1)

    if v10 and f1(v10, v10.Parent) then
      local v11, v12 = currentCamera:WorldToViewportPoint(v10.Position)

      if v12 then
        local vector3 = Vector2.new(
          currentCamera.ViewportSize.X / 2, currentCamera.ViewportSize.Y / 2
        )

        if (Vector2.new(v11.X, v11.Y) - vector3).Magnitude <= 6 then
          if mouse1press and mouse1release then
            mouse1press()
            task.wait(0.01)
            mouse1release()
          elseif mouse1click then
            mouse1click()
          end
        end
      end
    end
  end
end)

local localPlayer2 = players.LocalPlayer
local currentCamera2 = workspace.CurrentCamera

local espTab = window:CreateTab("ESP", 4483362458)
espTab:CreateSection("ESP Settings")

local getPlayers = players.GetPlayers
local highlightESP = false
local nameESP = false
local healthESP = false
local skeletonESP = false
local rgb = false
local color = Color3.fromRGB(0, 255, 0)
local v13 = {}
local v14 = {}

task.spawn(function()
  while true do
    task.wait()

    if rgb then
      local v15 = tick()
      color = Color3.fromHSV(v15 % 5 / 5, 1, 1)
    end
  end
end)

local function f5(p6)
  if p6 <= 25 then
    return Color3.fromRGB(255, 60, 60)
  end

  if p6 <= 50 then
    return Color3.fromRGB(255, 170, 0)
  end

  return Color3.fromRGB(0, 255, 100)
end

local function f6()
  local line = Drawing.new("Line")
  line.Visible = false
  line.Thickness = 1.5
  line.Transparency = 1

  return line
end

local f7

local function makeTextLabel(key2)
  f7(key2)
  local highlight, nameESP2, textLabel, healthESP2, textLabel2, frame, connect

  if key2 == localPlayer2 then
    return
  else
    local character3 = key2.Character

    if not character3 then
      return
    else
      local humanoid3 = character3:FindFirstChildOfClass("Humanoid")
      local head = character3:FindFirstChild("Head")
      local v16 = not humanoid3
      local humanoidRootPart2 = character3:FindFirstChild("HumanoidRootPart")

      if v16 or not head or not humanoidRootPart2 then
        return
      else
        v13[key2] = {}

        highlight = Instance.new("Highlight")
        highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
        highlight.FillTransparency = 0.65
        highlight.OutlineTransparency = 0
        highlight.FillColor = color
        highlight.OutlineColor = color
        highlight.Enabled = highlightESP
        highlight.Parent = character3

        v13[key2].Highlight = highlight

        nameESP2 = Instance.new("BillboardGui")
        nameESP2.Name = "NameESP"
        nameESP2.Size = UDim2.new(0, 70, 0, 18)
        nameESP2.StudsOffset = Vector3.new(0, 2.2, 0)
        nameESP2.AlwaysOnTop = true
        nameESP2.Enabled = nameESP
        nameESP2.Parent = head

        textLabel = Instance.new("TextLabel")
        textLabel.BackgroundTransparency = 1
        textLabel.Size = UDim2.new(1, 0, 1, 0)
        textLabel.Font = Enum.Font.GothamBold
        textLabel.TextScaled = true
        textLabel.TextStrokeTransparency = 0
        textLabel.Text = key2.Name
        textLabel.TextColor3 = color
        textLabel.Parent = nameESP2

        v13[key2].NameGui = nameESP2
        v13[key2].NameText = textLabel

        healthESP2 = Instance.new("BillboardGui")
        healthESP2.Name = "HealthESP"
        healthESP2.Size = UDim2.new(0, 35, 0, 60)
        healthESP2.StudsOffset = Vector3.new(2.5, 0, 0)
        healthESP2.AlwaysOnTop = true
        healthESP2.Enabled = healthESP
        healthESP2.Parent = humanoidRootPart2

        textLabel2 = Instance.new("TextLabel")
        textLabel2.BackgroundTransparency = 1
        textLabel2.Size = UDim2.new(1, 0, 0, 14)
        textLabel2.Position = UDim2.new(0, 0, 0, -12)
        textLabel2.Font = Enum.Font.GothamBold
        textLabel2.TextScaled = true
        textLabel2.TextStrokeTransparency = 0
        textLabel2.TextColor3 = Color3.new(1, 1, 1)
        textLabel2.Parent = healthESP2

        local frame2 = Instance.new("Frame")
        frame2.AnchorPoint = Vector2.new(0.5, 0)
        frame2.Position = UDim2.new(0.5, 0, 0, 0)
        frame2.Size = UDim2.new(0, 6, 1, -10)
        frame2.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
        frame2.BorderSizePixel = 0
        frame2.Parent = healthESP2

        frame = Instance.new("Frame")
        frame.AnchorPoint = Vector2.new(0, 1)
        frame.Position = UDim2.new(0, 0, 1, 0)
        frame.Size = UDim2.new(1, 0, 1, 0)
        frame.BorderSizePixel = 0
        frame.BackgroundColor3 = Color3.fromRGB(0, 255, 100)
        frame.Parent = frame2

        v13[key2].HealthGui = healthESP2
        v13[key2].HealthBar = frame
        v13[key2].PercentText = textLabel2

        connect = nil

        connect = runService.RenderStepped:Connect(function()
          if not key2.Parent then
            connect:Disconnect()
            f7(key2)
            return
          else
            local character4 = key2.Character

            if not character4 or not character4.Parent then
              highlight.Enabled = false
              nameESP2.Enabled = false
              healthESP2.Enabled = false
              return
            else
              local humanoid4 = character4:FindFirstChildOfClass("Humanoid")
              local head2 = character4:FindFirstChild("Head")
              local v17 = not humanoid4
              local humanoidRootPart3 = character4:FindFirstChild("HumanoidRootPart")

              if v17 or not head2 or not humanoidRootPart3 then
                highlight.Enabled = false
                nameESP2.Enabled = false
                healthESP2.Enabled = false
                return
              else
                highlight.Enabled = highlightESP
                nameESP2.Enabled = nameESP
                healthESP2.Enabled = healthESP

                if highlight.Parent ~= character4 then
                  highlight.Parent = character4
                end

                if nameESP2.Parent ~= head2 then
                  nameESP2.Parent = head2
                end

                if healthESP2.Parent ~= humanoidRootPart3 then
                  healthESP2.Parent = humanoidRootPart3
                end

                highlight.FillColor = color
                highlight.OutlineColor = color

                textLabel.TextColor3 = color
                local health = humanoid4.Health
                local maxHealth = humanoid4.MaxHealth

                local v18 = math.clamp(
                  health / (maxHealth > 0 and maxHealth or 100) * 100, 0, 100
                )

                frame.Size = UDim2.new(1, 0, v18 / 100, 0)
                frame.BackgroundColor3 = f5(v18)

                textLabel2.Text = math.floor(v18) .. "%"
                return
              end
            end
          end
        end)

        v13[key2].Connection = connect
        return
      end
    end
  end
end
local function f8(key3)
  if key3 == localPlayer2 then
    return
  end

  v14[key3] = {}

  for i = 1, 15 do
    table.insert(v14[key3], f6())
  end
end

function f7(key4)
  if v13[key4] then
    if v13[key4].Connection then
      v13[key4].Connection:Disconnect()
    end

    for key5, value8 in pairs(v13[key4]) do
      if typeof(value8) == "Instance" then
        value8:Destroy()
      end
    end

    v13[key4] = nil
  end

  if v14[key4] then
    for key6, value9 in pairs(v14[key4]) do
      local v19 = value9

      pcall(function()
        v19.Visible = false
        v19:Remove()
      end)
    end

    v14[key4] = nil
  end
end

local function f9(p7, character5)
  if p7 == localPlayer2 then
    return
  else
    local waitForChild = character5:WaitForChild("Humanoid", 5)
    local waitForChild2 = character5:WaitForChild("Head", 5)
    local v20 = not waitForChild
    local waitForChild3 = character5:WaitForChild("HumanoidRootPart", 5)

    if v20 or not waitForChild2 or not waitForChild3 then
      return
    end

    task.wait(0.3)
    makeTextLabel(p7)
    f8(p7)

    character5.ChildAdded:Connect(function(child)
      if child.Name == "HumanoidRootPart" or child.Name == "Head" then
        task.wait(0.2)
        makeTextLabel(p7)
        f8(p7)
      end
    end)

    return
  end
end

local function f10(p8)
  if p8 == localPlayer2 then
    return
  end

  p8.CharacterAdded:Connect(function(character6) f9(p8, character6) end)

  if p8.Character then
    task.spawn(function() f9(p8, p8.Character) end)
  end
end

for index2, value10 in ipairs(getPlayers(players)) do
  f10(value10)
end

players.PlayerAdded:Connect(function(player) f10(player) end)
players.PlayerRemoving:Connect(function(player2) f7(player2) end)

runService.RenderStepped:Connect(function()
  for key7, value11 in pairs(v14) do
    local character7 = key7.Character

    if not character7 or not character7.Parent or not skeletonESP then
      for key8, value12 in pairs(value11) do
        value12.Visible = false
      end
    else
      local humanoid5 = character7:FindFirstChildOfClass("Humanoid")

      if not humanoid5 or humanoid5.Health <= 0 then
        for key9, value13 in pairs(value11) do
          value13.Visible = false
        end
      else
        local v21 = {
          Head = character7:FindFirstChild("Head"),
          UpperTorso = character7:FindFirstChild("UpperTorso"),
          LowerTorso = character7:FindFirstChild("LowerTorso"),
          LeftUpperArm = character7:FindFirstChild("LeftUpperArm"),
          LeftLowerArm = character7:FindFirstChild("LeftLowerArm"),
          LeftHand = character7:FindFirstChild("LeftHand"),
          RightUpperArm = character7:FindFirstChild("RightUpperArm"),
          RightLowerArm = character7:FindFirstChild("RightLowerArm"),
          RightHand = character7:FindFirstChild("RightHand"),
          LeftUpperLeg = character7:FindFirstChild("LeftUpperLeg"),
          LeftLowerLeg = character7:FindFirstChild("LeftLowerLeg"),
          LeftFoot = character7:FindFirstChild("LeftFoot"),
          RightUpperLeg = character7:FindFirstChild("RightUpperLeg"),
          RightLowerLeg = character7:FindFirstChild("RightLowerLeg"),
          RightFoot = character7:FindFirstChild("RightFoot"),
        }

        for key10, value14 in pairs({
          { "Head", "UpperTorso" }, { "UpperTorso", "LowerTorso" },
          { "UpperTorso", "LeftUpperArm" }, { "LeftUpperArm", "LeftLowerArm" },
          { "LeftLowerArm", "LeftHand" }, { "UpperTorso", "RightUpperArm" },
          { "RightUpperArm", "RightLowerArm" }, { "RightLowerArm", "RightHand" },
          { "LowerTorso", "LeftUpperLeg" }, { "LeftUpperLeg", "LeftLowerLeg" },
          { "LeftLowerLeg", "LeftFoot" }, { "LowerTorso", "RightUpperLeg" },
          { "RightUpperLeg", "RightLowerLeg" }, { "RightLowerLeg", "RightFoot" },
        }) do
          local v22 = v21[value14[1]]
          local v23 = v21[value14[2]]
          local v24 = value11[key10]

          if v22 and v23 then
            local v25, v26 = currentCamera2:WorldToViewportPoint(v22.Position)
            local v27, v28 = currentCamera2:WorldToViewportPoint(v23.Position)

            if v26 and v28 then
              v24.From = Vector2.new(v25.X, v25.Y)
              v24.To = Vector2.new(v27.X, v27.Y)
              v24.Color = color
              v24.Visible = true
            else
              v24.Visible = false
            end
          else
            v24.Visible = false
          end
        end
      end
    end
  end
end)

espTab:CreateToggle({
  Name = "Highlight ESP",
  CurrentValue = false,
  Flag = "HighlightESP",
  Callback = function(value15)
    highlightESP = value15

    for key11, value16 in pairs(v13) do
      if value16.Highlight then
        value16.Highlight.Enabled = value15
      end
    end
  end,
})

espTab:CreateToggle({
  Name = "Name ESP",
  CurrentValue = false,
  Flag = "NameESP",
  Callback = function(value17)
    nameESP = value17

    for key12, value18 in pairs(v13) do
      if value18.NameGui then
        value18.NameGui.Enabled = value17
      end
    end
  end,
})

espTab:CreateToggle({
  Name = "Health ESP",
  CurrentValue = false,
  Flag = "HealthESP",
  Callback = function(value19)
    healthESP = value19

    for key13, value20 in pairs(v13) do
      if value20.HealthGui then
        value20.HealthGui.Enabled = value19
      end
    end
  end,
})

espTab:CreateToggle({
  Name = "Skeleton ESP",
  CurrentValue = false,
  Flag = "SkeletonESP",
  Callback = function(value21)
    skeletonESP = value21

    if not value21 then
      for key14, value22 in pairs(v14) do
        for key15, value23 in pairs(value22) do
          value23.Visible = false
        end
      end
    end
  end,
})

espTab:CreateSection("ESP Color Picker")

espTab:CreateColorPicker({
  Name = "ESP Color",
  Color = Color3.fromRGB(0, 255, 0),
  Flag = "ESPColor",
  Callback = function(value24) color = value24 end,
})

espTab:CreateToggle({
  Name = "RGB",
  CurrentValue = false,
  Flag = "RGBESP",
  Callback = function(value25) rgb = value25 end,
})

local playerTab = window:CreateTab("Player", 4483362458)
local localPlayer3 = players.LocalPlayer
local fly = false
local flySpeed = 50
local infiniteJump = false
local spin = false
local spinSpeed = 50
local noClip = false
playerTab:CreateSection("Fly")
local bodyVelocity, bodyGyro

local function makeBodyVelocity()
  local character8 = localPlayer3.Character

  if not character8 then
    return
  else
    local humanoidRootPart4 = character8:FindFirstChild("HumanoidRootPart")

    if not humanoidRootPart4 then
      return
    else
      local humanoid6 = character8:FindFirstChildOfClass("Humanoid")

      if humanoid6 then
        humanoid6.PlatformStand = false
      end

      bodyVelocity = Instance.new("BodyVelocity")
      bodyVelocity.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
      bodyVelocity.Velocity = Vector3.zero
      bodyVelocity.Parent = humanoidRootPart4

      bodyGyro = Instance.new("BodyGyro")
      bodyGyro.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
      bodyGyro.P = 10000
      bodyGyro.D = 100
      bodyGyro.CFrame = workspace.CurrentCamera.CFrame
      bodyGyro.Parent = humanoidRootPart4

      return
    end
  end
end

local function f11()
  if bodyVelocity then
    bodyVelocity:Destroy()
    bodyVelocity = nil
  end

  if bodyGyro then
    bodyGyro:Destroy()
    bodyGyro = nil
  end
end

runService.RenderStepped:Connect(function()
  local character9 = localPlayer3.Character

  if not character9 then
    return
  else
    local humanoidRootPart5 = character9:FindFirstChild("HumanoidRootPart")

    if not humanoidRootPart5 then
      return
    end

    if noClip then
      for key16, value26 in pairs(character9:GetDescendants()) do
        if value26:IsA("BasePart") then
          value26.CanCollide = false
        end
      end
    end

    if spin then
      humanoidRootPart5.CFrame = humanoidRootPart5.CFrame
        * CFrame.Angles(0, math.rad(spinSpeed), 0)
    end

    if fly and bodyVelocity and bodyGyro then
      local currentCamera3 = workspace.CurrentCamera
      local zero = Vector3.zero

      if userInputService:IsKeyDown(Enum.KeyCode.W) then
        zero = zero + currentCamera3.CFrame.LookVector
      end

      if userInputService:IsKeyDown(Enum.KeyCode.S) then
        zero = zero - currentCamera3.CFrame.LookVector
      end

      if userInputService:IsKeyDown(Enum.KeyCode.A) then
        zero = zero - currentCamera3.CFrame.RightVector
      end

      if userInputService:IsKeyDown(Enum.KeyCode.D) then
        zero = zero + currentCamera3.CFrame.RightVector
      end

      if userInputService:IsKeyDown(Enum.KeyCode.Space) then
        zero = zero + Vector3.new(0, 1, 0)
      end

      if userInputService:IsKeyDown(Enum.KeyCode.LeftShift) then
        zero = zero - Vector3.new(0, 1, 0)
      end

      if zero.Magnitude > 0 then
        bodyVelocity.Velocity = zero.Unit * flySpeed
      else
        bodyVelocity.Velocity = Vector3.zero
      end

      bodyGyro.CFrame = currentCamera3.CFrame
    end

    return
  end
end)

playerTab:CreateToggle({
  Name = "Fly",
  CurrentValue = false,
  Flag = "FlyToggle",
  Callback = function(value27)
    fly = value27

    if value27 then
      makeBodyVelocity()
    else
      f11()
    end
  end,
})

playerTab:CreateSlider({
  Name = "Fly Speed",
  Range = { 10, 200 },
  Increment = 5,
  CurrentValue = 50,
  Flag = "FlySpeed",
  Callback = function(value28) flySpeed = value28 end,
})

playerTab:CreateSection("No Clip")

playerTab:CreateToggle({
  Name = "No Clip",
  CurrentValue = false,
  Flag = "NoClip",
  Callback = function(value29) noClip = value29 end,
})

playerTab:CreateSection("Infinite Jump")

userInputService.JumpRequest:Connect(function()
  if infiniteJump then
    local character10 = localPlayer3.Character

    if not character10 then
      return
    end

    local humanoid7 = character10:FindFirstChildOfClass("Humanoid")

    if humanoid7 then
      humanoid7:ChangeState(Enum.HumanoidStateType.Jumping)
    end

    return
  end
end)

playerTab:CreateToggle({
  Name = "Infinite Jump",
  CurrentValue = false,
  Flag = "InfiniteJump",
  Callback = function(value30) infiniteJump = value30 end,
})

playerTab:CreateSection("Spin")

playerTab:CreateToggle({
  Name = "Spin",
  CurrentValue = false,
  Flag = "SpinToggle",
  Callback = function(value31) spin = value31 end,
})

playerTab:CreateSlider({
  Name = "Spin Speed",
  Range = { 1, 300 },
  Increment = 1,
  CurrentValue = 50,
  Flag = "SpinSpeed",
  Callback = function(value32) spinSpeed = value32 end,
})

local function f12(value33)
  if value33 then
    for key17, value34 in pairs(lighting:GetDescendants()) do
      if value34:IsA("PostEffect") or value34:IsA("BloomEffect") or value34:IsA("BlurEffect")
        or value34:IsA("SunRaysEffect") or value34:IsA("ColorCorrectionEffect") then
        value34.Enabled = false
      end
    end

    settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
  else
    for key18, value35 in pairs(lighting:GetDescendants()) do
      if value35:IsA("PostEffect") then
        value35.Enabled = true
      end
    end
  end
end

playerTab:CreateSection("Performance")
local v29 = true

local function f13()
  local currentCamera4 = workspace.CurrentCamera

  if not currentCamera4 then
    return
  end

  runService:BindToRenderStep("NoCameraShake", 1000, function()
    if not v29 then
      currentCamera4.CFrame = currentCamera4.CFrame
    end
  end)
end

playerTab:CreateToggle({
  Name = "Disable Camera Shake",
  CurrentValue = false,
  Callback = function(value36)
    v29 = not value36

    if value36 then
      f13()
    end
  end,
})

playerTab:CreateToggle({
  Name = "Anti Lag (FPS Boost)",
  CurrentValue = false,
  Callback = function(value37) f12(value37) end,
})


