-- FUCKED BY MEDALWARE XDDD SHITTY WEAK LEGACY SCRIPT

local runService = game:GetService("RunService")
local teleportService = game:GetService("TeleportService")
local httpService = game:GetService("HttpService")
local workspaceService = game:GetService("Workspace")
local players = game:GetService("Players")
local localPlayer = players.LocalPlayer
local placeId = game.PlaceId
local character = localPlayer.Character or localPlayer.CharacterAdded:Wait()
local humanoidRootPart = character:WaitForChild("HumanoidRootPart")

localPlayer.CharacterAdded:Connect(function(character2)
  character = character2
  humanoidRootPart = character2:WaitForChild("HumanoidRootPart")
end)

local eventTab = loadstring(game:HttpGet("https://sirius.menu/rayfield"))():CreateWindow({
  Name = "VelocityHUB | Weak Legacy 2 Event Script",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "Pls Like and Follow",
  ConfigurationSaving = { Enabled = false },
}):CreateTab(
  "Event", 88825541002931
)

local gifts = workspaceService:WaitForChild("Map"):WaitForChild("Gifts")
local v1 = false
local v2 = false
local v3 = false
local color = Color3.fromRGB(255, 0, 0)

local function f1()
  local humanoid = character and character:FindFirstChildOfClass("Humanoid")

  if humanoid then
    humanoid.WalkSpeed = 0
    humanoid.JumpPower = 0
    humanoid.AutoRotate = false
  end
end

local color2 = color

local function f2(p1)
  local gift = p1:FindFirstChild("Gift")

  if gift and gift:IsA("MeshPart") then
    return gift
  end
end

local function f3(p2)
  for index, value in ipairs(p2:GetDescendants()) do
    if value:IsA("ProximityPrompt") then
      return value
    end
  end
end

local v4 = {}

local function f4(key)
  if v4[key] then
    v4[key].Gui:Destroy()
    v4[key] = nil
  end
end

local function f5()
  local humanoid2 = character and character:FindFirstChildOfClass("Humanoid")

  if humanoid2 then
    humanoid2.WalkSpeed = 16
    humanoid2.JumpPower = 50
    humanoid2.AutoRotate = true
  end
end

local function makeTextLabel(value2)
  if v4[value2] then
    return
  else
    local v5 = f2(value2)

    if not v5 then
      return
    else
      local giftESP = Instance.new("BillboardGui")
      giftESP.Name = "GiftESP"
      giftESP.Size = UDim2.fromOffset(220, 60)
      giftESP.AlwaysOnTop = true
      giftESP.Adornee = v5
      giftESP.Parent = localPlayer:WaitForChild("PlayerGui")

      local textLabel = Instance.new("TextLabel")
      textLabel.Size = UDim2.fromScale(1, 1)
      textLabel.BackgroundTransparency = 1
      textLabel.TextStrokeTransparency = 0
      textLabel.TextScaled = true
      textLabel.Font = Enum.Font.SourceSansBold
      textLabel.Parent = giftESP

      v4[value2] = { Gui = giftESP, Text = textLabel, Mesh = v5 }
      return
    end
  end
end

runService.RenderStepped:Connect(function()
  if not v2 then
    return
  end

  for key2, value3 in pairs(v4) do
    if value3.Mesh then
      value3.Text.Text = ([[
Gift Box
%d studs]]):format((humanoidRootPart.Position
        - value3.Mesh.Position).Magnitude)

      value3.Text.TextColor3 = color2
    end
  end
end)

local cframe, f6

local function f7()
  for index2, value4 in ipairs(gifts:GetChildren()) do
    if v1 then
      f6(value4)
    end
  end

-- https://discord.gg/AwGHNh7Z7T
  if v1 and cframe then
    humanoidRootPart.CFrame = cframe
  end

  f5()
end

function f6(p3)
  if not v1 then
    return
  else
    local v6 = f2(p3)
    local v7 = f3(p3)

    if not v6 or not v7 then
      return
    end

    humanoidRootPart.CFrame = CFrame.new(v6.Position + Vector3.new(0, v6.Size.Y / 7 + 7, 0))
    task.wait(0.3)
    v7:InputHoldBegin()
    task.wait(2)
    v7:InputHoldEnd()
    task.wait(0.4)
    return
  end
end

local function f8(value5)
  if v2 then
    makeTextLabel(value5)
  end

  if v1 then
    task.spawn(function()
      task.wait(0.5)
      f6(value5)
    end)
  end
end

gifts.ChildAdded:Connect(f8)

local function f9()
  for index3, value6 in ipairs(httpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"
    .. placeId .. "/servers/Public?sortOrder=Asc&limit=100")).data) do
    if value6.playing < value6.maxPlayers then
      teleportService:TeleportToPlaceInstance(placeId, value6.id, localPlayer)
      break
    end
  end
end

task.spawn(function()
  while task.wait(5) do
    if v3 and #gifts:GetChildren() == 0 then
      f9()
    end
  end
end)

eventTab:CreateToggle({
  Name = "Auto Collect Gift Box",
  CurrentValue = false,
  Callback = function(value7)
    v1 = value7

    if value7 then
      cframe = humanoidRootPart.CFrame
      f1()
      task.spawn(f7)
    end
  end,
})

eventTab:CreateToggle({
  Name = "ESP Gift Box",
  CurrentValue = false,
  Callback = function(value8)
    v2 = value8

    if value8 then
      for index4, value9 in ipairs(gifts:GetChildren()) do
        makeTextLabel(value9)
      end
    else
      for key3, value10 in pairs(v4) do
        f4(key3)
      end
    end
  end,
})

eventTab:CreateToggle({
  Name = "Hop Server If No Gift Box",
  CurrentValue = false,
  Callback = function(value11) v3 = value11 end,
})

eventTab:CreateSlider({
  Name = "Red",
  Range = { 0, 255 },
  Increment = 1,
  CurrentValue = 255,
  Callback = function(value12)
    color2 = Color3.fromRGB(value12, color2.G * 255, color2.B * 255)
  end,
})

eventTab:CreateSlider({
  Name = "Green",
  Range = { 0, 255 },
  Increment = 1,
  CurrentValue = 0,
  Callback = function(value13)
    color2 = Color3.fromRGB(color2.R * 255, value13, color2.B * 255)
  end,
})

eventTab:CreateSlider({
  Name = "Blue",
  Range = { 0, 255 },
  Increment = 1,
  CurrentValue = 0,
  Callback = function(value14)
    color2 = Color3.fromRGB(color2.R * 255, color2.G * 255, value14)
  end,
})

for index5, value15 in ipairs(gifts:GetChildren()) do
  f8(value15)
end