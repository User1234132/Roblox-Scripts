-- FUCKED BY MEDALWARE YOUR SCRIPTS ARE SO ASS

local players = game:GetService("Players")
local virtualInputManager = game:GetService("VirtualInputManager")
local debris = game:GetService("Debris")
local runService = game:GetService("RunService")
local localPlayer = players.LocalPlayer

local window = loadstring(game:HttpGet("https://sirius.menu/rayfield"))():CreateWindow({
  Name = "VelocityHUB | Poop a Big Poop Script",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "Pls like and follow",
  ConfigurationSaving = { Enabled = false },
})

local mainTab = window:CreateTab("Main", 4483362458)
local autoSellTab = window:CreateTab("Auto Sell", 4483362458)
local doorTab = window:CreateTab("Door", 4483362458)
local autoPerfect = false
local autoPoop = false
local v1 = false
local v2 = false
local visible = true
local autoSell = false
local sellAmount = 1
local v3 = false
local v4 = false

mainTab:CreateToggle({
  Name = "Auto Poop",
  CurrentValue = false,
  Callback = function(value)
    autoPoop = value

    if value then
      v2 = true
      virtualInputManager:SendMouseButtonEvent(0, 0, 0, true, game, 0)
    else
      v2 = false
      virtualInputManager:SendMouseButtonEvent(0, 0, 0, false, game, 0)
    end
  end,
})

mainTab:CreateToggle({
  Name = "Auto Perfect",
  CurrentValue = false,
  Callback = function(value2)
    autoPerfect = value2
    v1 = false
  end,
})

mainTab:CreateToggle({
  Name = "Hide all poops",
  CurrentValue = false,
  Callback = function(value3) v4 = value3 end,
})

function cleanPlayer(p1)
  if p1 == localPlayer then
    return
  else
    local function f1(p2)
      for index, value4 in ipairs(p2:GetChildren()) do
        if value4:IsA("Tool") then
          value4:Destroy()
        end
      end
    end

    if p1.Character then
      f1(p1.Character)
    end

    local backpack = p1:FindFirstChild("Backpack")

    if backpack then
      f1(backpack)
    end

    return
  end
end

players.PlayerAdded:Connect(function(player)
  player.CharacterAdded:Connect(function(character)
    character.ChildAdded:Connect(function(child)
      if v4 and child:IsA("Tool") then
        child:Destroy()
      end
    end)
  end)
end)

task.spawn(function()
  while task.wait(0.5) do
    if v4 then
      for index2, value5 in ipairs(players:GetPlayers()) do
        cleanPlayer(value5)
      end
    end
  end
end)

function disableCollideAndDestroyTool(p3)
  for index3, value6 in ipairs(p3:GetDescendants()) do
    if value6:IsA("BasePart") then
      value6.CanCollide = false
    end
  end

  p3:Destroy()
end

function cleanWorkspaceTools()
  for index4, value7 in ipairs(workspace:GetChildren()) do
    if value7:IsA("Tool") then
      disableCollideAndDestroyTool(value7)
    end
  end
end

workspace.ChildAdded:Connect(function(child2)
  if not v4 then
    return
  end

  if child2:IsA("Tool") then
    disableCollideAndDestroyTool(child2)
  end
end)

task.spawn(function()
  while task.wait(0.4) do
    if v4 then
      cleanWorkspaceTools()
    end
  end
end)

autoSellTab:CreateToggle({
  Name = "Auto Sell",
  CurrentValue = false,
  Callback = function(value8)
    autoSell = value8
    v3 = false
  end,
})

autoSellTab:CreateSlider({
  Name = "Sell Amount",
  Range = { 1, 300 },
  Increment = 1,
  CurrentValue = 1,
  Callback = function(value9) sellAmount = value9 end,
})

function centerInsideTarget(p4, p5)
  local absolutePosition = p4.AbsolutePosition
  local absoluteSize = p4.AbsoluteSize
  local v5 = absolutePosition.X + absoluteSize.X / 2
  local v6 = absolutePosition.Y + absoluteSize.Y / 2
  local absolutePosition2 = p5.AbsolutePosition
  local absoluteSize2 = p5.AbsoluteSize

  return v5 >= absolutePosition2.X and v5 <= absolutePosition2.X + absoluteSize2.X
    and v6 >= absolutePosition2.Y and v6 <= absolutePosition2.Y + absoluteSize2.Y
end

function getInventoryCount()
  local count = 0
  local backpack2 = localPlayer:FindFirstChild("Backpack")

  if backpack2 then
    for index5, value10 in ipairs(backpack2:GetChildren()) do
      if value10:IsA("Tool") then
        count = count + 1
      end
    end
  end

  local character2 = localPlayer.Character

  if character2 then
    for index6, value11 in ipairs(character2:GetChildren()) do
      if value11:IsA("Tool") then
        count = count + 1
      end
    end
  end

  return count
end

runService.RenderStepped:Connect(function()
  local playerGui = localPlayer:FindFirstChild("PlayerGui")

  if not playerGui then
    return
  end

-- https://discord.gg/AwGHNh7Z7T
  if autoPerfect then
    local poopUI = playerGui:FindFirstChild("PoopUI")
    local catchBar = poopUI and poopUI:FindFirstChild("CatchBar")
    local lineTrigger = catchBar and catchBar:FindFirstChild("LineTrigger")
    local barLine = catchBar and catchBar:FindFirstChild("BarLine")
    local slider = barLine and barLine:FindFirstChild("Slider")
    local target = slider and slider:FindFirstChild("Target")

    if lineTrigger and target then
      local v7 = centerInsideTarget(lineTrigger, target)

      if v7 and not v1 then
        local viewportSize = workspace.CurrentCamera.ViewportSize

        virtualInputManager:SendMouseButtonEvent(
          viewportSize.X / 2, viewportSize.Y / 2, 0, true, game, 0
        )

        virtualInputManager:SendMouseButtonEvent(
          viewportSize.X / 2, viewportSize.Y / 2, 0, false, game, 0
        )
      end

      v1 = v7
    end
  end

  if autoPoop then
    local poopUI2 = playerGui:FindFirstChild("PoopUI")
    local catchBar2 = poopUI2 and poopUI2:FindFirstChild("CatchBar")
    local chargeUI = workspace:FindFirstChild("ChargeUI")
    local uis = chargeUI and chargeUI:FindFirstChild("UIS")
    local barProgress = uis and uis:FindFirstChild("BarProgress")
    local fill = barProgress and barProgress:FindFirstChild("Fill")

    if v2 and fill and barProgress then
      if fill.AbsoluteSize.Y >= barProgress.AbsoluteSize.Y * 0.93 then
        v2 = false
        virtualInputManager:SendMouseButtonEvent(0, 0, 0, false, game, 0)
      end
    end

    if catchBar2 then
      if visible and not catchBar2.Visible then
        v2 = true
        virtualInputManager:SendMouseButtonEvent(0, 0, 0, true, game, 0)
      end

      visible = catchBar2.Visible
    end
  end

  if autoSell and not v3 then
    if getInventoryCount() >= sellAmount then
      v3 = true
      local character3 = localPlayer.Character

      local humanoidRootPart = character3
      humanoidRootPart = character3 and character3:FindFirstChild("HumanoidRootPart")

      if humanoidRootPart then
        humanoidRootPart.CFrame = CFrame.new(32, 3, -31)
      end

      task.wait(0.25)
      virtualInputManager:SendKeyEvent(true, Enum.KeyCode.E, false, game)
      task.wait(0.05)
      virtualInputManager:SendKeyEvent(false, Enum.KeyCode.E, false, game)

      task.spawn(function()
        local waitForChild = playerGui:WaitForChild("dialog", 5)
        local waitForChild2 = waitForChild and waitForChild:WaitForChild("dialogResponses", 5)
        local findFirstChild = waitForChild2 and waitForChild2:FindFirstChild("3")
        local visible2

        if findFirstChild then
          repeat
            task.wait()
            visible2 = findFirstChild.Visible or not autoSell
          until visible2

          if autoSell and findFirstChild.Visible then
            local v8 = findFirstChild.AbsolutePosition + findFirstChild.AbsoluteSize / 2
            virtualInputManager:SendMouseButtonEvent(v8.X, v8.Y, 0, true, game, 0)
            virtualInputManager:SendMouseButtonEvent(v8.X, v8.Y, 0, false, game, 0)
          end
        end

        task.wait(0.3)
        v3 = false
      end)
    end
  end
end)

local holdDuration = 0

doorTab:CreateSlider({
  Name = "Toilet Door Hold Duration",
  Range = { 0, 10 },
  Increment = 0.1,
  CurrentValue = 0,
  Callback = function(value12)
    holdDuration = value12
    local portaPotty = workspace:FindFirstChild("Porta Potty")
    local portaPotty2 = portaPotty and portaPotty:FindFirstChild("porta potty")
    local door = portaPotty2 and portaPotty2:FindFirstChild("Door")
    local union = door and door:FindFirstChild("Union")
    local proximityPrompt = union and union:FindFirstChildOfClass("ProximityPrompt")

    if proximityPrompt then
      proximityPrompt.HoldDuration = holdDuration
    end
  end,
})

doorTab:CreateButton({
  Name = "Open Door",
  Callback = function()
    local portaPotty3 = workspace:FindFirstChild("Porta Potty")
    local portaPotty4 = portaPotty3 and portaPotty3:FindFirstChild("porta potty")

    if portaPotty4 then
      local door2 = portaPotty4:FindFirstChild("Door")

      if door2 then
        door2:Destroy()
      end
    end

    for index7, value13 in ipairs(workspace:GetDescendants()) do
      if value13:IsA("BasePart") then
        local color = value13.Color

        if math.floor(color.R255) == 106 and math.floor(color.G255) == 57
          and math.floor(color.B * 255) == 9 then
          if value13.Name:lower():find("logo") then
            value13:Destroy()
          end
        end
      end
    end
  end,
})

doorTab:CreateButton({
  Name = "Teleport into the toilet",
  Callback = function()
    local humanoidRootPart2 = localPlayer.Character
      and localPlayer.Character:FindFirstChild("HumanoidRootPart")

    if humanoidRootPart2 then
      humanoidRootPart2.CFrame = CFrame.new(23, 3, -13)
    end
  end,
})

doorTab:CreateButton({
  Name = "Teleport to the toilet",
  Callback = function()
    local humanoidRootPart3 = localPlayer.Character
      and localPlayer.Character:FindFirstChild("HumanoidRootPart")

    if humanoidRootPart3 then
      humanoidRootPart3.CFrame = CFrame.new(20, 3, -15)
    end
  end,
})

doorTab:CreateButton({
  Name = "Play the Failure sound",
  Callback = function()
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://2236842292"
    sound.Volume = 2
    sound.Parent = workspace
    sound:Play()

    debris:AddItem(sound, 5)
  end,
})

doorTab:CreateButton({
  Name = "Play the Success sound",
  Callback = function()
    local sound2 = Instance.new("Sound")
    sound2.SoundId = "rbxassetid://122445547124433"
    sound2.Volume = 2
    sound2.Parent = workspace
    sound2:Play()

    debris:AddItem(sound2, 5)
  end,
})

