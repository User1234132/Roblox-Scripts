-- FUCKED BY MEDALWARE GET GOOD

local tweenService = game:GetService("TweenService")
local runService = game:GetService("RunService")
local players = game:GetService("Players")
local virtualUser = game:GetService("VirtualUser")
local userInputService = game:GetService("UserInputService")
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local enterKey = ""
local verifyKey = true

local keySystemWindow = rayfield:CreateWindow({
  Name = "Key System",
  Icon = 0,
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false },
  Discord = { Enabled = false },
  KeySystem = false,
})

local keySystemTab = keySystemWindow:CreateTab("Key System", 4483362458)
keySystemTab:CreateSection("VelocityHUB Key")
keySystemTab:CreateLabel("Enter the key to access VelocityHUB.")
keySystemTab:CreateLabel("The key is available in our Discord server.")

keySystemTab:CreateInput({
  Name = "Enter Key",
  PlaceholderText = "Enter your key here...",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) enterKey = value end,
})

keySystemTab:CreateButton({
  Name = "Verify Key",
  Callback = function()
    if enterKey == "VELOCITY_2026" then
      verifyKey = true

      rayfield:Notify({
        Title = "Key Verified",
        Content = "Correct key! Opening VelocityHUB...",
        Duration = 3,
      })

      task.wait(0.5)
      keySystemWindow:Destroy()
    else
      rayfield:Notify({
        Title = "Wrong Key",
        Content = "The key you entered is incorrect.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateButton({
  Name = "Copy Discord Link",
  Callback = function()
    if setclipboard then
      setclipboard("https://discord.gg/QVTsmm352y")

      rayfield:Notify({
        Title = "Discord Link Copied",
        Content = "The Discord invite link has been copied to your clipboard.",
        Duration = 3,
      })
    else
      rayfield:Notify({
        Title = "Clipboard Error",
        Content = "Your executor does not support clipboard copying.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateLabel("Join our Discord to get the key.")

while true do
  task.wait()

  if verifyKey then
    break
  end
end

local window = rayfield:CreateWindow({
  Name = "VelocityHUB | Murder Mystery 2",
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false, FolderName = nil, FileName = "VelocityHUB_MM2" },
  Discord = { Enabled = false, Invite = "noinvitelink", RememberJoins = true },
  KeySystem = false,
})

local v1 = {
  Innocents = false,
  Sheriff = false,
  Murderer = false,
  Name = false,
  Role = false,
  Distance = false,
  AutoFarm = false,
  AutoCoins = false,
  Colors = {
    Innocents = Color3.fromRGB(0, 255, 0),
    Sheriff = Color3.fromRGB(0, 0, 255),
    Murderer = Color3.fromRGB(255, 0, 0),
  },
}

local v2 = 0

local mainTab = window:CreateTab("Main", 4483362458)
mainTab:CreateSection("Auto")

local toggle

local autoFarmToggle = mainTab:CreateToggle({
  Name = "Auto Farm",
  CurrentValue = false,
  Flag = "Toggle_AutoFarm",
  Callback = function(value2)
    v1.AutoFarm = value2

    if value2 and toggle and v1.AutoCoins then
      toggle:Set(false)
    end

    if not value2 then
      pcall(function()
        local velocitySafePlatform = workspace:FindFirstChild("Velocity_Safe_Platform")

        if velocitySafePlatform then
          velocitySafePlatform:Destroy()
        end
      end)
    end
  end,
})

local create

toggle = mainTab:CreateToggle({
  Name = "Auto Collect Coins",
  CurrentValue = false,
  Flag = "Toggle_AutoCoins",
  Callback = function(value3)
    v1.AutoCoins = value3

    if value3 and autoFarmToggle and v1.AutoFarm then
      autoFarmToggle:Set(false)
    end

    if not value3 then
      if create then
        create:Cancel()
      end

      local character = players.LocalPlayer.Character

      if character and character:FindFirstChild("HumanoidRootPart") then
        character.HumanoidRootPart.Anchored = false
        local humanoid = character:FindFirstChild("Humanoid")

        if humanoid then
          humanoid.PlatformStand = false
        end
      end

      v2 = 0
    end
  end,
})

local espTab = window:CreateTab("ESP", 4483362458)
espTab:CreateSection("ESP Player")

espTab:CreateToggle({
  Name = "ESP Innocents",
  CurrentValue = false,
  Flag = "Toggle_Innocents",
  Callback = function(value4) v1.Innocents = value4 end,
})

espTab:CreateToggle({
  Name = "ESP Sheriff",
  CurrentValue = false,
  Flag = "Toggle_Sheriff",
  Callback = function(value5) v1.Sheriff = value5 end,
})

espTab:CreateToggle({
  Name = "ESP Murderer",
  CurrentValue = false,
  Flag = "Toggle_Murderer",
  Callback = function(value6) v1.Murderer = value6 end,
})

espTab:CreateSection("ESP Other")

espTab:CreateToggle({
  Name = "ESP Name",
  CurrentValue = false,
  Flag = "Toggle_Name",
  Callback = function(value7) v1.Name = value7 end,
})

espTab:CreateToggle({
  Name = "ESP Role",
  CurrentValue = false,
  Flag = "Toggle_Role",
  Callback = function(value8) v1.Role = value8 end,
})

espTab:CreateToggle({
  Name = "ESP Distance",
  CurrentValue = false,
  Flag = "Toggle_Distance",
  Callback = function(value9) v1.Distance = value9 end,
})

espTab:CreateSection("ESP Color Picker")

espTab:CreateColorPicker({
  Name = "Innocents Color",
  Color = v1.Colors.Innocents,
  Flag = "Color_Innocents",
  Callback = function(value10) v1.Colors.Innocents = value10 end,
})

espTab:CreateColorPicker({
  Name = "Sheriff Color",
  Color = v1.Colors.Sheriff,
  Flag = "Color_Sheriff",
  Callback = function(value11) v1.Colors.Sheriff = value11 end,
})

espTab:CreateColorPicker({
  Name = "Murderer Color",
  Color = v1.Colors.Murderer,
  Flag = "Color_Murderer",
  Callback = function(value12) v1.Colors.Murderer = value12 end,
})

local function f1(p1)
  if not p1 or not p1.Character then
    return "Innocent"
  else
    local v3 = false
    local v4 = false

    for key, value13 in pairs(p1.Character:GetChildren()) do
      if value13:IsA("Tool") then
        if value13.Name == "Gun" then
          v3 = true
        end

        if value13.Name == "Knife" then
          v4 = true
        end
      end
    end

    local backpack = p1:FindFirstChild("Backpack")

    if backpack then
      for key2, value14 in pairs(backpack:GetChildren()) do
        if value14:IsA("Tool") then
          if value14.Name == "Gun" then
            v3 = true
          end

          if value14.Name == "Knife" then
            v4 = true
          end
        end
      end
    end

    if v4 then
      return "Murderer"
    end

    if v3 then
      return "Sheriff"
    end

    return "Innocent"
  end
end

runService.RenderStepped:Connect(function()
  for key3, value15 in pairs(players:GetPlayers()) do
    if value15 ~= players.LocalPlayer then
      local character2 = value15.Character

      if character2 and character2:FindFirstChild("HumanoidRootPart")
        and character2:FindFirstChild("Humanoid") and character2.Humanoid.Health > 0 then
        local v5 = f1(value15)
        local v6 = false
        local color = Color3.new(1, 1, 1)

        if v5 == "Innocent" and v1.Innocents then
          v6 = true
          color = v1.Colors.Innocents
        elseif v5 == "Sheriff" and v1.Sheriff then
          v6 = true
          color = v1.Colors.Sheriff
        elseif v5 == "Murderer" and v1.Murderer then
          v6 = true
          color = v1.Colors.Murderer
        end

        local velocityESPHL = character2:FindFirstChild("Velocity_ESP_HL")

        if v6 then
          if not velocityESPHL then
            velocityESPHL = Instance.new("Highlight")
            velocityESPHL.Name = "Velocity_ESP_HL"
            velocityESPHL.Parent = character2
            velocityESPHL.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            velocityESPHL.FillTransparency = 0.5
            velocityESPHL.OutlineTransparency = 0
          end

          velocityESPHL.FillColor = color
          velocityESPHL.OutlineColor = color
        elseif velocityESPHL then
          velocityESPHL:Destroy()
        end

        local velocityESPText = character2:FindFirstChild("Velocity_ESP_Text")

        if v6 and (v1.Name or v1.Role or v1.Distance) then
          if not velocityESPText then
            velocityESPText = Instance.new("BillboardGui")
            velocityESPText.Name = "Velocity_ESP_Text"
            velocityESPText.Parent = character2

            velocityESPText.Adornee = character2:FindFirstChild("Head")
              or character2:FindFirstChild("HumanoidRootPart")

            velocityESPText.Size = UDim2.new(0, 200, 0, 50)
            velocityESPText.StudsOffset = Vector3.new(0, 3, 0)
            velocityESPText.AlwaysOnTop = true

            local label = Instance.new("TextLabel")
            label.Name = "Label"
            label.Parent = velocityESPText
            label.Size = UDim2.new(1, 0, 1, 0)
            label.BackgroundTransparency = 1
            label.TextStrokeTransparency = 0.5
            label.TextStrokeColor3 = Color3.new(0, 0, 0)
            label.TextSize = 14
            label.Font = Enum.Font.Code
          end

          local label2 = velocityESPText:FindFirstChild("Label")

          if label2 then
            label2.TextColor3 = color
            local v7 = {}

            if v1.Name then
              table.insert(v7, value15.Name)
            end

            if v1.Role then
              table.insert(v7, v5)
            end

            if v1.Distance then
              local character3 = players.LocalPlayer.Character

              if character3 and character3:FindFirstChild("HumanoidRootPart") then
                local v8 = math.floor((character3.HumanoidRootPart.Position
                  - character2.HumanoidRootPart.Position).Magnitude)

                table.insert(v7, v8 .. " Studs")
              end
            end

            label2.Text = table.concat(v7, "\n")
          end
        elseif velocityESPText then
          velocityESPText:Destroy()
        end
      elseif character2 then
        local velocityESPHL2 = character2:FindFirstChild("Velocity_ESP_HL")

        if velocityESPHL2 then
          velocityESPHL2:Destroy()
        end

        local velocityESPText2 = character2:FindFirstChild("Velocity_ESP_Text")

        if velocityESPText2 then
          velocityESPText2:Destroy()
        end
      end
    end
  end
end)

local v9 = false
local v10, userId

task.spawn(function()
  while task.wait(0.05) do
    if v1.AutoFarm then
      pcall(function()
        local character4 = players.LocalPlayer.Character

        local humanoid2 = character4 and character4:FindFirstChild("HumanoidRootPart")
          and character4:FindFirstChild("Humanoid") and character4.Humanoid.Health > 0

        local humanoidRootPart, character5

        if humanoid2 then
          humanoidRootPart = character4.HumanoidRootPart
          local humanoid3 = character4.Humanoid
          local v11 = f1(players.LocalPlayer)
          local v12 = nil
          local v13 = {}

          for key4, value16 in pairs(players:GetPlayers()) do
            if value16 ~= players.LocalPlayer and value16.Character
              and value16.Character:FindFirstChild("HumanoidRootPart")
              and value16.Character:FindFirstChild("Humanoid")
              and value16.Character.Humanoid.Health > 0 then
              local v14 = f1(value16)

              if v14 == "Murderer" then
                v12 = value16
              elseif v14 ~= "Murderer" then
                table.insert(v13, value16)
              end
            end
          end

          if not v12 and v11 ~= "Murderer" then
            if humanoidRootPart.Anchored then
              humanoidRootPart.Anchored = false
            end

            players.LocalPlayer.CameraMode = Enum.CameraMode.Classic
            return
          end

          if v11 == "Murderer" then
            humanoidRootPart.Anchored = false
            players.LocalPlayer.CameraMode = Enum.CameraMode.Classic

            if v10 then
              if not v10.Character or not v10.Character:FindFirstChild("Humanoid")
                or v10.Character.Humanoid.Health <= 0 then
                v10 = nil
              end
            end

            if not v10 then
              local v15 = 5000

              for key5, value17 in pairs(v13) do
                local magnitude = (humanoidRootPart.Position
                  - value17.Character.HumanoidRootPart.Position).Magnitude

                if magnitude <= v15 then
                  v15 = magnitude
                  v10 = value17
                end
              end
            end

            if v10 then
              local backpack2 = players.LocalPlayer:FindFirstChild("Backpack")

              local knife = character4:FindFirstChild("Knife")
                or backpack2 and backpack2:FindFirstChild("Knife")

              if knife and knife.Parent == backpack2 then
                humanoid3:EquipTool(knife)
              end

              humanoidRootPart.CFrame = v10.Character.HumanoidRootPart.CFrame
                * CFrame.new(0, 0, 3)

              pcall(function()
                if mouse1click then
                  mouse1click()
                else
                  virtualUser:Button1Down(Vector2.new(0, 0))
                  task.wait(0.01)
                  virtualUser:Button1Up(Vector2.new(0, 0))
                end
              end)
            end
          elseif v11 == "Sheriff" then
            if v12 then
              character5 = v12.Character

              if character5 and character5:FindFirstChild("HumanoidRootPart")
                and character5.Humanoid.Health > 0 then
                if userId ~= v12.UserId then
                  userId = v12.UserId
                  v9 = false
                end

                if not v9 then
                  v9 = true
                  humanoidRootPart.Anchored = false

                  task.spawn(function()
                    local v16 = {}

                    for index, value18 in ipairs(character4:GetChildren()) do
                      if value18:IsA("BasePart") then
                        v16[value18] = value18.CustomPhysicalProperties
                        value18.CustomPhysicalProperties = PhysicalProperties.new(100, 0.3, 0.5)
                        value18.CanCollide = true
                      end
                    end

                    local sheriffFlingForce = Instance.new("BodyAngularVelocity")
                    sheriffFlingForce.Name = "Sheriff_Fling_Force"
                    sheriffFlingForce.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
                    sheriffFlingForce.AngularVelocity = Vector3.new(0, 99999, 0)
                    sheriffFlingForce.Parent = humanoidRootPart

                    local total = 0

                    local connect

                    connect = runService.Stepped:Connect(function(delta, index2)
                      total = total + index2

                      if total >= 1 or not character5:FindFirstChild("HumanoidRootPart")
                        or character5.Humanoid.Health <= 0 then
                        connect:Disconnect()

                        if sheriffFlingForce then
                          sheriffFlingForce:Destroy()
                        end

                        humanoidRootPart.Velocity = Vector3.new(0, 0, 0)
                        humanoidRootPart.RotVelocity = Vector3.new(0, 0, 0)

                        for key6, value19 in pairs(v16) do
                          if key6 and key6.Parent then
                            key6.CustomPhysicalProperties = value19
                          end
                        end
                      else
                        humanoidRootPart.CFrame = character5.HumanoidRootPart.CFrame
                      end
                    end)
                  end)
                end
              end
            else
              userId = nil
              v9 = false
            end
          elseif v11 == "Innocent" then
            if v12 then
              players.LocalPlayer.CameraMode = Enum.CameraMode.Classic

-- https://discord.gg/AwGHNh7Z7T
              if not humanoidRootPart.Anchored then
                humanoidRootPart.CFrame = humanoidRootPart.CFrame + Vector3.new(0, 500, 0)
                humanoidRootPart.Anchored = true
              end
            end
          end

          return
        end
      end)
    else
      pcall(function()
        local character6 = players.LocalPlayer.Character

        if character6 and character6:FindFirstChild("HumanoidRootPart") then
          character6.HumanoidRootPart.Anchored = false
          local sheriffFlingForce2 = character6.HumanoidRootPart:FindFirstChild("Sheriff_Fling_Force")

          if sheriffFlingForce2 then
            sheriffFlingForce2:Destroy()
          end
        end

        players.LocalPlayer.CameraMode = Enum.CameraMode.Classic
        v10 = nil
        userId = nil
        v9 = false
      end)
    end
  end
end)

local v17 = setmetatable({}, { __mode = "k" })
local cframe

task.spawn(function()
  while task.wait(0.1) do
    if v1.AutoCoins then
      pcall(function()
        local character7 = players.LocalPlayer.Character

        local humanoid4 = character7 and character7:FindFirstChild("HumanoidRootPart")
          and character7:FindFirstChild("Humanoid") and character7.Humanoid.Health > 0

        local humanoidRootPart2, v18

        if humanoid4 then
          humanoidRootPart2 = character7.HumanoidRootPart
          local humanoid5 = character7.Humanoid
          v18 = nil
          local huge = math.huge

          for key7, value20 in pairs(workspace:GetDescendants()) do
            if value20.Name == "Coin_Server" and value20:IsA("BasePart")
              and value20.Parent ~= nil and not v17[value20] then
              local magnitude2 = (humanoidRootPart2.Position - value20.Position).Magnitude

              if magnitude2 < huge then
                v18 = value20
                huge = magnitude2
              end
            end
          end

          if v18 and v1.AutoCoins then
            local position = v18.Position

            local connect2 = runService.Stepped:Connect(function()
              for index3, value21 in ipairs(character7:GetChildren()) do
                if value21:IsA("BasePart") then
                  value21.CanCollide = false
                end
              end

              humanoidRootPart2.Velocity = Vector3.new(0, 0, 0)
            end)

            humanoid5.PlatformStand = true
            humanoidRootPart2.Anchored = false

            local function f2(cframe2)
              if not v1.AutoCoins then
                return false
              else
                local v19 = (humanoidRootPart2.Position - cframe2.Position).Magnitude / 55

                if v19 > 0 then
                  create = tweenService:Create(
                    humanoidRootPart2, TweenInfo.new(v19, Enum.EasingStyle.Linear),
                    { CFrame = cframe2 }
                  )

                  create:Play()

                  local total2 = 0

                  while total2 < v19 do
                    if not v1.AutoCoins or v18.Parent == nil then
                      create:Cancel()
                      return false
                    end

                    total2 = total2 + task.wait(0.03)
                  end

                  return true
                end

                return true
              end
            end

            local v20 = f2((CFrame.new(
              humanoidRootPart2.Position.X, position.Y - 15, humanoidRootPart2.Position.Z
            )))

            if v20 then
              v20 = f2((CFrame.new(position.X, position.Y - 15, position.Z)))
            end

            if v20 then
              v20 = f2(CFrame.new(position))
            end

            if connect2 then
              connect2:Disconnect()
            end

            if v1.AutoCoins and v20 then
              humanoid5.PlatformStand = false
              v17[v18] = true
              v2 = v2 + 1
              task.wait(0.1)

              if v2 >= 5 then
                cframe = humanoidRootPart2.CFrame
                local velocityCoinPlatform = workspace:FindFirstChild("Velocity_Coin_Platform")

                if not velocityCoinPlatform then
                  velocityCoinPlatform = Instance.new("Part")
                  velocityCoinPlatform.Name = "Velocity_Coin_Platform"
                  velocityCoinPlatform.Size = Vector3.new(50, 2, 50)
                  velocityCoinPlatform.Anchored = true
                  velocityCoinPlatform.Transparency = 1
                  velocityCoinPlatform.CanCollide = true
                  velocityCoinPlatform.Parent = workspace
                end

                velocityCoinPlatform.Position = cframe.Position + Vector3.new(0, 500, 0)
                humanoidRootPart2.CFrame = velocityCoinPlatform.CFrame * CFrame.new(0, 5, 0)
                task.wait(2)

                if v1.AutoCoins and character7 and character7:FindFirstChild("HumanoidRootPart") then
                  character7.HumanoidRootPart.CFrame = cframe
                  task.wait(0.2)
                end

                v2 = 0
              end
            end
          elseif humanoid5.PlatformStand then
            humanoid5.PlatformStand = false
          end
        end
      end)
    end
  end
end)

local playerTab = window:CreateTab("Player", 4483362458)

local v21 = {
  Speed = 16,
  JumpPower = 50,
  Fly = false,
  Noclip = false,
  Fling = false,
}

playerTab:CreateSection("Player")

playerTab:CreateSlider({
  Name = "Speed",
  Range = { 16, 100 },
  Increment = 1,
  Suffix = " WalkSpeed",
  CurrentValue = 16,
  Flag = "Player_Speed",
  Callback = function(value22)
    v21.Speed = value22

    pcall(function()
      local character8 = players.LocalPlayer.Character
      local humanoid6 = character8 and character8:FindFirstChildOfClass("Humanoid")

      if humanoid6 then
        humanoid6.WalkSpeed = value22
      end
    end)
  end,
})

playerTab:CreateSlider({
  Name = "JumpPower",
  Range = { 50, 150 },
  Increment = 1,
  Suffix = " JumpPower",
  CurrentValue = 50,
  Flag = "Player_JumpPower",
  Callback = function(value23)
    v21.JumpPower = value23

    pcall(function()
      local character9 = players.LocalPlayer.Character
      local humanoid7 = character9 and character9:FindFirstChildOfClass("Humanoid")

      if humanoid7 then
        humanoid7.UseJumpPower = true
        humanoid7.JumpPower = value23
      end
    end)
  end,
})

local velocityFlyGyro = nil
local f3
local connect3, velocityFly

local function makeBodyVelocity()
  f3()
  local localPlayer = players.LocalPlayer
  local character10 = localPlayer.Character

  if not character10 then
    return
  else
    local v22 = not character10:FindFirstChildOfClass("Humanoid")
    local humanoidRootPart3 = character10:FindFirstChild("HumanoidRootPart")

    if v22 or not humanoidRootPart3 then
      return
    end

    velocityFly = Instance.new("BodyVelocity")
    velocityFly.Name = "Velocity_Fly"
    velocityFly.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
    velocityFly.Velocity = Vector3.zero
    velocityFly.P = 9000
    velocityFly.Parent = humanoidRootPart3

    velocityFlyGyro = Instance.new("BodyGyro")
    velocityFlyGyro.Name = "Velocity_Fly_Gyro"
    velocityFlyGyro.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
    velocityFlyGyro.P = 9000
    velocityFlyGyro.D = 500
    velocityFlyGyro.CFrame = workspace.CurrentCamera.CFrame
    velocityFlyGyro.Parent = humanoidRootPart3

    connect3 = runService.RenderStepped:Connect(function()
      if not v21.Fly then
        f3()
        return
      else
        local character11 = localPlayer.Character

        if not character11 then
          return
        else
          local humanoid8 = character11:FindFirstChildOfClass("Humanoid")

          if not humanoid8 or not character11:FindFirstChild("HumanoidRootPart")
            or humanoid8.Health <= 0 then
            f3()
            return
          else
            local currentCamera = workspace.CurrentCamera

            if not currentCamera then
              return
            else
              local zero = Vector3.zero

              if userInputService:IsKeyDown(Enum.KeyCode.W) then
                zero = zero + currentCamera.CFrame.LookVector
              end

              if userInputService:IsKeyDown(Enum.KeyCode.S) then
                zero = zero - currentCamera.CFrame.LookVector
              end

              if userInputService:IsKeyDown(Enum.KeyCode.D) then
                zero = zero + currentCamera.CFrame.RightVector
              end

              if userInputService:IsKeyDown(Enum.KeyCode.A) then
                zero = zero - currentCamera.CFrame.RightVector
              end

              if userInputService:IsKeyDown(Enum.KeyCode.Space) then
                zero = zero + Vector3.new(0, 1, 0)
              end

              if userInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
                zero = zero - Vector3.new(0, 1, 0)
              end

              if zero.Magnitude > 0 then
                zero = zero.Unit
              end

              velocityFly.Velocity = zero * v21.Speed
              velocityFlyGyro.CFrame = currentCamera.CFrame
              return
            end
          end
        end
      end
    end)

    return
  end
end

function f3()
  if connect3 then
    connect3:Disconnect()
    connect3 = nil
  end

  if velocityFly then
    velocityFly:Destroy()
    velocityFly = nil
  end

  if velocityFlyGyro then
    velocityFlyGyro:Destroy()
    velocityFlyGyro = nil
  end
end

playerTab:CreateToggle({
  Name = "Fly",
  CurrentValue = false,
  Flag = "Player_Fly",
  Callback = function(value24)
    v21.Fly = value24

    if value24 then
      makeBodyVelocity()
    else
      f3()
    end
  end,
})

local v23 = {}
local connect4

local function f4()
  if connect4 then
    connect4:Disconnect()
    connect4 = nil
  end

  for key8, value25 in pairs(v23) do
    if key8 and key8.Parent and key8:IsA("BasePart") then
      key8.CanCollide = true
    end
  end

  v23 = {}
end

local function f5()
  if connect4 then
    connect4:Disconnect()
    connect4 = nil
  end

  v23 = {}

  connect4 = runService.Stepped:Connect(function()
    if not v21.Noclip then
      return
    else
      local character12 = players.LocalPlayer.Character

      if character12 then
        for index4, value26 in ipairs(character12:GetDescendants()) do
          if value26:IsA("BasePart") and value26.CanCollide then
            value26.CanCollide = false
            v23[value26] = true
          end
        end
      end

      return
    end
  end)
end

playerTab:CreateToggle({
  Name = "Noclip",
  CurrentValue = false,
  Flag = "Player_Noclip",
  Callback = function(value27)
    v21.Noclip = value27

    if value27 then
      f5()
    else
      f4()
    end
  end,
})

players.LocalPlayer.CharacterAdded:Connect(function(character13)
  task.wait(0.5)
  local humanoid9 = character13:FindFirstChildOfClass("Humanoid")

  if humanoid9 then
    humanoid9.WalkSpeed = v21.Speed
    humanoid9.UseJumpPower = true
    humanoid9.JumpPower = v21.JumpPower
  end

  if v21.Fly then
    task.wait(0.2)
    makeBodyVelocity()
  end

  if v21.Noclip then
    task.wait(0.2)
    f5()
  end
end)

playerTab:CreateSection("Fling")
local velocityFling = nil
local v24 = {}
local connect5, connect6

local function f6()
  if connect5 then
    connect5:Disconnect()
    connect5 = nil
  end

  if connect6 then
    connect6:Disconnect()
    connect6 = nil
  end

  if velocityFling then
    velocityFling:Destroy()
    velocityFling = nil
  end

  for key9, value28 in pairs(v24) do
    local v25 = key9
    local v26 = value28

    if v25 and v25.Parent and v25:IsA("BasePart") then
      pcall(function()
        v25.CustomPhysicalProperties = v26.CustomPhysicalProperties
        v25.Massless = v26.Massless
        v25.AssemblyLinearVelocity = Vector3.zero
        v25.AssemblyAngularVelocity = Vector3.zero
      end)
    end
  end

  table.clear(v24)
end

local function makeBodyAngularVelocity()
  f6()
  local localPlayer2 = players.LocalPlayer
  local character14 = localPlayer2.Character

  if not character14 then
    return
  else
    local humanoid10 = character14:FindFirstChildOfClass("Humanoid")
    local v27 = not humanoid10
    local humanoidRootPart4 = character14:FindFirstChild("HumanoidRootPart")

    if v27 or not humanoidRootPart4 then
      return
    end

    for index5, value29 in ipairs(character14:GetDescendants()) do
      if value29:IsA("BasePart") then
        v24[value29] = {
          CustomPhysicalProperties = value29.CustomPhysicalProperties,
          Massless = value29.Massless,
        }

        value29.CustomPhysicalProperties = PhysicalProperties.new(100, 0.3, 0.5)
        value29.Massless = true
        value29.AssemblyLinearVelocity = Vector3.zero
        value29.AssemblyAngularVelocity = Vector3.zero
      end
    end

    velocityFling = Instance.new("BodyAngularVelocity")
    velocityFling.Name = "Velocity_Fling"
    velocityFling.AngularVelocity = Vector3.new(0, 99999, 0)
    velocityFling.MaxTorque = Vector3.new(0, math.huge, 0)
    velocityFling.P = math.huge
    velocityFling.Parent = humanoidRootPart4

    connect6 = humanoid10.Died:Connect(function()
      v21.Fling = false
      f6()
    end)

    connect5 = runService.Heartbeat:Connect(function()
      if not v21.Fling then
        f6()
        return
      else
        local character15 = localPlayer2.Character

        if not character15 or not character15.Parent then
          f6()
          return
        else
          local humanoidRootPart5 = character15:FindFirstChild("HumanoidRootPart")

          if not humanoidRootPart5 then
            return
          end

          if velocityFling then
            velocityFling.AngularVelocity = Vector3.new(0, 99999, 0)
          end

          humanoidRootPart5.AssemblyAngularVelocity = Vector3.new(0, 99999, 0)
          return
        end
      end
    end)

    return
  end
end

playerTab:CreateToggle({
  Name = "Fling",
  CurrentValue = false,
  Flag = "Player_Fling",
  Callback = function(value30)
    v21.Fling = value30

    if value30 then
      makeBodyAngularVelocity()
    else
      f6()
    end
  end,
})