-- ANALLY FUCKED BY MEDALWARE

local runService = game:GetService("RunService")
local players = game:GetService("Players")
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local localPlayer = players.LocalPlayer
local verifyKey = true
local enterKey = ""

local keySystemWindow = rayfield:CreateWindow({
  Name = "Key System",
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false },
  KeySystem = false,
})

local keySystemTab = keySystemWindow:CreateTab("Key System")
keySystemTab:CreateSection("VelocityHUB Key")
keySystemTab:CreateLabel("Enter the key to access VelocityHUB.")
keySystemTab:CreateLabel("The key is available in our Discord server.")

keySystemTab:CreateInput({
  Name = "Enter Key",
  PlaceholderText = "Enter your key here...",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) enterKey = value end,
})

keySystemTab:CreateButton({
  Name = "Verify Key",
  Callback = function()
    if enterKey == "VELOCITY_2026" then
      verifyKey = true

      rayfield:Notify({
        Title = "Key Verified",
        Content = "Correct key! Opening VelocityHUB...",
        Duration = 3,
      })

      task.wait(0.5)
      keySystemWindow:Destroy()
    else
      rayfield:Notify({
        Title = "Wrong Key",
        Content = "The key you entered is incorrect.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateButton({
  Name = "Copy Discord Link",
  Callback = function()
    if setclipboard then
      setclipboard("https://discord.gg/QVTsmm352y")

      rayfield:Notify({
        Title = "Discord Link Copied",
        Content = "The Discord invite link has been copied to your clipboard.",
        Duration = 3,
      })
    else
      rayfield:Notify({
        Title = "Clipboard Error",
        Content = "Your executor does not support clipboard copying.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateLabel("Join our Discord to get the key.")

repeat
  task.wait()
until verifyKey

local window = rayfield:CreateWindow({
  Name = "Build A Boat For Treasure🛳️ | VelocityHUB",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "VelocityHUB",
  ConfigurationSaving = { Enabled = false },
  KeySystem = false,
})

local mainTab = window:CreateTab("Main")
local autoFarm = false
local v1 = false
local v2 = {}

mainTab:CreateToggle({
  Name = "Auto Farm",
  CurrentValue = false,
  Flag = "AutoFarm",
  Callback = function(value2)
    autoFarm = value2

    if autoFarm then
      task.spawn(startAutoFarm)
    else
      v1 = false
      cleanupFly(localPlayer.Character)
    end
  end,
})

mainTab:CreateLabel("Note: Waits 3 seconds after respawn to prevent physics glitches and ensure character fully loads.")

mainTab:CreateButton({
  Name = "Delete Water",
  Callback = function()
    for key, value3 in pairs(workspace:GetDescendants()) do
      if value3.Name == "Water" and value3:IsA("BasePart") then
        value3:Destroy()
      end
    end
  end,
})

runService.Stepped:Connect(function()
  if autoFarm and v1 then
    for i = 1, #v2 do
      v2[i].CanCollide = false
    end
  end
end)

function cleanupFly(p1)
  v1 = false

  if p1 then
    local humanoidRootPart = p1:FindFirstChild("HumanoidRootPart")
    local humanoid = p1:FindFirstChild("Humanoid")

    if humanoidRootPart then
      local autoFarmBV = humanoidRootPart:FindFirstChild("AutoFarmBV")

      if autoFarmBV then
        autoFarmBV:Destroy()
      end

      local autoFarmBG = humanoidRootPart:FindFirstChild("AutoFarmBG")

      if autoFarmBG then
        autoFarmBG:Destroy()
      end
    end

    if humanoid then
      humanoid.PlatformStand = false
    end
  end
end

local v3

function startAutoFarm()
  local cframe = CFrame.new(-56, -360, 9484)
  local vector = Vector3.new(-51.5656433, 65.0000458, 1369.09009)
  local vector2 = Vector3.new(-51.5656433, 65.0000458, 8299.08984)
  local v4 = true

  if not v3 then
    local v5 = {}

    for index, value4 in ipairs(workspace:GetDescendants()) do
      if value4.Name == "DarknessPart" and value4:IsA("BasePart") then
        if (value4.Position - vector2).Magnitude > 5 then
          table.insert(v5, value4)
        end
      end
    end

    table.sort(v5, function(p2, p3) return p2.Position.Z < p3.Position.Z end)
    v3 = {}

    for index2, value5 in ipairs(v5) do
      if value5.Position.Z >= vector.Z - 10 then
        table.insert(v3, value5)
      end
    end
  end

  local f1, v6

  while autoFarm do
    local character = localPlayer.Character
    local v7 = not character
    local v8 = v7

    if not v7 then
      local v9 = not character.Parent

      v7 = v9
      v7 = v9 or not character:FindFirstChild("Humanoid") or character.Humanoid.Health <= 0

      v8 = v7
    end

    if v8 then
      task.wait(1)
    else
      local humanoidRootPart2 = character:FindFirstChild("HumanoidRootPart")
      local humanoid2 = character:FindFirstChild("Humanoid")

      if not humanoidRootPart2 or not humanoid2 then
        task.wait(1)
      elseif not v4 then
        local v10 = false

        for j = 1, 30 do
          if not autoFarm or humanoid2.Health <= 0 or not character.Parent then
            v10 = true
            break
          end

          task.wait(0.1)
        end

        if not (v10 or not autoFarm) then
          ::L10596885::
          table.clear(v2)

          for index3, value6 in ipairs(character:GetDescendants()) do
            if value6:IsA("BasePart") then
              table.insert(v2, value6)
            end
          end

          v1 = true
          humanoid2.PlatformStand = true

          local autoFarmBV2 = humanoidRootPart2:FindFirstChild("AutoFarmBV")
            or Instance.new("BodyVelocity")

          autoFarmBV2.Name = "AutoFarmBV"
          autoFarmBV2.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
          autoFarmBV2.Velocity = Vector3.zero
          autoFarmBV2.Parent = humanoidRootPart2

          local autoFarmBG2 = humanoidRootPart2:FindFirstChild("AutoFarmBG")
            or Instance.new("BodyGyro")

          autoFarmBG2.Name = "AutoFarmBG"
          autoFarmBG2.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
          autoFarmBG2.P = 90000
          autoFarmBG2.CFrame = humanoidRootPart2.CFrame
          autoFarmBG2.Parent = humanoidRootPart2

          function f1(index4)
            local v11 = false

            while autoFarm and character.Parent and humanoid2.Health > 0 and not v11 do
              local position = humanoidRootPart2.Position

              if (index4 - position).Magnitude < 60 then
                autoFarmBV2.Velocity = Vector3.zero

                humanoidRootPart2.Velocity = Vector3.zero
                humanoidRootPart2.RotVelocity = Vector3.zero
                humanoidRootPart2.CFrame = CFrame.new(index4)

                runService.Heartbeat:Wait()
                v11 = true
                break
              end

              autoFarmBV2.Velocity = (index4 - position).Unit * 3000
              autoFarmBG2.CFrame = CFrame.new(position, index4)
              runService.Heartbeat:Wait()
            end

            return v11
          end

          v6 = true

          for index5, value7 in ipairs(v3) do
            if not autoFarm or humanoid2.Health <= 0 or not character.Parent then
              v6 = false
              break
            end

-- https://discord.gg/AwGHNh7Z7T
            f1(value7.Position)
          end

          if autoFarm and humanoid2.Health > 0 and character.Parent and v6 then
            f1((Vector3.new(cframe.X, 65, cframe.Z)))

            if autoFarm and humanoid2.Health > 0 and character.Parent then
              f1(cframe.Position)

              if autoFarm and humanoid2.Health > 0 and character.Parent then
                autoFarmBV2.Velocity = Vector3.zero

                humanoidRootPart2.Velocity = Vector3.zero
                humanoidRootPart2.RotVelocity = Vector3.zero
                humanoidRootPart2.CFrame = cframe

                autoFarmBG2.CFrame = cframe

                while autoFarm and humanoid2.Health > 0 and character.Parent do
                  humanoidRootPart2.Velocity = Vector3.zero
                  humanoidRootPart2.CFrame = cframe
                  task.wait(0.1)
                end
              end
            end
          end

          cleanupFly(character)
        end
      else
        v4 = false
        goto L10596885
      end
    end
  end
end

local espTab = window:CreateTab("ESP")
espTab:CreateSection("ESP Treasure")

local espTreasure = false
local color = Color3.fromRGB(255, 215, 0)
local v12 = {}

espTab:CreateToggle({
  Name = "ESP Treasure",
  CurrentValue = false,
  Flag = "ESPTreasure",
  Callback = function(value8)
    espTreasure = value8

    if not value8 then
      for key2, value9 in pairs(v12) do
        if value9 then
          value9:Destroy()
        end
      end

      table.clear(v12)
    end
  end,
})

espTab:CreateColorPicker({
  Name = "Treasure ESP Color",
  Color = Color3.fromRGB(255, 215, 0),
  Flag = "TreasureESPColor",
  Callback = function(value10) color = value10 end,
})

espTab:CreateSection("Player ESP")

local playerESP = false
local color2 = Color3.fromRGB(255, 0, 0)
local v13 = {}

espTab:CreateToggle({
  Name = "Player ESP",
  CurrentValue = false,
  Flag = "ESPPlayer",
  Callback = function(value11)
    playerESP = value11

    if not value11 then
      for key3, value12 in pairs(v13) do
        if value12.Highlight then
          value12.Highlight:Destroy()
        end

        if value12.Billboard then
          value12.Billboard:Destroy()
        end
      end

      table.clear(v13)
    end
  end,
})

espTab:CreateColorPicker({
  Name = "Player ESP Color",
  Color = Color3.fromRGB(255, 0, 0),
  Flag = "PlayerESPColor",
  Callback = function(value13) color2 = value13 end,
})

runService.RenderStepped:Connect(function()
  local humanoidRootPart3 = localPlayer.Character
    and localPlayer.Character:FindFirstChild("HumanoidRootPart")

  if espTreasure then
    local goldenChest = workspace:FindFirstChild("BoatStages")
      and workspace.BoatStages:FindFirstChild("NormalStages")
      and workspace.BoatStages.NormalStages:FindFirstChild("TheEnd")
      and workspace.BoatStages.NormalStages.TheEnd:FindFirstChild("GoldenChest")

    if goldenChest then
      for index6, value14 in ipairs({
        goldenChest:FindFirstChild("Base"), goldenChest:FindFirstChild("Cap"),
      }) do
        if value14 then
          if not v12["Highlight_" .. index6] then
            local highlight = Instance.new("Highlight")
            highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            highlight.FillTransparency = 0.5
            highlight.OutlineTransparency = 0.1
            highlight.Parent = value14

            v12["Highlight_" .. index6] = highlight
          end

          v12["Highlight_" .. index6].Adornee = value14
          v12["Highlight_" .. index6].FillColor = color
          v12["Highlight_" .. index6].OutlineColor = color

          if value14.Name == "Base" then
            if not v12.Billboard then
              local billboardGui = Instance.new("BillboardGui")
              billboardGui.AlwaysOnTop = true
              billboardGui.Size = UDim2.new(0, 100, 0, 40)
              billboardGui.StudsOffset = Vector3.new(0, 4, 0)
              billboardGui.SizeOffset = Vector2.new(1, 1)

              local instance = Instance.new("TextLabel", billboardGui)
              instance.Size = UDim2.new(1, 0, 1, 0)
              instance.BackgroundTransparency = 1
              instance.TextScaled = true

              instance.FontFace = Font.new(
                "rbxasset://fonts/families/Arcane.json", Enum.FontWeight.Bold,
                Enum.FontStyle.Normal
              )

              instance.TextStrokeTransparency = 0

              local playerGui = localPlayer:FindFirstChild("PlayerGui")

              if playerGui then
                billboardGui.Parent = playerGui
              end

              v12.Billboard = billboardGui
              v12.Text = instance
            end

            local basePart = value14:IsA("BasePart") and value14

            local findFirstChildWhichIsA = basePart

            findFirstChildWhichIsA = basePart
              or value14:FindFirstChildWhichIsA("BasePart", true) or value14

            v12.Billboard.Adornee = findFirstChildWhichIsA
            v12.Text.TextColor3 = color

            if humanoidRootPart3 and findFirstChildWhichIsA then
              local position2 = findFirstChildWhichIsA:IsA("BasePart")
                and findFirstChildWhichIsA.Position

              local position3 = position2
              position3 = position2 or value14:GetPivot().Position

              v12.Text.Text = string.format("Treasure\n[%d m]", math.floor((humanoidRootPart3.Position
                - position3).Magnitude))
            end
          end
        end
      end
    end
  end

  if playerESP then
    for index7, value15 in ipairs(players:GetPlayers()) do
      if value15 ~= localPlayer then
        local character2 = value15.Character

        local humanoidRootPart4 = character2
        humanoidRootPart4 = character2 and character2:FindFirstChild("HumanoidRootPart")

        if humanoidRootPart4 then
          if not v13[value15] then
            local v14 = {}

            local highlight2 = Instance.new("Highlight")
            highlight2.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            highlight2.FillTransparency = 0.5
            highlight2.Parent = character2

            v14.Highlight = highlight2

            local billboardGui2 = Instance.new("BillboardGui")
            billboardGui2.AlwaysOnTop = true
            billboardGui2.Size = UDim2.new(0, 100, 0, 40)
            billboardGui2.StudsOffset = Vector3.new(0, 3.5, 0)

            local instance2 = Instance.new("TextLabel", billboardGui2)
            instance2.Size = UDim2.new(1, 0, 1, 0)
            instance2.BackgroundTransparency = 1
            instance2.TextScaled = true

            instance2.FontFace = Font.new(
              "rbxasset://fonts/families/Arcane.json", Enum.FontWeight.Bold,
              Enum.FontStyle.Normal
            )

            instance2.TextStrokeTransparency = 0

            local playerGui2 = localPlayer:FindFirstChild("PlayerGui")

            if playerGui2 then
              billboardGui2.Parent = playerGui2
            end

            v14.Billboard = billboardGui2
            v14.Text = instance2

            v13[value15] = v14
          end

          local v15 = v13[value15]
          v15.Highlight.Adornee = character2
          v15.Highlight.FillColor = color2
          v15.Highlight.OutlineColor = color2

          local billboard = v15.Billboard
          billboard.Adornee = character2:FindFirstChild("Head") or humanoidRootPart4

          v15.Text.TextColor3 = color2

          if humanoidRootPart3 then
            v15.Text.Text = string.format("%s\n[%d m]", value15.Name, math.floor((humanoidRootPart3.Position
              - humanoidRootPart4.Position).Magnitude))
          end
        elseif v13[value15] then
          if v13[value15].Highlight then
            v13[value15].Highlight:Destroy()
          end

          if v13[value15].Billboard then
            v13[value15].Billboard:Destroy()
          end

          v13[value15] = nil
        end
      end
    end
  end
end)

players.PlayerRemoving:Connect(function(player)
  if v13[player] then
    if v13[player].Highlight then
      v13[player].Highlight:Destroy()
    end

    if v13[player].Billboard then
      v13[player].Billboard:Destroy()
    end

    v13[player] = nil
  end
end)

-- https://discord.gg/AwGHNh7Z7T
