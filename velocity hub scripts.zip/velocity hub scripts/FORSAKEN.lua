-- SHITTY SCRIPT FUCKED BY MEDALWRE EASY DEOBF

local players = game:GetService("Players")
local runService = game:GetService("RunService")
local virtualInputManager = game:GetService("VirtualInputManager")
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local enterKey = ""
local verifyKey = true
local keySystemWindow = rayfield:CreateWindow({
  Name = "Key System",
  Icon = 0,
  LoadingTitle = "VelocityHUB",
  LoadingSubtitle = "Loading...",
  ConfigurationSaving = { Enabled = false },
  Discord = { Enabled = false },
  KeySystem = false,
})

local keySystemTab = keySystemWindow:CreateTab("Key System", 4483362458)
keySystemTab:CreateSection("VelocityHUB Key")
keySystemTab:CreateLabel("Enter the key to access VelocityHUB.")
keySystemTab:CreateLabel("The key is available in our Discord server.")

keySystemTab:CreateInput({
  Name = "Enter Key",
  PlaceholderText = "Enter your key here...",
  RemoveTextAfterFocusLost = false,
  Callback = function(value) enterKey = value end,
})

keySystemTab:CreateButton({
  Name = "Verify Key",
  Callback = function()
    if enterKey == "VELOCITY_2026" then
      verifyKey = true

      rayfield:Notify({
        Title = "Key Verified",
        Content = "Correct key! Opening VelocityHUB...",
        Duration = 3,
      })

      task.wait(0.5)
      keySystemWindow:Destroy()
    else
      rayfield:Notify({
        Title = "Wrong Key",
        Content = "The key you entered is incorrect.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateButton({
  Name = "Copy Discord Link",
  Callback = function()
    if setclipboard then
      setclipboard("https://discord.gg/QVTsmm352y")

      rayfield:Notify({
        Title = "Discord Link Copied",
        Content = "The Discord invite link has been copied to your clipboard.",
        Duration = 3,
      })
    else
      rayfield:Notify({
        Title = "Clipboard Error",
        Content = "Your executor does not support clipboard copying.",
        Duration = 3,
      })
    end
  end,
})

keySystemTab:CreateLabel("Join our Discord to get the key.")

repeat
  task.wait()
until verifyKey

local localPlayer = players.LocalPlayer

local function f1(value2)
  if not value2 or not value2:IsA("Model") then
    return nil
  else
    for index, value3 in ipairs({ "Player", "Owner", "PlayerObject", "PlayerValue" }) do
      local findFirstChild = value2:FindFirstChild(value3)

      if findFirstChild and findFirstChild:IsA("ObjectValue") and findFirstChild.Value
        and findFirstChild.Value:IsA("Player") then
        return findFirstChild.Value.Name
      end
    end

    for index2, value4 in ipairs({ "UserId", "PlayerUserId", "OwnerUserId" }) do
      local getAttribute = value2:GetAttribute(value4)

      if typeof(getAttribute) == "number" then
        local getPlayerByUserId = players:GetPlayerByUserId(getAttribute)

        if getPlayerByUserId then
          return getPlayerByUserId.Name
        end
      end

      if typeof(getAttribute) == "string" then
        local v1 = tonumber(getAttribute)

        if v1 then
          local getPlayerByUserId2 = players:GetPlayerByUserId(v1)

          if getPlayerByUserId2 then
            return getPlayerByUserId2.Name
          end
        end
      end
    end

    for index3, value5 in ipairs({ "PlayerName", "Username", "Player", "OwnerName" }) do
      local getAttribute2 = value2:GetAttribute(value5)

      if typeof(getAttribute2) == "string" and getAttribute2 ~= "" then
        local findFirstChild2 = players:FindFirstChild(getAttribute2)

        if findFirstChild2 then
          return findFirstChild2.Name
        end

        return getAttribute2
      end
    end

    local findFirstChild3 = players:FindFirstChild(value2.Name)

    if findFirstChild3 then
      return findFirstChild3.Name
    end

    return value2.Name
  end
end

local function f2(value6)
  if not value6 or not value6:IsA("Model") then
    return false
  elseif value6 == localPlayer.Character then
    return true
  elseif value6.Name == localPlayer.Name then
    return true
  elseif value6.Name == localPlayer.DisplayName then
    return true
  else
    local userId = value6:GetAttribute("UserId")
    local playerUserId = value6:GetAttribute("PlayerUserId")

    if userId == localPlayer.UserId then
      return true
    end

    if playerUserId == localPlayer.UserId then
      return true
    end

    return false
  end
end

local window = rayfield:CreateWindow({
  Name = "🎄 Forsaken | VelocityHUB",
  Icon = 0,
  LoadingTitle = "Loading...",
  LoadingSubtitle = "VelocityHUB",
  ShowText = "🎄 Forsaken | VelocityHUB",
  ToggleUIKeybind = "K",
  DisableBuildWarnings = true,
  ConfigurationSaving = { Enabled = false },
  Discord = { Enabled = false },
  KeySystem = false,
})

local mainTab = window:CreateTab("Main", 4483362458)

local function f3(p1)
  if not p1 then
    return nil
  end

  return p1:FindFirstChildOfClass("Humanoid")
end

local espTab = window:CreateTab("ESP", 4483362458)
mainTab:CreateSection("Auto")
local autoFarm = false

local function f4()
  return workspace:FindFirstChild("Players")
end

local function f5(p2)
  if not p2 then
    return nil
  else
    local humanoidRootPart = p2:FindFirstChild("HumanoidRootPart")

    if humanoidRootPart and humanoidRootPart:IsA("BasePart") then
      return humanoidRootPart
    end

    if p2.PrimaryPart then
      return p2.PrimaryPart
    end

    return p2:FindFirstChildWhichIsA("BasePart", true)
  end
end

local vector = Vector3.new(-3552, 12, 268)

local function f6()
  local v2, v3

  if typeof(mouse1click) == "function" then
    pcall(function() mouse1click() end)
    return
  else
    local currentCamera = workspace.CurrentCamera

    if not currentCamera then
      return
    else
      local viewportSize = currentCamera.ViewportSize
      v2 = viewportSize.X / 2
      v3 = viewportSize.Y / 2

      pcall(function()
        virtualInputManager:SendMouseButtonEvent(v2, v3, 0, true, game, 0)
        virtualInputManager:SendMouseButtonEvent(v2, v3, 0, false, game, 0)
      end)

      return
    end
  end
end

local v4 = false
local autoSafe = false
local v5 = false

local function f7(value7)
  local v6 = f4()

  if not v6 then
    return nil
  end

  return v6:FindFirstChild(value7)
end

local f8

local function f9()
  local survivors = f7("Survivors")

  if survivors then
    local v7 = f8(survivors)

    if v7 then
      return "Survivor", v7
    end
  end

  local killers = f7("Killers")

  if killers then
    local v8 = f8(killers)

    if v8 then
      return "Killer", v8
    end

    return nil, nil
  end

  return nil, nil
end

function f8(p3)
  if not p3 then
    return nil
  end

  for index4, value8 in ipairs(p3:GetChildren()) do
    if f2(value8) then
      return value8
    end
  end

  return nil
end

local function f10()
  local v9 = { f9() }
  local v10 = f5(v9[2])

  if not v10 and localPlayer.Character then
    v10 = f5(localPlayer.Character)
  end

  if not v10 then
    return nil
  else
    local v11 = nil
    local huge = math.huge
    local v12 = {}

    for index5, value9 in ipairs({ "Survivors", "Killers" }) do
      local v13 = f7(value9)

      if v13 then
        for index6, value10 in ipairs(v13:GetChildren()) do
          if value10:IsA("Model") and not v12[value10] and not f2(value10) then
            v12[value10] = true
            local v14 = f3(value10)
            local v15 = f5(value10)

            if v15 and (not v14 or v14.Health > 0) then
              local magnitude = (v10.Position - v15.Position).Magnitude

              if magnitude < huge then
                v11 = value10
                huge = magnitude
              end
            end
          end
        end
      end
    end

    return v11
  end
end

local function f11()
  local survivors2 = f7("Survivors")

  if not survivors2 then
    return nil
  else
    local v16 = { f9() }
    local v17 = f5(v16[2])

    if not v17 and localPlayer.Character then
      v17 = f5(localPlayer.Character)
    end

    if not v17 then
      return nil
    else
      local v18 = nil
      local huge2 = math.huge

      for index7, value11 in ipairs(survivors2:GetChildren()) do
        if value11:IsA("Model") and not f2(value11) then
          local v19 = f3(value11)
          local v20 = f5(value11)

          if v19 and v20 and v19.Health > 0 then
            local magnitude2 = (v17.Position - v20.Position).Magnitude

            if magnitude2 < huge2 then
              huge2 = magnitude2
              v18 = value11
            end
          end
        end
      end

      return v18
    end
  end
end

local function f12()
  local survivors3 = f7("Survivors")
  local v21 = { "None" }
  local v22 = { None = true }

  if not survivors3 then
    return v21
  end

  for index8, value12 in ipairs(survivors3:GetChildren()) do
    if value12:IsA("Model") and not f2(value12) then
      local v23 = f1(value12)

      if v23 and not v22[v23] then
        v22[v23] = true
        table.insert(v21, v23)
      end
    end
  end

  table.sort(v21, function(p4, p5)
    if p4 == "None" then
      return true
    end

    if p5 == "None" then
      return false
    end

    return p4:lower() < p5:lower()
  end)

  return v21
end

local v24

local function f13()
  local survivors4 = f7("Survivors")

  if not survivors4 or not v24 or v24 == "None" then
    return nil
  end

  for index9, value13 in ipairs(survivors4:GetChildren()) do
    if value13:IsA("Model") and not f2(value13) then
      if f1(value13) == v24 then
        return value13
      end
    end
  end

  return nil
end

local function f14(p6, p7)
  if not p6 or not p7 then
    return false
  elseif not p7.Parent then
    return false
  else
    local v25 = f3(p7)
    local v26 = f5(p7)
    local v27 = f5(p6)

    if not v25 or not v26 or not v27 then
      return false
    elseif v25.Health <= 0 then
      return false
    else
      local cframe = CFrame.new(0, 0, 2)

      v27.CFrame = CFrame.lookAt((v26.CFrame * cframe).Position, v26.Position)
      v27.AssemblyLinearVelocity = Vector3.zero
      v27.AssemblyAngularVelocity = Vector3.zero

      f6()
      return true
    end
  end
end

local v28

local function f15()
  if not autoFarm then
    v28 = nil
    return
  else
    local v29, v30 = f9()

    if v29 == "Survivor" then
      v28 = nil
      local v31 = f5(v30)

      if v31 then
        v31.CFrame = CFrame.new(vector)
        v31.AssemblyLinearVelocity = Vector3.zero
        v31.AssemblyAngularVelocity = Vector3.zero
      end

      return
    elseif v29 == "Killer" then
      if v5 and v24 and v24 ~= "None" then
        local v32 = f13()

        if v32 then
          local v33 = f3(v32)

          if not v33 or v33.Health <= 0 then
            v28 = nil
            return
          end

          if f14(v30, v32) then
            v28 = v32
          else
            v28 = nil
          end

          return
        end

        v28 = nil
        return
      end

      if not f5(v30) then
        v28 = nil
        return
      end

      if not v28 or not v28.Parent then
        v28 = f11()
      end

      if v28 then
        local v34 = f3(v28)
        local v35 = f5(v28)

        if not v34 or v34.Health <= 0 or not v35 then
          v28 = f11()
        else
          f14(v30, v28)
        end
      end

      return
    else
      v28 = nil
      return
    end
  end
end

mainTab:CreateToggle({
  Name = "Auto Farm",
  CurrentValue = false,
  Flag = "AutoFarm",
  Callback = function(value14)
    autoFarm = value14

    if not value14 then
      v28 = nil
    end
  end,
})

mainTab:CreateToggle({
  Name = "Auto Use Skills",
  CurrentValue = false,
  Flag = "AutoUseSkills",
  Callback = function(value15) v4 = value15 end,
})

local function f16()
  local survivors5 = f7("Survivors")

  if not survivors5 then
    return false
  end

  for index10, value16 in ipairs(survivors5:GetChildren()) do
    if f2(value16) and value16.Name == "Chance" then
      return true
    end
  end

  return false
end

local v36 = false

mainTab:CreateToggle({
  Name = "Auto Coin Flip",
  CurrentValue = false,
  Flag = "AutoCoinFlip",
  Callback = function(value17) v36 = value17 end,
})

task.spawn(function()
  while true do
    if v36 and f16() then
      task.wait(2)
    else
      task.wait(0.1)
    end
  end
end)

local function f17()
  return f8(f7("Survivors"))
end

local v38, v39

local function makePart()
  if v38 and v38.Parent then
    return
  end

  if not v39 or not v39.Parent then
    return
  else
    local autoSafePlatform = Instance.new("Part")
    autoSafePlatform.Name = "AutoSafePlatform"
    autoSafePlatform.Size = Vector3.new(10, 2, 10)
    autoSafePlatform.Anchored = true
    autoSafePlatform.CanCollide = true
    autoSafePlatform.CanTouch = false
    autoSafePlatform.CanQuery = true
    autoSafePlatform.CFrame = CFrame.new(v39.Position.X, v39.Position.Y + 10, v39.Position.Z)
    autoSafePlatform.Parent = workspace

    v38 = autoSafePlatform
    return
  end
end

local function f18()
  if v38 then
    if v38.Parent then
      v38:Destroy()
    end

    v38 = nil
  end
end

local function f19()
  if not v38 or not v38.Parent then
    return false
  end

  if not v39 or not v39.Parent then
    return false
  else
    local pointToObjectSpace = v38.CFrame:PointToObjectSpace(v39.Position)

    return math.abs(pointToObjectSpace.X) <= v38.Size.X / 2
      and math.abs(pointToObjectSpace.Z) <= v38.Size.Z / 2
      and v39.Position.Y >= v38.Position.Y + v38.Size.Y / 2 - 4
  end
end

local v40, v41, connect, health, f20

local function f21(p8)
  if not autoSafe then
    return
  end

  if not p8 or not p8:IsA("Model") then
    return
  else
    local v42 = f3(p8)
    local v43 = not v42
    local v44 = f5(p8)

    if v43 or not v44 then
      return
    end

    if connect then
      connect:Disconnect()
      connect = nil
    end

    v40 = p8
    v41 = v42
    v39 = v44
    health = v42.Health

    connect = v42.HealthChanged:Connect(function(p9)
      if not autoSafe then
        return
      end

      if health and p9 < health then
        makePart()
        task.defer(f20)
      end

      health = p9
    end)

    return
  end
end

function f20()
  if not v38 or not v38.Parent then
    return
  end

  if not v39 or not v39.Parent then
    return
  end

  v39.CFrame = CFrame.new(v38.Position.X, v38.Position.Y + v38.Size.Y / 2 + 3, v38.Position.Z)
  v39.AssemblyLinearVelocity = Vector3.zero
  v39.AssemblyAngularVelocity = Vector3.zero
end

local function f22()
  if connect then
    connect:Disconnect()
    connect = nil
  end

  f18()
  v40 = nil
  v41 = nil
  v39 = nil
  health = nil
end

local function f23()
  if not autoSafe then
    return
  else
    local v45 = f17()

    if v45 and v45 ~= v40 then
      f21(v45)
    elseif v45 and (not v41 or not v41.Parent or not v39 or not v39.Parent) then
      f21(v45)
    end

    return
  end
end

mainTab:CreateToggle({
  Name = "Auto Safe(Kick Risk)",
  CurrentValue = false,
  Flag = "AutoSafe",
  Callback = function(value18)
    autoSafe = value18

    if value18 then
      f23()
    else
      f22()
    end
  end,
})

mainTab:CreateSection("Buttons")

mainTab:CreateButton({
  Name = "Safe Place(Kick Risk)",
  Callback = function()
    local v46 = f17()

    if not v46 then
      return
    else
      local v47 = f5(v46)

      if not v47 then
        return
      end

      v40 = v46
      v39 = v47
      makePart()
      f20()
      return
    end
  end,
})

mainTab:CreateButton({
  Name = "TP Player",
  Callback = function()
    local v48 = f10()

    if not v48 then
      return
    else
      local v49 = f5(v48)

      if not v49 then
        return
      else
        local v50 = { f9() }
        local v51 = f5(v50[2])

        if not v51 and localPlayer.Character then
          v51 = f5(localPlayer.Character)
        end

        if not v51 then
          return
        else
          local cframe2 = CFrame.new(0, 0, 3)

          v51.CFrame = CFrame.lookAt((v49.CFrame * cframe2).Position, v49.Position)
          v51.AssemblyLinearVelocity = Vector3.zero
          v51.AssemblyAngularVelocity = Vector3.zero

          return
        end
      end
    end
  end,
})

local v52 = false

local function f24()
  if v52 then
    return
  end

  v52 = true

  task.spawn(function()
    while v52 do
      local v53, v54 = f9()

      if v53 ~= "Killer" then
        break
      elseif not f7("Survivors") then
        break
      else
        local v55 = f5(v54)

        if not v55 then
          break
        else
          local v56 = f11()

          if not v56 then
            break
          end

          while v52 and v56 and v56.Parent do
            local v57 = f3(v56)
            local v58 = not v57
            local v59 = f5(v56)

            if v58 or v57.Health <= 0 or not v59 then
              break
            else
              local cframe3 = CFrame.new(0, 0, 2)

              v55.CFrame = CFrame.lookAt((v59.CFrame * cframe3).Position, v59.Position)
              v55.AssemblyLinearVelocity = Vector3.zero
              v55.AssemblyAngularVelocity = Vector3.zero

              f6()
              task.wait(0.05)
            end
          end

          task.wait(0.05)
        end
      end
    end

    v52 = false
  end)
end

mainTab:CreateButton({ Name = "Kill All", Callback = function() f24() end })
mainTab:CreateSection("Target")

local targetPlayerDropdown = mainTab:CreateDropdown({
  Name = "Target Player",
  Options = { "None" },
  CurrentOption = { "None" },
  MultipleOptions = false,
  Flag = "TargetPlayer",
  Callback = function(value19)
    local v60 = value19[1]

    if not v60 then
      v60 = "None"
    end

    v24 = v60

    if v60 ~= "None" then
      v37 = f13()
    end
  end,
})

mainTab:CreateToggle({
  Name = "Target With Killer",
  CurrentValue = false,
  Flag = "TargetWithKiller",
  Callback = function(value20)
    v5 = value20
    v28 = nil

    if value20 then
      if not f13() then
        v24 = nil
        pcall(function() targetPlayerDropdown:Set({ "None" }) end)
      end
    end
  end,
})

task.spawn(function()
  while true do
    pcall(function()
      local v61 = f12()
      local v62 = false

      if v24 then
        for index11, value21 in ipairs(v61) do
          if value21 == v24 then
            v62 = true
            break
          end
        end
      end

      targetPlayerDropdown:Refresh(v61)

      if not v62 then
        v24 = nil
      else
        v37 = f13()
      end
    end)

    task.wait(0.5)
  end
end)

espTab:CreateSection("ESP Players")

local v63 = {
  Survivors = {
    Enabled = false,
    ShowDistance = false,
    ShowHealth = false,
    Color = Color3.fromRGB(0, 255, 0),
  },
  Killers = {
    Enabled = false,
    ShowDistance = false,
    ShowHealth = false,
    Color = Color3.fromRGB(255, 0, 0),
  },
}

local v64 = { Survivors = {}, Killers = {} }

local function f25(p10)
  if not p10 then
    return nil
  else
    local head = p10:FindFirstChild("Head")

    if head and head:IsA("BasePart") then
      return head
    else
      local humanoidRootPart2 = p10:FindFirstChild("HumanoidRootPart")

      if humanoidRootPart2 and humanoidRootPart2:IsA("BasePart") then
        return humanoidRootPart2
      end

      return p10:FindFirstChildWhichIsA("BasePart", true)
    end
  end
end

local function f26(key, key2)
  local v65 = v64[key2][key]

  if v65 then
    if v65.InfoGui then
      v65.InfoGui:Destroy()
    end

    v65.InfoGui = nil
    v65.InfoText = nil
    v65.AttachPart = nil
  end

  local v66 = f25(key)

  if v66 then
    local espInfo = v66:FindFirstChild("ESP_Info")

    if espInfo then
      espInfo:Destroy()
    end
  end
end

local function makeTextLabel(key3, key4)
  local v67 = v63[key4]
  f26(key3, key4)

  if not v67.ShowDistance and not v67.ShowHealth then
    return
  else
    local v68 = f25(key3)

    if not v68 then
      return
    else
      local espInfo2 = Instance.new("BillboardGui")
      espInfo2.Name = "ESP_Info"
      espInfo2.Adornee = v68
      espInfo2.AlwaysOnTop = true
      espInfo2.Size = UDim2.fromOffset(220, 70)
      espInfo2.StudsOffset = Vector3.new(0, 3.5, 0)
      espInfo2.MaxDistance = 2000
      espInfo2.ResetOnSpawn = false
      espInfo2.Parent = v68

-- https://discord.gg/AwGHNh7Z7T
      local info = Instance.new("TextLabel")
      info.Name = "Info"
      info.BackgroundTransparency = 1
      info.Size = UDim2.fromScale(1, 1)
      info.Font = Enum.Font.Arcade
      info.Text = ""
      info.TextColor3 = v67.Color
      info.TextStrokeColor3 = Color3.new(0, 0, 0)
      info.TextStrokeTransparency = 0
      info.TextSize = 24
      info.TextWrapped = true
      info.Parent = espInfo2

      local v69 = v64[key4][key3]

      local v70 = v64[key4]
      v70[key3] = v69 or {}

      v64[key4][key3].InfoGui = espInfo2
      v64[key4][key3].InfoText = info
      v64[key4][key3].AttachPart = v68

      return
    end
  end
end

local function makeHighlight(key5, key6)
  if not key5 or not key5:IsA("Model") then
    return
  else
    local v71 = v63[key6]

    local v72 = v64[key6]
    v72[key5] = v64[key6][key5] or {}

    local v73 = v64[key6][key5]
    local espHighlight = v73.Highlight

    if not espHighlight or not espHighlight.Parent then
      local espHighlight2 = key5:FindFirstChild("ESP_Highlight")

      if espHighlight2 then
        espHighlight2:Destroy()
      end

      espHighlight = Instance.new("Highlight")
      espHighlight.Name = "ESP_Highlight"
      espHighlight.Adornee = key5
      espHighlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
      espHighlight.FillTransparency = 0.45
      espHighlight.OutlineTransparency = 0
      espHighlight.Parent = key5

      v73.Highlight = espHighlight
    end

    espHighlight.FillColor = v71.Color
    espHighlight.OutlineColor = v71.Color

    makeTextLabel(key5, key6)
    return
  end
end

local f27

local function f28(key7)
  local v74 = f7(key7)

  if not v74 then
    return
  elseif not v63[key7].Enabled then
    local v75 = {}

    for key8 in pairs(v64[key7]) do
      table.insert(v75, key8)
    end

    for index12, value22 in ipairs(v75) do
      f27(value22, key7)
    end

    return
  else
    local v76 = {}

    for index13, value23 in ipairs(v74:GetChildren()) do
      if value23:IsA("Model") then
        v76[value23] = true
        makeHighlight(value23, key7)
      end
    end

    for key9 in pairs(v64[key7]) do
      if not v76[key9] then
        f27(key9, key7)
      end
    end

    return
  end
end

function f27(key10, key11)
  local v77 = v64[key11][key10]

  if v77 then
    if v77.Highlight then
      v77.Highlight:Destroy()
    end

    if v77.InfoGui then
      v77.InfoGui:Destroy()
    end
  end

  v64[key11][key10] = nil
end

espTab:CreateToggle({
  Name = "ESP Survivors",
  CurrentValue = false,
  Flag = "ESPSurvivors",
  Callback = function(value24)
    v63.Survivors.Enabled = value24
    f28("Survivors")
  end,
})

espTab:CreateToggle({
  Name = "Show Distance",
  CurrentValue = false,
  Flag = "SurvivorDistance",
  Callback = function(value25)
    v63.Survivors.ShowDistance = value25
    f28("Survivors")
  end,
})

espTab:CreateToggle({
  Name = "Show Health",
  CurrentValue = false,
  Flag = "SurvivorHealth",
  Callback = function(value26)
    v63.Survivors.ShowHealth = value26
    f28("Survivors")
  end,
})

espTab:CreateColorPicker({
  Name = "Survivor Color",
  Color = Color3.fromRGB(0, 255, 0),
  Flag = "SurvivorColor",
  Callback = function(value27)
    v63.Survivors.Color = value27
    f28("Survivors")
  end,
})

espTab:CreateToggle({
  Name = "ESP Killers",
  CurrentValue = false,
  Flag = "ESPKillers",
  Callback = function(value28)
    v63.Killers.Enabled = value28
    f28("Killers")
  end,
})

espTab:CreateToggle({
  Name = "Show Distance",
  CurrentValue = false,
  Flag = "KillerDistance",
  Callback = function(value29)
    v63.Killers.ShowDistance = value29
    f28("Killers")
  end,
})

espTab:CreateToggle({
  Name = "Show Health",
  CurrentValue = false,
  Flag = "KillerHealth",
  Callback = function(value30)
    v63.Killers.ShowHealth = value30
    f28("Killers")
  end,
})

espTab:CreateColorPicker({
  Name = "Killer Color",
  Color = Color3.fromRGB(255, 0, 0),
  Flag = "KillerColor",
  Callback = function(value31)
    v63.Killers.Color = value31
    f28("Killers")
  end,
})

task.spawn(function()
  local v78 = { Survivors = nil, Killers = nil }
  local v79 = { Survivors = nil, Killers = nil }

  while true do
    pcall(function()
      for index14, value32 in ipairs({ "Survivors", "Killers" }) do
        local v80 = value32
        local v81 = f7(v80)

        if v81 ~= v79[v80] then
          if v78[v80] then
            v78[v80]:Disconnect()
            v78[v80] = nil
          end

          local v82 = {}

          for key12 in pairs(v64[v80]) do
            table.insert(v82, key12)
          end

          for index15, value33 in ipairs(v82) do
            f27(value33, v80)
          end

          v79[v80] = v81

          if v81 then
            v78[v80] = v81.ChildAdded:Connect(function(child)
              if v63[v80].Enabled and child:IsA("Model") then
                task.wait(0.05)
                makeHighlight(child, v80)
              end
            end)

            v81.ChildRemoved:Connect(function(child2) f27(child2, v80) end)
            f28(v80)
          end
        end
      end
    end)

    task.wait(0.5)
  end
end)

runService.RenderStepped:Connect(function()
  pcall(function()
    local currentCamera2 = workspace.CurrentCamera

    if not currentCamera2 then
      return
    end

    for key13, value34 in pairs(v64) do
      local v83 = v63[key13]

      if v83 and v83.Enabled then
        for key14, value35 in pairs(value34) do
          if key14 and key14.Parent and value35.InfoText then
            local v84 = f5(key14)
            local v85 = f3(key14)

            if v84 then
              local magnitude3 = (currentCamera2.CFrame.Position - v84.Position).Magnitude
              local v86 = {}

              if v83.ShowDistance then
                table.insert(v86, math.floor(magnitude3 + 0.5) .. " studs")
              end

              if v83.ShowHealth and v85 then
                local maxHealth = v85.MaxHealth

                if maxHealth > 0 then
                  local v87 = math.floor(v85.Health / maxHealth * 100 + 0.5)
                  local v88 = math.clamp(v87, 0, 100)
                  table.insert(v86, v88 .. "%")
                end
              end

              value35.InfoText.Text = table.concat(v86, "\n")
              value35.InfoText.TextSize = math.clamp(32 - magnitude3 * 0.05, 10, 32)
              value35.InfoText.TextColor3 = v83.Color
            end
          end
        end
      end
    end
  end)
end)

espTab:CreateSection("ESP Generators")
local v89 = { Enabled = false, ShowDistance = false, Color = Color3.fromRGB(0, 170, 255) }
local v90 = {}
local v91 = {}
local f29

local function f30()
  local v92 = f29()

  if not v92 then
    return {}
  else
    local v93 = {}
    local v94 = {}

    if v92:IsA("Model") then
      v94[v92] = true
      table.insert(v93, v92)
    end

    for index16, value36 in ipairs(v92:GetDescendants()) do
      if value36:IsA("Model") and not v94[value36] then
        v94[value36] = true
        table.insert(v93, value36)
      end
    end

    return v93
  end
end

local function f31(p11)
  if not p11 then
    return nil
  end

  if p11.PrimaryPart then
    return p11.PrimaryPart
  end

  return p11:FindFirstChildWhichIsA("BasePart", true)
end

function f29()
  local map = workspace:FindFirstChild("Map")

  if not map then
    return nil
  else
    local ingame = map:FindFirstChild("Ingame")

    if not ingame then
      return nil
    else
      local map2 = ingame:FindFirstChild("Map")

      if not map2 then
        return nil
      end

      return map2:FindFirstChild("Generator")
    end
  end
end

local function makeTextLabel2(value37)
  if not v89.ShowDistance then
    return
  else
    local v95 = f31(value37)

    if not v95 then
      return
    elseif v95:FindFirstChild("Generator_Info") then
      return
    else
      local generatorInfo = Instance.new("BillboardGui")
      generatorInfo.Name = "Generator_Info"
      generatorInfo.Adornee = v95
      generatorInfo.AlwaysOnTop = true
      generatorInfo.Size = UDim2.fromOffset(200, 40)
      generatorInfo.StudsOffset = Vector3.new(0, 3, 0)
      generatorInfo.MaxDistance = 2000
      generatorInfo.Parent = v95

      local textLabel = Instance.new("TextLabel")
      textLabel.BackgroundTransparency = 1
      textLabel.Size = UDim2.fromScale(1, 1)
      textLabel.Font = Enum.Font.Arcade
      textLabel.Text = "0 studs"
      textLabel.TextColor3 = v89.Color
      textLabel.TextStrokeColor3 = Color3.new(0, 0, 0)
      textLabel.TextStrokeTransparency = 0
      textLabel.TextSize = 24
      textLabel.Parent = generatorInfo

      v90[value37] = v90[value37] or {}
      v90[value37].DistanceGui = generatorInfo
      v90[value37].DistanceText = textLabel
      v90[value37].AttachPart = v95

      return
    end
  end
end

local function makeHighlight2(value38)
  if not value38 or not value38:IsA("Model") then
    return
  else
    local v96 = v90[value38]

    if v96 and v96.Highlight and v96.Highlight.Parent then
      return
    else
      local generatorESP = Instance.new("Highlight")
      generatorESP.Name = "Generator_ESP"
      generatorESP.Adornee = value38
      generatorESP.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
      generatorESP.FillColor = v89.Color
      generatorESP.OutlineColor = v89.Color
      generatorESP.FillTransparency = 0.45
      generatorESP.OutlineTransparency = 0
      generatorESP.Parent = value38

      v90[value38] = v90[value38] or {}
      v90[value38].Highlight = generatorESP

      makeTextLabel2(value38)
      return
    end
  end
end

local f32

local function f33()
  if not v89.Enabled then
    for key15 in pairs(v90) do
      f32(key15)
    end

    return
  else
    local v97 = {}

    for index17, value39 in ipairs(f30()) do
      v97[value39] = true
      makeHighlight2(value39)
      local v98 = v90[value39]

      if v98 then
        if v98.Highlight then
          v98.Highlight.FillColor = v89.Color
          v98.Highlight.OutlineColor = v89.Color
        end

        if v89.ShowDistance then
          if not v98.DistanceText then
            makeTextLabel2(value39)
          end
        elseif v98.DistanceGui then
          v98.DistanceGui:Destroy()
          v98.DistanceGui = nil
          v98.DistanceText = nil
          v98.AttachPart = nil
        end
      end
    end

    for key16 in pairs(v90) do
      if not v97[key16] then
        f32(key16)
      end
    end

    return
  end
end

function f32(key17)
  local v99 = v90[key17]

  if v99 then
    if v99.Highlight then
      v99.Highlight:Destroy()
    end

    if v99.DistanceGui then
      v99.DistanceGui:Destroy()
    end
  end

  v90[key17] = nil
end

espTab:CreateToggle({
  Name = "ESP Generators",
  CurrentValue = false,
  Flag = "ESPGenerators",
  Callback = function(value40)
    v89.Enabled = value40
    f33()
  end,
})

espTab:CreateToggle({
  Name = "Show Distance",
  CurrentValue = false,
  Flag = "GeneratorDistance",
  Callback = function(value41)
    v89.ShowDistance = value41
    f33()
  end,
})

espTab:CreateColorPicker({
  Name = "Generator Color",
  Color = Color3.fromRGB(0, 170, 255),
  Flag = "GeneratorColor",
  Callback = function(value42)
    v89.Color = value42

    for key18, value43 in pairs(v90) do
      if value43.Highlight then
        value43.Highlight.FillColor = value42
        value43.Highlight.OutlineColor = value42
      end

      if value43.DistanceText then
        value43.DistanceText.TextColor3 = value42
      end
    end
  end,
})

espTab:CreateSection("ESP Items")

local v100 = { Enabled = false, ShowName = false, Color = Color3.fromRGB(255, 255, 255) }
local v101 = {}
local v102 = {}

local function f34(key19)
  local v103 = v101[key19]

  if v103 then
    if v103.Highlight then
      v103.Highlight:Destroy()
    end

    if v103.NameGui then
      v103.NameGui:Destroy()
    end
  end

  v101[key19] = nil
end

local f35

local function f36()
  local v104 = f35()

  if not v104 then
    return {}
  else
    local v105 = {}
    local v106 = {}

    for index18, value44 in ipairs(v104:GetDescendants()) do
      if value44:IsA("Tool") and not v106[value44] then
        v106[value44] = true
        table.insert(v105, value44)
      end
    end

    return v105
  end
end

function f35()
  local map3 = workspace:FindFirstChild("Map")

  if not map3 then
    return nil
  else
    local ingame2 = map3:FindFirstChild("Ingame")

    if not ingame2 then
      return nil
    end

    return ingame2:FindFirstChild("Map")
  end
end

local f37

local function f38(key20)
  local v107 = v101[key20]

  if v107 then
    if v107.NameGui then
      v107.NameGui:Destroy()
    end

    v107.NameGui = nil
    v107.NameText = nil
    v107.AttachPart = nil
  end

  local v108 = f37(key20)

  if v108 then
    local itemName = v108:FindFirstChild("Item_Name")

    if itemName then
      itemName:Destroy()
    end
  end
end

function f37(p12)
  if not p12 then
    return nil
  else
    local handle = p12:FindFirstChild("Handle")

    if handle and handle:IsA("BasePart") then
      return handle
    end

    if p12.PrimaryPart then
      return p12.PrimaryPart
    end

    return p12:FindFirstChildWhichIsA("BasePart", true)
  end
end

local f39

local function makeHighlight3(value45)
  if not value45 or not value45:IsA("Tool") then
    return
  else
    local v109 = v101[value45]

    if v109 and v109.Highlight and v109.Highlight.Parent then
      v109.Highlight.FillColor = v100.Color
      v109.Highlight.OutlineColor = v100.Color

      if v100.ShowName and not v109.NameText then
        f39(value45)
      end

      return
    else
      local itemESP = value45:FindFirstChild("Item_ESP")

      if itemESP then
        itemESP:Destroy()
      end

      local itemESP2 = Instance.new("Highlight")
      itemESP2.Name = "Item_ESP"
      itemESP2.Adornee = value45
      itemESP2.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
      itemESP2.FillColor = v100.Color
      itemESP2.OutlineColor = v100.Color
      itemESP2.FillTransparency = 0.4
      itemESP2.OutlineTransparency = 0
      itemESP2.Parent = value45

      v101[value45] = v101[value45] or {}
      v101[value45].Highlight = itemESP2

      if v100.ShowName then
        f39(value45)
      end

      return
    end
  end
end

function f39(key21)
  if not v100.ShowName then
    return
  else
    local v110 = f37(key21)

    if not v110 then
      return
    else
      f38(key21)

      local itemName2 = Instance.new("BillboardGui")
      itemName2.Name = "Item_Name"
      itemName2.Adornee = v110
      itemName2.AlwaysOnTop = true
      itemName2.Size = UDim2.fromOffset(220, 40)
      itemName2.StudsOffset = Vector3.new(0, 2.5, 0)
      itemName2.MaxDistance = 2000
      itemName2.Parent = v110

      local name = Instance.new("TextLabel")
      name.Name = "Name"
      name.BackgroundTransparency = 1
      name.Size = UDim2.fromScale(1, 1)
      name.Font = Enum.Font.Arcade
      name.Text = key21.Name
      name.TextColor3 = v100.Color
      name.TextStrokeColor3 = Color3.new(0, 0, 0)
      name.TextStrokeTransparency = 0
      name.TextSize = 22
      name.TextWrapped = true
      name.Parent = itemName2

      v101[key21] = v101[key21] or {}
      v101[key21].NameGui = itemName2
      v101[key21].NameText = name
      v101[key21].AttachPart = v110

      return
    end
  end
end

local function f40()
  if not v100.Enabled then
    for key22 in pairs(v101) do
      f34(key22)
    end

    return
  else
    local v111 = {}

    for index19, value46 in ipairs(f36()) do
      v111[value46] = true
      makeHighlight3(value46)
      local v112 = v101[value46]

      if v112 then
        if v112.Highlight then
          v112.Highlight.FillColor = v100.Color
          v112.Highlight.OutlineColor = v100.Color
        end

        if v100.ShowName then
          if not v112.NameText then
            f39(value46)
          end
        elseif v112.NameGui then
          v112.NameGui:Destroy()
          v112.NameGui = nil
          v112.NameText = nil
          v112.AttachPart = nil
        end
      end
    end

    for key23 in pairs(v101) do
      if not v111[key23] then
        f34(key23)
      end
    end

    return
  end
end

espTab:CreateToggle({
  Name = "ESP Items",
  CurrentValue = false,
  Flag = "ESPItems",
  Callback = function(value47)
    v100.Enabled = value47
    f40()
  end,
})

espTab:CreateToggle({
  Name = "Show Name",
  CurrentValue = false,
  Flag = "ItemShowName",
  Callback = function(value48)
    v100.ShowName = value48
    f40()
  end,
})

espTab:CreateColorPicker({
  Name = "Item Color",
  Color = Color3.fromRGB(255, 255, 255),
  Flag = "ItemColor",
  Callback = function(value49)
    v100.Color = value49

    for key24, value50 in pairs(v101) do
      if value50.Highlight then
        value50.Highlight.FillColor = value49
        value50.Highlight.OutlineColor = value49
      end

      if value50.NameText then
        value50.NameText.TextColor3 = value49
      end
    end
  end,
})

task.spawn(function()
  while true do
    pcall(function() f15() end)
    task.wait(0.05)
  end
end)

task.spawn(function()
  while true do
    if v4 then
      task.wait(2)
    else
      task.wait(0.1)
    end
  end
end)

task.spawn(function()
  while true do
    pcall(function()
      if autoSafe then
        f23()

        if v38 and v38.Parent then
          if not f19() then
            f18()
          end
        end
      end
    end)

    task.wait(0.1)
  end
end)

local v113

task.spawn(function()
  while true do
    pcall(function()
      local v114 = f29()

      if v114 ~= v113 then
        for key25 in pairs(v90) do
          f32(key25)
        end

        for index20, value51 in ipairs(v91) do
        end

        v91 = {}
        v113 = v114

        if v114 then
          local descendantAdded = v114.DescendantAdded

          table.insert(v91, descendantAdded:Connect(function(p13)
            if v89.Enabled and p13:IsA("Model") then
              task.wait(0.05)
              makeHighlight2(p13)
            end
          end))

          local descendantRemoving = v114.DescendantRemoving

          table.insert(v91, descendantRemoving:Connect(function(key26)
            if v90[key26] then
              f32(key26)
            end
          end))

          f33()
        end
      end
    end)

    task.wait(0.5)
  end
end)

local v115

task.spawn(function()
  while true do
    pcall(function()
      local v116 = f35()

      if v116 ~= v115 then
        for key27 in pairs(v101) do
          f34(key27)
        end

        for index21, value52 in ipairs(v102) do
        end

        v102 = {}
        v115 = v116

        if v116 then
          local descendantAdded2 = v116.DescendantAdded

          table.insert(v102, descendantAdded2:Connect(function(p14)
            if v100.Enabled and p14:IsA("Tool") then
              task.wait(0.05)
              makeHighlight3(p14)
            end
          end))

          local descendantRemoving2 = v116.DescendantRemoving

          table.insert(v102, descendantRemoving2:Connect(function(key28)
            if v101[key28] then
              f34(key28)
            end
          end))

          f40()
        end
      end
    end)

    task.wait(0.5)
  end
end)

runService.RenderStepped:Connect(function()
  pcall(function()
    local currentCamera3 = workspace.CurrentCamera

    if not currentCamera3 then
      return
    end

    for key29, value53 in pairs(v64) do
      local v117 = v63[key29]

      if v117 and v117.Enabled then
        for key30, value54 in pairs(value53) do
          if key30 and key30.Parent and value54.InfoText then
            local v118 = f5(key30)
            local v119 = f3(key30)

            if v118 then
              local magnitude4 = (currentCamera3.CFrame.Position - v118.Position).Magnitude
              local v120 = {}

              if v117.ShowDistance then
                table.insert(v120, math.floor(magnitude4 + 0.5) .. " studs")
              end

              if v117.ShowHealth and v119 then
                local maxHealth2 = v119.MaxHealth

                if maxHealth2 > 0 then
                  local v121 = math.floor(v119.Health / maxHealth2 * 100 + 0.5)
                  local v122 = math.clamp(v121, 0, 100)
                  table.insert(v120, v122 .. "%")
                end
              end

              value54.InfoText.Text = table.concat(v120, "\n")
              value54.InfoText.TextSize = math.clamp(32 - magnitude4 * 0.05, 10, 32)
              value54.InfoText.TextColor3 = v117.Color
            end
          end
        end
      end
    end
  end)
end)

runService.RenderStepped:Connect(function()
  pcall(function()
    if not v89.Enabled or not v89.ShowDistance then
      return
    else
      local currentCamera4 = workspace.CurrentCamera

      if not currentCamera4 then
        return
      end

      for key31, value55 in pairs(v90) do
        if key31 and key31.Parent and value55.AttachPart and value55.DistanceText then
          local magnitude5 = (currentCamera4.CFrame.Position
            - value55.AttachPart.Position).Magnitude

          value55.DistanceText.Text = math.floor(magnitude5 + 0.5) .. " studs"
          value55.DistanceText.TextSize = math.clamp(32 - magnitude5 * 0.05, 10, 32)
        end
      end

      return
    end
  end)
end)


