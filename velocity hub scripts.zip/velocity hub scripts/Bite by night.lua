-- YALL SHIT SO ASS MEDALWARE EASY DEOBF

local players = game:GetService("Players")
local runService = game:GetService("RunService")
local localPlayer = players.LocalPlayer

repeat
  task.wait()
until localPlayer.Character

local window = loadstring(game:HttpGet("https://sirius.menu/rayfield"))():CreateWindow({
  Name = "VELOCITY HUB | Bite By Night",
  LoadingTitle = "Loading...",
  LoadingSubtitle = "Bite By Night",
  ConfigurationSaving = { Enabled = false },
})

local survivorTab = window:CreateTab("Survivor", 4483362458)
local killerTab = window:CreateTab("Killer", 4483362458)
local playerTab = window:CreateTab("Player", 4483362458)
local espKiller = false
local v1 = {}
local v2, f1

local function makeHighlight()
  local v3 = f1()

  if not v3 then
    return
  else
    local v4 = v3:GetChildren()[1]

    if not v4 then
      return
    else
      if v2 then
        v2:Destroy()
      end

      local highlight = Instance.new("Highlight")
      highlight.FillColor = Color3.fromRGB(255, 0, 0)
      highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
      highlight.Adornee = v4
      highlight.Parent = v4

      v2 = highlight
      return
    end
  end
end

function f1()
  return workspace:FindFirstChild("PLAYERS") and workspace.PLAYERS:FindFirstChild("KILLER")
end

local function f2()
  for index, value in ipairs(v1) do
  end

  v1 = {}
  local v5 = f1()

  if not v5 then
    return
  else
    local childAdded = v5.ChildAdded

    table.insert(v1, childAdded:Connect(function()
      if espKiller then
        task.wait(0.1)
        makeHighlight()
      end
    end))

    return
  end
end

survivorTab:CreateToggle({
  Name = "ESP Killer",
  Callback = function(value2)
    espKiller = value2

    if value2 then
      makeHighlight()
      f2()
    elseif v2 then
      v2:Destroy()
    end
  end,
})

local function f3()
  return workspace.MAPS and workspace.MAPS["GAME MAP"] and workspace.MAPS["GAME MAP"].Generators
end

local espGenerators = {}

local function makeHighlight2(value3)
  if value3.Name ~= "Generator" or espGenerators[value3] then
    return
  else
    local highlight2 = Instance.new("Highlight")
    highlight2.FillColor = Color3.fromRGB(0, 0, 255)
    highlight2.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    highlight2.Adornee = value3
    highlight2.Parent = value3

    espGenerators[value3] = highlight2
    return
  end
end

survivorTab:CreateToggle({
  Name = "ESP Generators",
  Callback = function(value4)
    if value4 then
      local v6 = f3()

      if not v6 then
        return
      end

      for index2, value5 in ipairs(v6:GetChildren()) do
        makeHighlight2(value5)
      end

      v6.ChildAdded:Connect(makeHighlight2)
      return
    end

    for key, value6 in pairs(espGenerators) do
      value6:Destroy()
    end

    espGenerators = {}
  end,
})

local v7 = {}
local v8 = false

local function f4()
  return workspace:FindFirstChild("PLAYERS") and workspace.PLAYERS:FindFirstChild("ALIVE")
end

local f5

local function f6()
  local v9 = f4()

  if not v9 then
    return
  end

  for index3, value7 in ipairs(v9:GetChildren()) do
    f5(value7)
  end

  v9.ChildAdded:Connect(function(child)
    if v8 then
      task.wait(0.1)
      f5(child)
    end
  end)
end

function f5(key2)
  if not key2 or v7[key2] then
    return
  else
    local highlight3 = Instance.new("Highlight")
    highlight3.FillColor = Color3.fromRGB(255, 255, 255)
    highlight3.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    highlight3.Adornee = key2
    highlight3.Parent = key2

    v7[key2] = highlight3
    return
  end
end

-- https://discord.gg/AwGHNh7Z7T
killerTab:CreateToggle({
  Name = "ESP Players",
  Callback = function(value8)
    v8 = value8

    if value8 then
      f6()
    else
      for key3, value9 in pairs(v7) do
        value9:Destroy()
      end

      v7 = {}
    end
  end,
})

local autoKill = false
local cframe = CFrame.new(0, 0, 2)

local function f7()
  local players2 = workspace:FindFirstChild("PLAYERS")

  return players2 and players2:FindFirstChild("KILLER")
    and players2.KILLER:FindFirstChild(localPlayer.Name)
end

local function f8()
  local v10 = f4()

  if not v10 then
    return
  end

  for index4, value10 in ipairs(v10:GetChildren()) do
    if value10.Name ~= localPlayer.Name then
      return value10
    end
  end
end

local function f9(p1)
  local humanoidRootPart = localPlayer.Character
    and localPlayer.Character:FindFirstChild("HumanoidRootPart")

  local humanoidRootPart2 = p1 and p1:FindFirstChild("HumanoidRootPart")

  if humanoidRootPart and humanoidRootPart2 then
    humanoidRootPart.CFrame = humanoidRootPart2.CFrame * cframe
  end
end

local function f10()
  local tool = localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Tool")

  if tool then
    tool:Activate()
  end
end

local v11

task.spawn(function()
  while true do
    task.wait(0.1)

    if not autoKill or not f7() then
      v11 = nil
    else
      local v12 = f4()

      if v12 then
        if not v11 then
          v11 = f8()
        end

        if v11 and v11.Parent ~= v12 then
          v11 = nil
        elseif v11 then
          f9(v11)
          f10()
          task.wait(3)
        end
      end
    end
  end
end)

killerTab:CreateToggle({
  Name = "Auto Kill",
  Callback = function(value11)
    autoKill = value11

    if not value11 then
      v11 = nil
    end
  end,
})

local autoFarm = false
local v13 = 0
local v14 = false

local function f11()
  return workspace:FindFirstChild("PLAYERS") and workspace.PLAYERS:FindFirstChild("ALIVE")
end

task.spawn(function()
  while true do
    task.wait(0.2)

    if not autoFarm then
      v14 = false
      v13 = 0
    else
      local character = localPlayer.Character
      local humanoidRootPart3 = character and character:FindFirstChild("HumanoidRootPart")
      local v15 = not humanoidRootPart3
      local v16 = f11()

      if not (v15 or not v16) then
        if not v16:FindFirstChild(localPlayer.Name) then
          v14 = false
          v13 = 0
        else
          if v13 == 0 then
            v13 = tick()
          end

          if not v14 and tick() - v13 >= 2 then
            humanoidRootPart3.CFrame = humanoidRootPart3.CFrame + Vector3.new(0, 100, 0)
            v14 = true
          end

          local v17 = workspace:FindFirstChild("GAME")
          local timer = v17 and v17:FindFirstChild("TIMER")

          if timer and timer:IsA("NumberValue") and timer.Value >= 360 then
            local escapePoint = workspace:FindFirstChild("MAPS")
              and workspace.MAPS:FindFirstChild("GAME MAP")
              and workspace.MAPS["GAME MAP"]:FindFirstChild("Escapes")
              and workspace.MAPS["GAME MAP"].Escapes:FindFirstChild("EscapePoint")

            if escapePoint then
              humanoidRootPart3.CFrame = escapePoint.CFrame + Vector3.new(0, 3, 0)
            end
          end
        end
      end
    end
  end
end)

survivorTab:CreateToggle({
  Name = "Auto Farm",
  Callback = function(value12)
    autoFarm = value12

    if not value12 then
      v14 = false
      v13 = 0
    end
  end,
})

local noclip = false
playerTab:CreateToggle({ Name = "Noclip", Callback = function(value13) noclip = value13 end })

runService.Stepped:Connect(function()
  if noclip and localPlayer.Character then
    for index5, value14 in ipairs(localPlayer.Character:GetDescendants()) do
      if value14:IsA("BasePart") then
        value14.CanCollide = false
      end
    end
  end
end)