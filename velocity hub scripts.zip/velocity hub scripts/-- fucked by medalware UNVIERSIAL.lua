-- fucked by medalware
-- this uses infinite yeild as their universial LMFAOOOO
local lighting = game:GetService("Lighting")
local players = game:GetService("Players")
local runService = game:GetService("RunService")
local teleportService = game:GetService("TeleportService")
local userInputService = game:GetService("UserInputService")
local httpService = game:GetService("HttpService")
local localPlayer = players.LocalPlayer
local currentCamera = workspace.CurrentCamera
local rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()

local velocityHUBWindow = rayfield:CreateWindow({
  Name = "Velocity HUB",
  LoadingTitle = "Velocity HUB",
  LoadingSubtitle = "Universal Script",
  ConfigurationSaving = { Enabled = true, FolderName = "VelocityHub", FileName = "Universal" },
})

local espPlayers = false
local v1 = {}

local function f1()
  for key, value in pairs(v1) do
    if value then
      value:Destroy()
    end
  end

  table.clear(v1)
end

local v2 = false

local function f2(p1)
  return p1.Character
end

local function f3(p2)
  local v3 = f2(p2)
  return v3 and v3:FindFirstChild("HumanoidRootPart")
end

local function makeHighlight(key2)
  if key2 == localPlayer then
    return
  else
    local character = key2.Character

    if not character then
      return
    else
      local highlight = Instance.new("Highlight")
      highlight.FillColor = Color3.fromRGB(255, 0, 0)
      highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
      highlight.FillTransparency = 0.5
      highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
      highlight.Adornee = character
      highlight.Parent = character

      v1[key2] = highlight
      return
    end
  end
end

local v4

runService.RenderStepped:Connect(function()
  if v2 and v4 and v4.Character then
    local humanoidRootPart = v4.Character:FindFirstChild("HumanoidRootPart")

    if humanoidRootPart then
      currentCamera.CFrame = CFrame.new(
        currentCamera.CFrame.Position, humanoidRootPart.Position
      )
    end
  end
end)

local mainTab = velocityHUBWindow:CreateTab("Main", 4483362458)

mainTab:CreateButton({
  Name = "Open Infinite Yield",
  Callback = function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()
  end,
})

mainTab:CreateButton({
  Name = "Copy Game ID",
  Callback = function() setclipboard(game.PlaceId) end,
})

mainTab:CreateButton({ Name = "Copy Job ID", Callback = function() setclipboard(game.JobId) end })

mainTab:CreateButton({
  Name = "Rejoin Server",
  Callback = function() teleportService:Teleport(game.PlaceId, localPlayer) end,
})

mainTab:CreateButton({
  Name = "Server Hop",
  Callback = function() teleportService:Teleport(game.PlaceId) end,
})

mainTab:CreateButton({
  Name = "Reset Character",
  Callback = function() localPlayer.Character:BreakJoints() end,
})

mainTab:CreateButton({
  Name = "Anti AFK",
  Callback = function()
    for key3, value2 in pairs(getconnections(localPlayer.Idled)) do
      value2:Disable()
    end
  end,
})

mainTab:CreateButton({
  Name = "FPS Boost",
  Callback = function()
    for key4, value3 in pairs(workspace:GetDescendants()) do
      if value3:IsA("BasePart") then
        value3.Material = Enum.Material.SmoothPlastic
        value3.Reflectance = 0
      end
    end
  end,
})

mainTab:CreateButton({
  Name = "Full Bright",
  Callback = function()
    lighting.Brightness = 5
    lighting.ClockTime = 12
    lighting.FogEnd = 100000
  end,
})

mainTab:CreateButton({ Name = "Destroy GUI", Callback = function() rayfield:Destroy() end })

local playerTab = velocityHUBWindow:CreateTab("Player", 4483362458)

playerTab:CreateSlider({
  Name = "WalkSpeed",
  Range = { 16, 100 },
  Increment = 1,
  CurrentValue = 16,
  Callback = function(value4) localPlayer.Character.Humanoid.WalkSpeed = value4 end,
})

playerTab:CreateSlider({
  Name = "JumpPower",
  Range = { 50, 200 },
  Increment = 5,
  CurrentValue = 50,
  Callback = function(value5) localPlayer.Character.Humanoid.JumpPower = value5 end,
})

playerTab:CreateToggle({
  Name = "Infinite Jump",
  CurrentValue = false,
  Callback = function(value6) _G.InfJump = value6 end,
})

userInputService.JumpRequest:Connect(function()
  if _G.InfJump then
    localPlayer.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
  end
end)

playerTab:CreateButton({
  Name = "Sit",
  Callback = function() localPlayer.Character.Humanoid.Sit = true end,
})

playerTab:CreateButton({
  Name = "Unsit",
  Callback = function() localPlayer.Character.Humanoid.Sit = false end,
})

playerTab:CreateButton({ Name = "Noclip", Callback = function() _G.NC = true end })
playerTab:CreateButton({ Name = "Clip", Callback = function() _G.NC = false end })

playerTab:CreateButton({
  Name = "Refresh Character",
  Callback = function() localPlayer:LoadCharacter() end,
})

playerTab:CreateButton({
  Name = "Teleport Up",
  Callback = function()
    local v5 = f3(localPlayer)

    if v5 then
      v5.CFrame = v5.CFrame + Vector3.new(0, 20, 0)
    end
  end,
})

local visualsTab = velocityHUBWindow:CreateTab("Visuals", 4483362458)

visualsTab:CreateToggle({
  Name = "ESP Players",
  CurrentValue = false,
  Callback = function(value7)
    espPlayers = value7
    f1()

    if value7 then
      for key5, value8 in pairs(players:GetPlayers()) do
        makeHighlight(value8)
      end
    end
  end,
})

players.PlayerAdded:Connect(function(player)
  player.CharacterAdded:Connect(function()
    if espPlayers then
      task.wait(1)
      makeHighlight(player)
    end
  end)
end)

visualsTab:CreateToggle({
  Name = "Disable Fog",
  CurrentValue = false,
  Callback = function(value9) lighting.FogEnd = value9 and 100000 or 1000 end,
})

visualsTab:CreateToggle({
  Name = "Remove Shadows",
  CurrentValue = false,
  Callback = function(value10) lighting.GlobalShadows = not value10 end,
})

visualsTab:CreateButton({ Name = "Day", Callback = function() lighting.ClockTime = 12 end })
visualsTab:CreateButton({ Name = "Night", Callback = function() lighting.ClockTime = 0 end })

-- https://discord.gg/AwGHNh7Z7T
visualsTab:CreateButton({
  Name = "Low Graphics",
  Callback = function() settings().Rendering.QualityLevel = Enum.QualityLevel.Level01 end,
})

visualsTab:CreateButton({
  Name = "High Graphics",
  Callback = function() settings().Rendering.QualityLevel = Enum.QualityLevel.Level21 end,
})

visualsTab:CreateButton({ Name = "Clear ESP", Callback = f1 })

visualsTab:CreateButton({
  Name = "Reload ESP",
  Callback = function()
    f1()

    for key6, value11 in pairs(players:GetPlayers()) do
      makeHighlight(value11)
    end
  end,
})

local combatTab = velocityHUBWindow:CreateTab("Combat", 4483362458)

combatTab:CreateToggle({
  Name = "Camera Lock Nearest",
  CurrentValue = false,
  Callback = function(value12)
    v2 = value12
    v4 = nil

    if not value12 then
      return
    else
      local v6 = nil
      local huge = math.huge

      for key7, value13 in pairs(players:GetPlayers()) do
        if value13 ~= localPlayer and value13.Character then
          local v7 = f3(value13)

          if v7 then
            local magnitude = (currentCamera.CFrame.Position - v7.Position).Magnitude

            if magnitude < huge then
              huge = magnitude
              v6 = value13
            end
          end
        end
      end

      v4 = v6
      return
    end
  end,
})

combatTab:CreateButton({
  Name = "Unlock Camera",
  Callback = function()
    v2 = false
    v4 = nil
  end,
})

combatTab:CreateButton({
  Name = "Anti Stun (Basic)",
  Callback = function()
    localPlayer.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Stunned, false)
  end,
})

combatTab:CreateButton({
  Name = "Enable Stun Back",
  Callback = function()
    localPlayer.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Stunned, true)
  end,
})

combatTab:CreateButton({
  Name = "Fast Equip",
  Callback = function() localPlayer.Character.Humanoid:UnequipTools() end,
})

combatTab:CreateButton({
  Name = "Auto Rotate On",
  Callback = function() localPlayer.Character.Humanoid.AutoRotate = true end,
})

combatTab:CreateButton({
  Name = "Auto Rotate Off",
  Callback = function() localPlayer.Character.Humanoid.AutoRotate = false end,
})

combatTab:CreateButton({
  Name = "Break Velocity",
  Callback = function()
    localPlayer.Character.HumanoidRootPart.AssemblyLinearVelocity = Vector3.zero
  end,
})

combatTab:CreateButton({
  Name = "Stabilize Character",
  Callback = function() localPlayer.Character.HumanoidRootPart.Anchored = false end,
})

local teleportsTab = velocityHUBWindow:CreateTab("Teleports", 4483362458)

teleportsTab:CreateButton({
  Name = "Teleport Spawn",
  Callback = function()
    local spawnLocation = workspace:FindFirstChildWhichIsA("SpawnLocation")

    if spawnLocation then
      f3(localPlayer).CFrame = spawnLocation.CFrame + Vector3.new(0, 5, 0)
    end
  end,
})

teleportsTab:CreateButton({
  Name = "Teleport Up 50 Studs",
  Callback = function()
    local v8 = f3(localPlayer)
    v8.CFrame = v8.CFrame + Vector3.new(0, 50, 0)
  end,
})

teleportsTab:CreateButton({
  Name = "Teleport Random Player",
  Callback = function()
    local getPlayers = players:GetPlayers()
    local v9 = getPlayers[math.random(1, #getPlayers)]

    if v9.Character then
      f3(localPlayer).CFrame = f3(v9).CFrame
    end
  end,
})

teleportsTab:CreateButton({
  Name = "Safe TP Forward",
  Callback = function()
    local v10 = f3(localPlayer)
    v10.CFrame = v10.CFrame * CFrame.new(0, 0, -20)
  end,
})

teleportsTab:CreateButton({
  Name = "Safe TP Backward",
  Callback = function()
    local v11 = f3(localPlayer)
    v11.CFrame = v11.CFrame * CFrame.new(0, 0, 20)
  end,
})

teleportsTab:CreateButton({
  Name = "Safe TP Left",
  Callback = function()
    local v12 = f3(localPlayer)
    v12.CFrame = v12.CFrame * CFrame.new(-20, 0, 0)
  end,
})

teleportsTab:CreateButton({
  Name = "Safe TP Right",
  Callback = function()
    local v13 = f3(localPlayer)
    v13.CFrame = v13.CFrame * CFrame.new(20, 0, 0)
  end,
})

teleportsTab:CreateButton({
  Name = "Zero Velocity",
  Callback = function() f3(localPlayer).AssemblyLinearVelocity = Vector3.zero end,
})

teleportsTab:CreateButton({
  Name = "Anchor Toggle",
  Callback = function()
    local v14 = f3(localPlayer)
    v14.Anchored = not v14.Anchored
  end,
})

teleportsTab:CreateButton({
  Name = "Unanchor",
  Callback = function() f3(localPlayer).Anchored = false end,
})

local utilitiesTab = velocityHUBWindow:CreateTab("Utilities", 4483362458)

utilitiesTab:CreateButton({
  Name = "Copy Username",
  Callback = function() setclipboard(localPlayer.Name) end,
})

utilitiesTab:CreateButton({
  Name = "Copy UserId",
  Callback = function() setclipboard(localPlayer.UserId) end,
})

utilitiesTab:CreateButton({
  Name = "Copy PlaceId",
  Callback = function() setclipboard(game.PlaceId) end,
})

utilitiesTab:CreateButton({
  Name = "Copy JobId",
  Callback = function() setclipboard(game.JobId) end,
})

utilitiesTab:CreateButton({
  Name = "Clear Errors",
  Callback = function() warn("Logs cleared (visual only)") end,
})

utilitiesTab:CreateButton({
  Name = "Performance Mode",
  Callback = function() runService:Set3dRenderingEnabled(false) end,
})

utilitiesTab:CreateButton({
  Name = "Disable Performance Mode",
  Callback = function() runService:Set3dRenderingEnabled(true) end,
})

utilitiesTab:CreateButton({ Name = "Unload ESP", Callback = f1 })

utilitiesTab:CreateButton({
  Name = "Unload Camera Lock",
  Callback = function()
    v2 = false
    v4 = nil
  end,
})

utilitiesTab:CreateButton({ Name = "Close Hub", Callback = function() rayfield:Destroy() end })

-- https://discord.gg/AwGHNh7Z7T
