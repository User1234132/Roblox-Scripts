-- FUCKED BY MEDALWARE SHITTY DRIVING EMPIRE SCRIPT

local players = game:GetService("Players")
local tweenService = game:GetService("TweenService")
local userInputService = game:GetService("UserInputService")
local guiService = game:GetService("GuiService")
local lighting = game:GetService("Lighting")
local contentProvider = game:GetService("ContentProvider")
local coreGui = game:GetService("CoreGui")
local virtualInputManager = game:GetService("VirtualInputManager")
local runService = game:GetService("RunService")

local v1 = {
  UseKeySystem = false,
  Key = "VELOCITY_2026",
  KeyLink = "https://discord.gg/QVTsmm352y",
  KeyHint = "Join our Discord server and open the #key channel to receive key.",
  Name = "VelocityHUB",
  ToggleKey = Enum.KeyCode.RightControl,
  AccentColor = Color3.fromRGB(108, 92, 255),
  ShowBanner = true,
  LogoId = "rbxassetid://79065395294292",
  BannerId = "rbxassetid://86528416919779",
}

local v2 = {
  Background = Color3.fromRGB(15, 15, 21),
  Sidebar = Color3.fromRGB(19, 19, 27),
  Card = Color3.fromRGB(27, 27, 38),
  CardHover = Color3.fromRGB(36, 36, 50),
  Input = Color3.fromRGB(20, 20, 29),
  Off = Color3.fromRGB(58, 58, 78),
  Stroke = Color3.fromRGB(46, 46, 64),
  Text = Color3.fromRGB(240, 240, 250),
  SubText = Color3.fromRGB(148, 148, 172),
  Success = Color3.fromRGB(80, 220, 140),
  Danger = Color3.fromRGB(255, 90, 105),
  Accent = v1.AccentColor,
}

local function f1(accent, p1)
  return accent:Lerp(Color3.new(1, 1, 1), p1)
end

local function f2(increment)
  local d = tostring(increment):match("%.(%d+)")
  return d and #d or 0
end

local v3 = {
  Regular = Enum.Font.Gotham,
  Medium = Enum.Font.GothamMedium,
  Bold = Enum.Font.GothamBold,
}

local v4 = {}
local v5 = {}
local v6 = 0
local v7 = {}

local function f3(p2)
  table.insert(v5, p2)
  p2()
end

local function f4(p3, p4, p5)
  local instance = Instance.new(p3)

  if instance:IsA("GuiObject") then
    instance.BorderSizePixel = 0
  end

  if instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox") then
    instance.BackgroundTransparency = 1
    instance.Font = v3.Medium
    instance.TextColor3 = v2.Text
    instance.TextSize = 13
    instance.Text = ""
    instance.TextXAlignment = Enum.TextXAlignment.Left
  end

  if instance:IsA("TextButton") or instance:IsA("ImageButton") then
    instance.AutoButtonColor = false
  end

  if instance:IsA("ImageLabel") or instance:IsA("ImageButton") then
    instance.BackgroundTransparency = 1
  end

  local v8 = pairs
  local v9

  for v10, v11 in v8(p4 or {}) do
    if v10 == "Parent" then
      v9 = v11
    else
      instance[v10] = v11
    end
  end

  for index, value in ipairs(p5 or {}) do
    value.Parent = instance
  end

  if v9 then
    instance.Parent = v9
  end

  return instance
end

local function f5(value2)
  v2.Accent = value2

  for index2, value3 in ipairs(v4) do
    value3(value2)
  end
end

local f6

local function f7(p6, key)
  f6(function(p7) p6[key] = p7 end)
end

function f6(p8)
  table.insert(v4, p8)
  p8(v2.Accent)
end

local function f8(p9, key2, index3)
  local function f9()
    p9[key2] = index3 + (1 - index3) * v6
  end

  table.insert(v5, f9)
  f9()
end

local function f10(p10, p11, duration, p12, inOut)
  local create = tweenService:Create(p10, TweenInfo.new(
    duration or 0.25, p12 or Enum.EasingStyle.Quint, inOut or Enum.EasingDirection.Out
  ), p11)

  create:Play()
  return create
end

local function f11(p13)
  v6 = p13

  for index4, value4 in ipairs(v5) do
    value4()
  end
end

local function f12(p14, p15)
  local connect = p14:Connect(p15)
  table.insert(v7, connect)
  return connect
end

local function f13(parent, p16)
  return f4("UICorner", { CornerRadius = UDim.new(0, p16), Parent = parent })
end

local function f14(p17)
  return f4("TextLabel", p17)
end

local function f15(parent2, color, p18, p19)
  return f4("UIStroke", {
    Color = color,
    Thickness = p18 or 1,
    Transparency = p19 or 0,
    ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
    Parent = parent2,
  })
end

local function f16(p20, index5, p21)
  for index6, value5 in ipairs(p20:GetChildren()) do
    if value5:IsA("ImageLabel") then
      local base = value5:GetAttribute("Base") or 0.8
      f10(value5, { ImageTransparency = base + (1 - base) * index5 }, p21 or 0.3)
    end
  end
end

local f17

local function f18(parent3, p22, p23, p24)
  local v12 = p22 or 30
  local v13 = p24 or 200

  local v14 = f4("Frame", {
    Name = "Shadow",
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.new(0.5, 0, 0.5, math.floor(v12 * 0.25)),
    Size = UDim2.fromScale(1, 1),
    ZIndex = 0,
    Parent = parent3,
  })

  for index7, value6 in ipairs({ { 1, 0.93 }, { 0.72, 0.88 }, { 0.46, 0.82 }, { 0.22, 0.74 } }) do
    local v15 = v12 * value6[1]

    f4("ImageLabel", {
      Image = "rbxassetid://6014261993",
      ImageColor3 = Color3.new(0, 0, 0),
      ScaleType = Enum.ScaleType.Slice,
      SliceCenter = Rect.new(49, 49, 450, 450),
      SliceScale = math.clamp((v13 + v15 * 2) / 110, 0.25, 1),
      AnchorPoint = Vector2.new(0.5, 0.5),
      Position = UDim2.fromScale(0.5, 0.5),
      Size = UDim2.new(1, v15 * 2, 1, v15 * 2),
      ZIndex = 0,
      Parent = v14,
    }):SetAttribute(
      "Base", value6[2]
    )
  end

  f17(v14, p23 or 0)
  return v14
end

function f17(p25, index8)
  for index9, value7 in ipairs(p25:GetChildren()) do
    if value7:IsA("ImageLabel") then
      local base2 = value7:GetAttribute("Base") or 0.8
      value7.ImageTransparency = base2 + (1 - base2) * index8
    end
  end
end

local function f19(p26, ...)
  if type(p26) ~= "function" then
    return
  else
    local v16, v17 = pcall(p26, ...)

    if not v16 then
      warn("[VelocityHUB] Callback error: " .. tostring(v17))
    end

    return
  end
end

local function f20(p27, parent4, p28)
  local v18 = f4("UIScale", { Parent = parent4 })
  p27.MouseButton1Down:Connect(function() f10(v18, { Scale = p28 or 0.97 }, 0.1) end)

  local function f21()
    f10(v18, { Scale = 1 }, 0.35, Enum.EasingStyle.Back)
  end

  p27.MouseButton1Up:Connect(f21)
  p27.MouseLeave:Connect(f21)
end

local function f22(p29, p30, fn, fn2)
  p29.MouseEnter:Connect(function() f10(p30, { BackgroundColor3 = fn2() }, 0.2) end)
  p29.MouseLeave:Connect(function() f10(p30, { BackgroundColor3 = fn() }, 0.25) end)
end

local v19 = { Listening = false }

local function f23(input)
  return input.UserInputType == Enum.UserInputType.MouseButton1
    or input.UserInputType == Enum.UserInputType.Touch
end

local function f24(index10, x, y)
  local v20 = math.max(index10.AbsoluteSize.X, index10.AbsoluteSize.Y) * 2.4

  local v21 = f4("Frame", {
    BackgroundColor3 = v2.Accent,
    BackgroundTransparency = 0.72,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromOffset(x - index10.AbsolutePosition.X, y - index10.AbsolutePosition.Y),
    Size = UDim2.fromOffset(0, 0),
    ZIndex = 0,
    Parent = index10,
  })

  f13(v21, 999)

  f10(
    v21, { Size = UDim2.fromOffset(v20, v20), BackgroundTransparency = 1 }, 0.65,
    Enum.EasingStyle.Quad
  )

  task.delay(0.7, function() v21:Destroy() end)
end

local function f25(p31, fn3, p32, p33)
  local v22 = false

  local function f26(position)
    local absoluteSize = p31.AbsoluteSize
    local absolutePosition = p31.AbsolutePosition

    fn3(
      math.clamp((position.X - absolutePosition.X) / math.max(absoluteSize.X, 1), 0, 1),
      math.clamp((position.Y - absolutePosition.Y) / math.max(absoluteSize.Y, 1), 0, 1)
    )
  end

  p31.InputBegan:Connect(function(input2)
    local connect2

    if f23(input2) then
      v22 = true

      if p32 then
        p32()
      end

      f26(input2.Position)

      connect2 = nil

      connect2 = input2.Changed:Connect(function()
        if input2.UserInputState == Enum.UserInputState.End then
          v22 = false

          if p33 then
            p33()
          end

          connect2:Disconnect()
        end
      end)
    end
  end)

  f12(userInputService.InputChanged, function(p34)
    if v22
      and (p34.UserInputType == Enum.UserInputType.MouseMovement
        or p34.UserInputType == Enum.UserInputType.Touch) then
      f26(p34.Position)
    end
  end)
end

local function makeFolder()
  for index11, value8 in ipairs({
    function() return gethui() end, function() return coreGui end,
    function() return players.LocalPlayer:WaitForChild("PlayerGui") end,
  }) do
    local v23, v24 = pcall(value8)

    if v23 and v24 then
      if pcall(function()
        local folder = Instance.new("Folder")
        folder.Parent = v24
        folder:Destroy()
      end) then
        return v24
      end
    end
  end

  return players.LocalPlayer:WaitForChild("PlayerGui")
end

local v25 = makeFolder()
local velocityHUB = v25:FindFirstChild("VelocityHUB")

if velocityHUB then
  velocityHUB:Destroy()
end

local v26 = f4("ScreenGui", {
  Name = "VelocityHUB",
  ResetOnSpawn = false,
  ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
  DisplayOrder = 999,
  Parent = v25,
})

pcall(function()
  if syn and syn.protect_gui then
    syn.protect_gui(v26)
  end
end)

local v27 = { Config = v1, Theme = v2, Flags = {} }

function v27:Destroy()
  for index12, value9 in ipairs(v7) do
  end

  table.clear(v7)

  for index13, value10 in ipairs(lighting:GetChildren()) do
    if value10:IsA("BlurEffect") and value10.Name == "VelocityBlur" then
      value10:Destroy()
    end
  end

  v26:Destroy()
end

local parent5 = f4("Frame", {
  Name = "Notifications",
  BackgroundTransparency = 1,
  AnchorPoint = Vector2.new(1, 1),
  Position = UDim2.new(1, -20, 1, -20),
  Size = UDim2.new(0, 290, 1, -40),
  ZIndex = 50,
  Parent = v26,
}, {
  f4("UIListLayout", {
    SortOrder = Enum.SortOrder.LayoutOrder,
    VerticalAlignment = Enum.VerticalAlignment.Bottom,
    Padding = UDim.new(0, 8),
  }),
})

function v27:Notify(p35)
  local v28 = p35 or {}
  local duration2 = v28.Duration or 4
  local accent2 = v2.Accent

  if v28.Type == "Success" then
    accent2 = v2.Success
  elseif v28.Type == "Error" then
    accent2 = v2.Danger
  end

  local v29 = f4("Frame", {
    BackgroundTransparency = 1,
    Size = UDim2.new(1, 0, 0, 70),
    Parent = parent5,
  })

  local v30 = f4("Frame", {
    BackgroundTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    Position = UDim2.new(1, 330, 0, 0),
    Parent = v29,
  })

  f18(v30, 24, 0, 70)

  local v31 = f4("Frame", {
    BackgroundColor3 = v2.Card,
    Size = UDim2.fromScale(1, 1),
    ClipsDescendants = true,
    Parent = v30,
  })

  f13(v31, 10)
  f15(v31, v2.Stroke, 1, 0.3)

  f13(f4("Frame", {
    BackgroundColor3 = accent2,
    Position = UDim2.new(0, 8, 0, 12),
    Size = UDim2.new(0, 3, 1, -24),
    Parent = v31,
  }), 2)

  f14({
    Text = v28.Title or "VelocityHUB",
    Font = v3.Bold,
    TextSize = 14,
    Position = UDim2.new(0, 22, 0, 9),
    Size = UDim2.new(1, -34, 0, 18),
    Parent = v31,
  })

  f14({
    Text = v28.Content or "",
    TextSize = 12,
    TextColor3 = v2.SubText,
    TextWrapped = true,
    TextYAlignment = Enum.TextYAlignment.Top,
    Position = UDim2.new(0, 22, 0, 29),
    Size = UDim2.new(1, -34, 0, 34),
    Parent = v31,
  })

  local v32 = f4("Frame", {
    BackgroundColor3 = accent2,
    Position = UDim2.new(0, 0, 1, -2),
    Size = UDim2.new(1, 0, 0, 2),
    Parent = v31,
  })

  task.spawn(function()
    f10(v30, { Position = UDim2.new(0, 0, 0, 0) }, 0.55, Enum.EasingStyle.Back)
    f10(v32, { Size = UDim2.new(0, 0, 0, 2) }, duration2, Enum.EasingStyle.Linear)

    task.wait(duration2)

    f10(
      v30, { Position = UDim2.new(1, 330, 0, 0) }, 0.4, Enum.EasingStyle.Quint,
      Enum.EasingDirection.In
    )

    task.wait(0.4)
    f10(v29, { Size = UDim2.new(1, 0, 0, 0) }, 0.2)
    task.wait(0.2)
    v29:Destroy()
  end)
end

local function makeBindableEvent(parent6)
  local bindableEvent = Instance.new("BindableEvent")
  local v33 = false

  local v34 = f4("Frame", {
    Name = "KeySystem",
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromOffset(420, 384),
    Parent = parent6,
  })

  local v35 = f4("UIScale", { Scale = 0.85, Parent = v34 })
  local v36 = f18(v34, 44, 1, 384)

  local v37 = f4("CanvasGroup", {
    BackgroundColor3 = v2.Background,
    GroupTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    Parent = v34,
  })

  f13(v37, 16)
  f15(v37, v2.Stroke, 1, 0.3)

  f10(v35, { Scale = 1 }, 0.6, Enum.EasingStyle.Back)
  f10(v37, { GroupTransparency = 0 }, 0.5)

  f16(v36, 0.15, 0.6)
  local v38 = f4("Frame", { Size = UDim2.new(1, 0, 0, 3), Parent = v37 })
  f7(v38, "BackgroundColor3")

  f4("UIGradient", {
    Transparency = NumberSequence.new({
      NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 0.9),
    }),
    Parent = v38,
  })

  local v39 = f4("ImageLabel", {
    Image = v1.LogoId,
    BackgroundColor3 = v2.Card,
    BackgroundTransparency = 0,
    AnchorPoint = Vector2.new(0.5, 0),
    Position = UDim2.new(0.5, 0, 0, 24),
    Size = UDim2.fromOffset(84, 84),
    ScaleType = Enum.ScaleType.Fit,
    Parent = v37,
  })

  f13(v39, 20)
  f7(f15(v39, v2.Accent, 2, 0.15), "Color")

  tweenService:Create(v39, TweenInfo.new(
    2.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true
  ), { Position = UDim2.new(0.5, 0, 0, 31) }):Play()

  f14({
    Text = v1.Name,
    Font = v3.Bold,
    TextSize = 26,
    TextXAlignment = Enum.TextXAlignment.Center,
    Position = UDim2.new(0, 0, 0, 122),
    Size = UDim2.new(1, 0, 0, 30),
    Parent = v37,
  })

  f14({
    Text = "Enter your key to continue",
    TextSize = 13,
    TextColor3 = v2.SubText,
    TextXAlignment = Enum.TextXAlignment.Center,
    Position = UDim2.new(0, 0, 0, 152),
    Size = UDim2.new(1, 0, 0, 18),
    Parent = v37,
  })

  local v40 = f4("Frame", {
    BackgroundColor3 = v2.Input,
    Position = UDim2.new(0, 24, 0, 184),
    Size = UDim2.new(1, -48, 0, 44),
    Parent = v37,
  })

  f13(v40, 10)
  local v41 = f15(v40, v2.Stroke, 1.5, 0)

  local v42 = f4("TextBox", {
    PlaceholderText = "Enter your key here...",
    PlaceholderColor3 = v2.SubText,
    ClearTextOnFocus = false,
    Font = v3.Medium,
    TextSize = 14,
    TextXAlignment = Enum.TextXAlignment.Center,
    Position = UDim2.new(0, 12, 0, 0),
    Size = UDim2.new(1, -24, 1, 0),
    Parent = v40,
  })

  local v43 = f14({
    Text = "",
    TextSize = 12,
    TextColor3 = v2.SubText,
    TextXAlignment = Enum.TextXAlignment.Center,
    Position = UDim2.new(0, 24, 0, 234),
    Size = UDim2.new(1, -48, 0, 16),
    Parent = v37,
  })

  v42.Focused:Connect(function()
    if not v33 then
      f10(v41, { Color = v2.Accent }, 0.2)
    end
  end)

  v42.FocusLost:Connect(function()
    if not v33 then
      f10(v41, { Color = v2.Stroke }, 0.25)
    end
  end)

  local v44 = f4("TextButton", {
    Text = "Verify Key",
    Font = v3.Bold,
    TextSize = 14,
    TextXAlignment = Enum.TextXAlignment.Center,
    BackgroundTransparency = 0,
    Position = UDim2.new(0, 24, 0, 258),
    Size = UDim2.new(0.58, -29, 0, 40),
    Parent = v37,
  })

  f13(v44, 10)
  f7(v44, "BackgroundColor3")
  f22(v44, v44, function() return v2.Accent end, function() return f1(v2.Accent, 0.18) end)
  f20(v44, v44, 0.96)

  local v45 = f4("TextButton", {
    Text = "Get Key",
    Font = v3.Bold,
    TextSize = 14,
    TextXAlignment = Enum.TextXAlignment.Center,
    BackgroundColor3 = v2.Card,
    BackgroundTransparency = 0,
    AnchorPoint = Vector2.new(1, 0),
    Position = UDim2.new(1, -24, 0, 258),
    Size = UDim2.new(0.42, -29, 0, 40),
    Parent = v37,
  })

  f13(v45, 10)
  f15(v45, v2.Stroke, 1, 0.2)
  f22(v45, v45, function() return v2.Card end, function() return v2.CardHover end)
  f20(v45, v45, 0.96)

  local v46 = f4("Frame", {
    BackgroundColor3 = v2.Card,
    Position = UDim2.new(0, 24, 0, 312),
    Size = UDim2.new(1, -48, 0, 56),
    Parent = v37,
  })

  f13(v46, 10)

  local v47 = f4("Frame", {
    Position = UDim2.new(0, 10, 0, 10),
    Size = UDim2.new(0, 3, 1, -20),
    Parent = v46,
  })

  f13(v47, 2)
  f7(v47, "BackgroundColor3")
  local udim = UDim2.new(0, 24, 0, 0)
  local udim2 = UDim2.new(1, -34, 1, 0)

  local v48 = f14({
    RichText = true,
    TextSize = 12,
    TextWrapped = true,
    TextColor3 = v2.SubText,
    TextYAlignment = Enum.TextYAlignment.Center,
    Position = udim,
    Size = udim2,
    Parent = v46,
  })

  f6(function(text)
    v48.Text = string.format(
      '<font color="#%s"><b>HINT</b></font>  %s', text:ToHex(), v1.KeyHint
    )
  end)

  local v49 = f4("TextButton", {
    Text = "x",
    Font = v3.Bold,
    TextSize = 16,
    TextColor3 = v2.SubText,
    TextXAlignment = Enum.TextXAlignment.Center,
    Position = UDim2.new(1, -38, 0, 10),
    Size = UDim2.fromOffset(28, 28),
    Parent = v37,
  })

  v49.MouseEnter:Connect(function() f10(v49, { TextColor3 = v2.Danger }, 0.2) end)
  v49.MouseLeave:Connect(function() f10(v49, { TextColor3 = v2.SubText }, 0.2) end)

  local function f27(keyLink, textColor3)
    v43.Text = keyLink
    v43.TextColor3 = textColor3
  end

  local function f28()
    task.spawn(function()
      local position2 = v34.Position

      for index14, value11 in ipairs({ -10, 10, -7, 7, -4, 4, 0 }) do
        f10(v34, {
          Position = UDim2.new(
            position2.X.Scale, position2.X.Offset + value11, position2.Y.Scale,
            position2.Y.Offset
          ),
        }, 0.05, Enum.EasingStyle.Sine)

        task.wait(0.05)
      end
    end)
  end

  local function f29(p36)
    f10(v37, { GroupTransparency = 1 }, 0.4)
    f10(v35, { Scale = 0.92 }, 0.4)

    f16(v36, 1, 0.4)
    task.wait(0.45)
    v34:Destroy()
    bindableEvent:Fire(p36)
  end

  local function f30()
    if v33 then
      return
    else
      local v50 = string.match(v42.Text, "^%s*(.-)%s*$")

      if v50 == "" then
        f27("Please enter your key.", v2.Danger)
        f28()
      elseif v50 == v1.Key then
        v33 = true
        f27("Key verified. Welcome!", v2.Success)
        f10(v41, { Color = v2.Success }, 0.25)
        task.delay(0.7, function() f29(true) end)
      else
        f27("Invalid key. Please try again.", v2.Danger)
        f10(v41, { Color = v2.Danger }, 0.2)
        f28()

        task.delay(1.3, function()
          if not v33 and not v42:IsFocused() then
            f10(v41, { Color = v2.Stroke }, 0.3)
          end
        end)
      end

      return
    end
  end

  v44.MouseButton1Click:Connect(f30)

  v42.FocusLost:Connect(function(p37)
    if p37 then
      f30()
    end
  end)

  v45.MouseButton1Click:Connect(function()
    if pcall(function() setclipboard(v1.KeyLink) end) then
      f27("Link copied to clipboard!", v2.Success)
    else
      f27(v1.KeyLink, v2.Accent)
    end
  end)

  v49.MouseButton1Click:Connect(function()
    if not v33 then
      v33 = true
      f29(false)
    end
  end)

  return bindableEvent.Event:Wait()
end

local function f31()
  local getGuiInset = guiService:GetGuiInset()

  local v51 = f4("Frame", {
    Name = "Backdrop",
    BackgroundColor3 = Color3.fromRGB(8, 8, 12),
    BackgroundTransparency = 1,
    Position = UDim2.fromOffset(0, -getGuiInset.Y),
    Size = UDim2.new(1, 0, 1, getGuiInset.Y),
    Active = true,
    ZIndex = 10,
    Parent = v26,
  })

  f10(v51, { BackgroundTransparency = 0.3 }, 0.6)
  local v52

  pcall(function()
    v52 = f4("BlurEffect", { Name = "VelocityBlur", Size = 0, Parent = lighting })
    f10(v52, { Size = 18 }, 0.7)
  end)

  return v51, function()
    f10(v51, { BackgroundTransparency = 1 }, 0.6)

    if v52 then
      f10(v52, { Size = 0 }, 0.6).Completed:Connect(function() v52:Destroy() end)
    end

    task.delay(0.65, function() v51:Destroy() end)
  end
end

local function f32(parent7)
  local v53 = f4("CanvasGroup", {
    Name = "Loader",
    BackgroundTransparency = 1,
    GroupTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    Parent = parent7,
  })

  local parent8 = f4("Frame", {
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.new(0.5, 0, 0.5, -70),
    Size = UDim2.fromOffset(150, 150),
    Parent = v53,
  })

  local v54 = f4("Frame", {
    BackgroundTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    Parent = parent8,
  })

  f13(v54, 46)
  f15(v54, v2.Stroke, 3, 0.4)

  local v55 = f4("Frame", {
    BackgroundTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    Parent = parent8,
  })

  f13(v55, 46)
  local parent9 = f15(v55, Color3.new(1, 1, 1), 3, 0)

  local v56 = f4("UIGradient", {
    Transparency = NumberSequence.new({
      NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.55, 1),
      NumberSequenceKeypoint.new(1, 0),
    }),
    Parent = parent9,
  })

  f6(function(p38) v56.Color = ColorSequence.new(p38) end)

  tweenService:Create(v56, TweenInfo.new(
    1.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, -1
  ), { Rotation = 360 }):Play()

  local v57 = f4("ImageLabel", {
    Image = v1.LogoId,
    BackgroundColor3 = v2.Card,
    BackgroundTransparency = 0,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromOffset(112, 112),
    ScaleType = Enum.ScaleType.Fit,
    Parent = parent8,
  })

  f13(v57, 28)

  tweenService:Create(f4("UIScale", { Parent = v57 }), TweenInfo.new(
    1.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true
  ), { Scale = 1.06 }):Play()

  f14({
    Text = string.upper(v1.Name),
    Font = Enum.Font.GothamBold,
    TextSize = 26,
    TextXAlignment = Enum.TextXAlignment.Center,
    AnchorPoint = Vector2.new(0.5, 0),
    Position = UDim2.new(0.5, 0, 0.5, 26),
    Size = UDim2.fromOffset(400, 32),
    Parent = v53,
  })

  local v58 = f14({
    Text = "Starting...",
    TextSize = 12,
    TextColor3 = v2.SubText,
    AnchorPoint = Vector2.new(0.5, 0),
    Position = UDim2.new(0.5, 0, 0.5, 68),
    Size = UDim2.fromOffset(300, 18),
    Parent = v53,
  })

  local v59 = f14({
    Text = "0%",
    TextSize = 12,
    Font = Enum.Font.GothamBold,
    TextXAlignment = Enum.TextXAlignment.Right,
    AnchorPoint = Vector2.new(0.5, 0),
    Position = UDim2.new(0.5, 0, 0.5, 68),
    Size = UDim2.fromOffset(300, 18),
    Parent = v53,
  })

  f7(v59, "TextColor3")

  local v60 = f4("Frame", {
    BackgroundColor3 = v2.Card,
    AnchorPoint = Vector2.new(0.5, 0),
    Position = UDim2.new(0.5, 0, 0.5, 94),
    Size = UDim2.fromOffset(300, 6),
    Parent = v53,
  })

  f13(v60, 3)
  local v61 = f4("Frame", { Size = UDim2.new(0, 0, 1, 0), Parent = v60 })
  f13(v61, 3)
  local v62 = f4("UIGradient", { Parent = v61 })
  f6(function(p39) v62.Color = ColorSequence.new(p39, f1(p39, 0.45)) end)

  v61:GetPropertyChangedSignal("Size"):Connect(function()
    v59.Text = math.floor(v61.Size.X.Scale * 100 + 0.5) .. "%"
  end)

  local v63 = false

  task.spawn(function()
    local v64 = f4("ImageLabel", { Image = v1.BannerId, Visible = false, Parent = v53 })
    pcall(function() contentProvider:PreloadAsync({ v57, v64 }) end)
    v63 = true
  end)

  f10(v53, { GroupTransparency = 0 }, 0.5)
  task.wait(0.5)

  local function f33(p40, p41, text2)
    v58.Text = text2

    f10(
      v61, { Size = UDim2.new(p40, 0, 1, 0) }, p41, Enum.EasingStyle.Quad,
      Enum.EasingDirection.InOut
    ).Completed:Wait()
  end

  f33(0.25, 0.6, "Initializing core modules...")

  v58.Text = "Preloading assets..."

  f10(
    v61, { Size = UDim2.new(0.6, 0, 1, 0) }, 0.8, Enum.EasingStyle.Quad,
    Enum.EasingDirection.InOut
  ).Completed:Wait()

  local v65 = os.clock()

  while not v63 and os.clock() - v65 < 3 do
    task.wait()
  end

  f33(0.88, 0.7, "Building interface...")
  f33(1, 0.5, "Ready!")

  task.wait(0.3)
  f10(v53, { GroupTransparency = 1 }, 0.5)
  task.wait(0.5)
  v53:Destroy()
end

function v27:CreateWindow(p42)
  local v66 = p42 or {}
  local v67 = { Flags = v27.Flags }
  local useKeySystem = v66.UseKeySystem

  if useKeySystem == nil then
    useKeySystem = v1.UseKeySystem
  end

  local name = v66.Name or v1.Name
  v67.ToggleKey = v66.ToggleKey or v1.ToggleKey
  local v68, v69 = f31()

  if useKeySystem then
    if not makeBindableEvent(v68) then
      v69()
      task.wait(0.7)
      v27:Destroy()
      Instance.new("BindableEvent").Event:Wait()
    end
  end

  f32(v68)
  v69()
  local currentCamera = workspace.CurrentCamera
  local v70 = 1

  if currentCamera then
    local viewportSize = currentCamera.ViewportSize
    v70 = math.clamp(math.min(viewportSize.X / 740, viewportSize.Y / 520), 0.5, 1)
  end

  local v71 = f4("Frame", {
    Name = "Window",
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromOffset(680, 460),
    Parent = v26,
  })

  local v72 = f4("Frame", {
    Name = "Body",
    BackgroundTransparency = 1,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromScale(1, 1),
    Parent = v71,
  })

  local v73 = f4("UIScale", { Scale = v70 * 0.85, Parent = v72 })
  local v74 = f18(v72, 46, 0, 460)
  f3(function() f17(v74, v6) end)

  local v75 = f4("Frame", {
    Name = "Main",
    BackgroundColor3 = v2.Background,
    Size = UDim2.fromScale(1, 1),
    Parent = v72,
  })

  f13(v75, 14)
  f15(v75, Color3.new(1, 1, 1), 1, 0.86)
  f8(v75, "BackgroundTransparency", 0)

  local v76 = f4("CanvasGroup", {
    Name = "BannerBackdrop",
    BackgroundTransparency = 1,
    Size = UDim2.fromScale(1, 1),
    ZIndex = 0,
    Parent = v75,
  })

  f13(v76, 14)

  local v77 = f4("ImageLabel", {
    Name = "Banner",
    Image = v1.BannerId,
    ScaleType = Enum.ScaleType.Crop,
    Size = UDim2.fromScale(1, 1),
    ZIndex = 1,
    Parent = v76,
  })

  local function f34(rotation, p43)
    local v78 = {}

    for index15, value12 in ipairs(p43) do
      table.insert(v78, NumberSequenceKeypoint.new(value12[1], value12[2]))
    end

    local v79 = f4("Frame", {
      BackgroundColor3 = Color3.new(0, 0, 0),
      Size = UDim2.fromScale(1, 1),
      Parent = v76,
    })

    f4("UIGradient", {
      Rotation = rotation,
      Transparency = NumberSequence.new(v78),
      Parent = v79,
    })

    return v79
  end

  local v80 = f34(0, { { 0, 0.25 }, { 0.27, 0.35 }, { 1, 0.48 } })
  local v81 = f34(90, { { 0, 0.65 }, { 1, 0.3 } })

  local v82 = f4("Frame", {
    BackgroundColor3 = Color3.new(1, 1, 1),
    Size = UDim2.fromScale(1, 1),
    Parent = v76,
  })

  local v83 = f4("UIGradient", {
    Rotation = -35,
    Transparency = NumberSequence.new({
      NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.6, 0.94),
      NumberSequenceKeypoint.new(1, 0.8),
    }),
    Parent = v82,
  })

  f6(function(p44) v83.Color = ColorSequence.new(p44) end)

  local v84 = f4("Frame", {
    BackgroundColor3 = v2.Sidebar,
    Size = UDim2.new(0, 184, 1, 0),
    Parent = v76,
  })

  f8(v84, "BackgroundTransparency", 0.42)
  v80.ZIndex = 2
  v81.ZIndex = 3
  v82.ZIndex = 4
  v84.ZIndex = 5
  local v85 = { v80, v81, v82 }
  local showBanner = v1.ShowBanner

  local function f35(p45)
    local v86 = showBanner and v6 or 1

    if p45 then
      f10(v77, { ImageTransparency = v86 }, 0.5)

      for index16, value13 in ipairs(v85) do
        f10(value13, { BackgroundTransparency = v86 }, 0.5)
      end
    else
      v77.ImageTransparency = v86

      for index17, value14 in ipairs(v85) do
        value14.BackgroundTransparency = v86
      end
    end
  end

  f3(function() f35(false) end)
  v77.ImageTransparency = 1

  for index18, value15 in ipairs(v85) do
    value15.BackgroundTransparency = 1
  end

  local parent10 = f4("Frame", {
    Name = "Sidebar",
    BackgroundTransparency = 1,
    Size = UDim2.new(0, 184, 1, 0),
    Parent = v75,
  })

  f4("Frame", {
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.88,
    Position = UDim2.new(0, 184, 0, 0),
    Size = UDim2.new(0, 1, 1, 0),
    Parent = v75,
  })

  local v87 = f4("Frame", {
    Name = "Header",
    BackgroundTransparency = 1,
    Size = UDim2.new(0, 184, 0, 68),
    Parent = v75,
  })

  local v88 = f4("ImageLabel", {
    Image = v1.LogoId,
    BackgroundColor3 = v2.Card,
    BackgroundTransparency = 0,
    ScaleType = Enum.ScaleType.Fit,
    Position = UDim2.new(0, 16, 0, 15),
    Size = UDim2.fromOffset(38, 38),
    Parent = v87,
  })

  f13(v88, 10)
  f7(f15(v88, v2.Accent, 1.5, 0.2), "Color")

  f14({
    Text = name,
    Font = v3.Bold,
    TextSize = 15,
    TextTruncate = Enum.TextTruncate.AtEnd,
    Position = UDim2.new(0, 64, 0, 16),
    Size = UDim2.new(1, -72, 0, 18),
    Parent = v87,
  })

  f14({
    Text = "Please Like...",
    TextSize = 11,
    TextColor3 = v2.SubText,
    Position = UDim2.new(0, 64, 0, 34),
    Size = UDim2.new(1, -72, 0, 14),
    Parent = v87,
  })

  local v89 = f4("ScrollingFrame", {
    Name = "Tabs",
    BackgroundTransparency = 1,
    ScrollBarThickness = 0,
    CanvasSize = UDim2.new(),
    AutomaticCanvasSize = Enum.AutomaticSize.Y,
    ScrollingDirection = Enum.ScrollingDirection.Y,
    Position = UDim2.new(0, 8, 0, 72),
    Size = UDim2.new(1, 0, 1, 0),
    Parent = parent10,
  })

  v89.Size = UDim2.new(0, 168, 1, -84)

  f4("UIListLayout", {
    Padding = UDim.new(0, 4),
    SortOrder = Enum.SortOrder.LayoutOrder,
    Parent = v89,
  })

  local parent11 = f4("Frame", {
    Name = "Content",
    BackgroundTransparency = 1,
    Position = UDim2.new(0, 185, 0, 0),
    Size = UDim2.new(1, -185, 1, 0),
    Parent = v75,
  })

  local v90 = f4("Frame", {
    Position = UDim2.new(0, 14, 0, 0),
    Size = UDim2.new(1, -28, 0, 2),
    Parent = parent11,
  })

  f7(v90, "BackgroundColor3")

  f4("UIGradient", {
    Transparency = NumberSequence.new({
      NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1),
    }),
    Parent = v90,
  })

  local v91 = f4("Frame", {
    Name = "Topbar",
    BackgroundTransparency = 1,
    Size = UDim2.new(1, 0, 0, 56),
    Parent = parent11,
  })

  local v92 = f14({
    Text = "",
    Font = v3.Bold,
    TextSize = 18,
    Position = UDim2.new(0, 20, 0, 0),
    Size = UDim2.new(1, -80, 1, 0),
    Parent = v91,
  })

  local vector = Vector2.new(1, 0.5)
  local udim3 = UDim2.new(1, -14, 0.5, 0)
  local udim4 = UDim2.fromOffset(30, 30)

  local v93 = f4("TextButton", {
    Text = "x",
    Font = v3.Bold,
    TextSize = 14,
    TextColor3 = v2.SubText,
    TextXAlignment = Enum.TextXAlignment.Center,
    BackgroundColor3 = v2.Card,
    BackgroundTransparency = 0,
    AnchorPoint = vector,
    Position = udim3,
    Size = udim4,
    Parent = v91,
  })

  f13(v93, 8)
  f22(v93, v93, function() return v2.Card end, function() return v2.Danger end)

  v93.MouseEnter:Connect(function() f10(v93, { TextColor3 = Color3.new(1, 1, 1) }, 0.2) end)
  v93.MouseLeave:Connect(function() f10(v93, { TextColor3 = v2.SubText }, 0.2) end)

  f20(v93, v93, 0.9)

  local parent12 = f4("Frame", {
    Name = "Pages",
    BackgroundTransparency = 1,
    ClipsDescendants = true,
    Position = UDim2.new(0, 12, 0, 56),
    Size = UDim2.new(1, -24, 1, -68),
    Parent = parent11,
  })

  local function f36(p46, p47)
    local v94 = false
    local inputBegan = p46.InputBegan
    local position3, position4

    inputBegan:Connect(function(p48)
      local connect3

      if f23(p48) then
        v94 = true
        position3 = p48.Position
        position4 = p47.Position

        connect3 = nil

        connect3 = p48.Changed:Connect(function()
          if p48.UserInputState == Enum.UserInputState.End then
            v94 = false
            connect3:Disconnect()
          end
        end)
      end
    end)

    f12(userInputService.InputChanged, function(p49)
      if v94
        and (p49.UserInputType == Enum.UserInputType.MouseMovement
          or p49.UserInputType == Enum.UserInputType.Touch) then
        local v95 = p49.Position - position3

        f10(p47, {
          Position = UDim2.new(
            position4.X.Scale, position4.X.Offset + v95.X, position4.Y.Scale,
            position4.Y.Offset + v95.Y
          ),
        }, 0.08, Enum.EasingStyle.Quad)
      end
    end)
  end

  f36(v87, v71)
  f36(v91, v71)

  local v96 = true

  local function f37(p50)
    if p50 == v96 then
      return
    end

    v96 = p50

    if p50 then
      v71.Visible = true
      v73.Scale = v70 * 0.88
      f10(v73, { Scale = v70 }, 0.45, Enum.EasingStyle.Back)
    else
      f10(
        v73, { Scale = v70 * 0.88 }, 0.22, Enum.EasingStyle.Quad,
        Enum.EasingDirection.In
      ).Completed:Connect(function()
        if not v96 then
          v71.Visible = false
        end
      end)
    end
  end

  function v67.Toggle(p51)
    f37(not v96)
  end

  function v67.Show(p52)
    f37(true)
  end

  function v67.Hide(p53)
    f37(false)
  end

  function v67:Notify(p54)
    v27:Notify(p54)
  end

  function v67:Destroy()
    v27:Destroy()
  end

  function v67.SetAccent(p55, p56)
    f5(p56)
  end

  function v67.SetTransparency(p57, p58)
    f11(math.clamp(p58, 0, 0.8))
  end

  function v67.SetToggleKey(p59, toggleKey)
    v67.ToggleKey = toggleKey
  end

  v93.MouseButton1Click:Connect(function()
    f37(false)

    v27:Notify({
      Title = name,
      Content = "Hidden. Press " .. v67.ToggleKey.Name .. " to open it again.",
      Duration = 3,
    })
  end)

  f12(userInputService.InputBegan, function(p60, p61)
    if p61 or v19.Listening then
      return
    end

    if p60.KeyCode == v67.ToggleKey then
      f37(not v96)
    end
  end)

  if userInputService.TouchEnabled and not userInputService.KeyboardEnabled then
    local v97 = f4("ImageButton", {
      Image = v1.LogoId,
      BackgroundColor3 = v2.Card,
      BackgroundTransparency = 0,
      Position = UDim2.new(0, 14, 0.5, -23),
      Size = UDim2.fromOffset(46, 46),
      ZIndex = 5,
      Parent = v26,
    })

    f13(v97, 14)
    f7(f15(v97, v2.Accent, 1.5, 0.2), "Color")
    v97.MouseButton1Click:Connect(function() f37(not v96) end)
  end

  function v67:SetBannerVisible(p62)
    showBanner = p62
    f35(true)
  end

  local function f38(text3, p63, layoutOrder)
    local v98 = { Name = text3 }

    local v99 = f4("TextButton", {
      Name = text3,
      BackgroundTransparency = 1,
      Size = UDim2.new(1, 0, 0, 36),
      LayoutOrder = layoutOrder,
      Parent = v89,
    })

    f13(v99, 9)
    f7(v99, "BackgroundColor3")

    local v100 = f4("Frame", {
      AnchorPoint = Vector2.new(0, 0.5),
      Position = UDim2.new(0, 0, 0.5, 0),
      Size = UDim2.fromOffset(3, 0),
      Parent = v99,
    })

    f13(v100, 2)
    f7(v100, "BackgroundColor3")
    local v101 = 14
    local v102

    if p63 then
      v102 = f4("ImageLabel", {
        Image = p63,
        ImageColor3 = v2.SubText,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.new(0, 14, 0.5, 0),
        Size = UDim2.fromOffset(18, 18),
        Parent = v99,
      })

      v101 = 40
    end

    local v103 = f14({
      Text = text3,
      TextColor3 = v2.SubText,
      Position = UDim2.new(0, v101, 0, 0),
      Size = UDim2.new(1, -(v101 + 8), 1, 0),
      Parent = v99,
    })

    local v104 = f4("ScrollingFrame", {
      Name = text3,
      BackgroundTransparency = 1,
      Size = UDim2.fromScale(1, 1),
      CanvasSize = UDim2.new(),
      AutomaticCanvasSize = Enum.AutomaticSize.Y,
      ScrollBarThickness = 3,
      ScrollingDirection = Enum.ScrollingDirection.Y,
      Visible = false,
      Parent = parent12,
    })

    f7(v104, "ScrollBarImageColor3")

    f4("UIListLayout", {
      Padding = UDim.new(0, 8),
      SortOrder = Enum.SortOrder.LayoutOrder,
      Parent = v104,
    })

    f4("UIPadding", {
      PaddingTop = UDim.new(0, 4),
      PaddingBottom = UDim.new(0, 12),
      PaddingRight = UDim.new(0, 8),
      Parent = v104,
    })

    local function f39(p64)
      f10(v99, { BackgroundTransparency = p64 and 0.85 or 1 }, 0.25)
      f10(v100, { Size = UDim2.fromOffset(3, p64 and 18 or 0) }, 0.35, Enum.EasingStyle.Back)
      f10(v103, { TextColor3 = p64 and v2.Text or v2.SubText }, 0.25)

      if v102 then
        f10(v102, { ImageColor3 = p64 and v2.Accent or v2.SubText }, 0.25)
      end
    end

    function v98:Select()
      if v67.CurrentTab == v98 then
        return
      else
        local currentTab = v67.CurrentTab

        if currentTab then
          currentTab._setActive(false)
          currentTab._page.Visible = false
        end

        v67.CurrentTab = v98
        f39(true)
        v92.Text = text3

        v104.Position = UDim2.fromOffset(0, 18)
        v104.Visible = true

        f10(v104, { Position = UDim2.fromOffset(0, 0) }, 0.4)
        return
      end
    end

    v98._setActive = f39
    v98._page = v104

    v99.MouseEnter:Connect(function()
      if v67.CurrentTab ~= v98 then
        f10(v99, { BackgroundTransparency = 0.93 }, 0.2)
      end
    end)

    v99.MouseLeave:Connect(function()
      if v67.CurrentTab ~= v98 then
        f10(v99, { BackgroundTransparency = 1 }, 0.25)
      end
    end)

    local function f40(p65, p66)
      if p65.Flag then
        v27.Flags[p65.Flag] = p66
      end

      return p66
    end

    v99.MouseButton1Click:Connect(function() v98:Select() end)
    local count = 0

    local function f41()
      count = count + 1
      return count
    end

    local function f42(p67)
      local v105 = f4("Frame", {
        BackgroundColor3 = v2.Card,
        Size = UDim2.new(1, 0, 0, p67),
        ClipsDescendants = true,
        LayoutOrder = f41(),
        Parent = v104,
      })

      f13(v105, 10)
      f15(v105, Color3.new(1, 1, 1), 1, 0.9)
      f8(v105, "BackgroundTransparency", 0.22)
      return v105
    end

    local function f43(p68, p69)
      f22(p68, p69, function() return v2.Card end, function() return v2.CardHover end)
    end

    function v98:CreateSection(p70)
      local parent13 = f4("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, 24),
        LayoutOrder = f41(),
        Parent = v104,
      })

      local v106 = f4("Frame", {
        Position = UDim2.new(0, 2, 0.5, -6),
        Size = UDim2.fromOffset(3, 12),
        Parent = parent13,
      })

      f13(v106, 2)
      f7(v106, "BackgroundColor3")

      local v107 = f14({
        Text = string.upper(p70 or "Section"),
        Font = v3.Bold,
        TextSize = 11,
        TextColor3 = v2.SubText,
        Position = UDim2.new(0, 12, 0, 0),
        Size = UDim2.new(1, -12, 1, 0),
        Parent = parent13,
      })

-- https://discord.gg/AwGHNh7Z7T
      return { Set = function(p71, text4) v107.Text = string.upper(text4) end }
    end

    function v98:CreateLabel(p72)
      local v108 = f14({
        Text = p72 or "",
        TextSize = 12,
        TextColor3 = v2.SubText,
        TextWrapped = true,
        TextYAlignment = Enum.TextYAlignment.Top,
        AutomaticSize = Enum.AutomaticSize.Y,
        Size = UDim2.new(1, -8, 0, 0),
        LayoutOrder = f41(),
        Parent = v104,
      })

      f4("UIPadding", { PaddingLeft = UDim.new(0, 4), Parent = v108 })
      return { Set = function(p73, text5) v108.Text = text5 end }
    end

    function v98:CreateButton(p74)
      local v109 = p74
      v109 = v109 or {}

      local v110 = f42(40)

      local v111 = f14({
        Text = v109.Name or "Button",
        Position = UDim2.new(0, 14, 0, 0),
        Size = UDim2.new(1, -60, 1, 0),
        Parent = v110,
      })

      local v112 = f4("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(1, -24, 0.5, 0),
        Size = UDim2.fromOffset(8, 8),
        Rotation = 45,
        Parent = v110,
      })

      f13(v112, 2)
      f7(v112, "BackgroundColor3")
      local v113 = f4("TextButton", { Size = UDim2.fromScale(1, 1), ZIndex = 3, Parent = v110 })
      f43(v113, v110)
      f20(v113, v110, 0.985)

      v113.InputBegan:Connect(function(input3)
        if f23(input3) then
          f24(v110, input3.Position.X, input3.Position.Y)
        end
      end)

      v113.MouseButton1Click:Connect(function()
        v112.Rotation = 45
        f10(v112, { Rotation = 225 }, 0.45)
        f19(v109.Callback)
      end)

      return f40(v109, { SetText = function(p75, text6) v111.Text = text6 end })
    end

    function v98:CreateToggle(p76)
      local v114 = p76
      v114 = v114 or {}

      local v115 = v114.CurrentValue == true
      local v116 = f42(40)

      f14({
        Text = v114.Name or "Toggle",
        Position = UDim2.new(0, 14, 0, 0),
        Size = UDim2.new(1, -80, 1, 0),
        Parent = v116,
      })

      local v117 = f4("Frame", {
        BackgroundColor3 = v2.Off,
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -14, 0.5, 0),
        Size = UDim2.fromOffset(42, 22),
        Parent = v116,
      })

      f13(v117, 11)

      local v118 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.new(0, 3, 0.5, 0),
        Size = UDim2.fromOffset(16, 16),
        Parent = v117,
      })

      f13(v118, 8)
      local v119 = { CurrentValue = v115 }

      local function f44()
        f10(v117, { BackgroundColor3 = v115 and v2.Accent or v2.Off }, 0.25)

        f10(
          v118, { Position = v115 and UDim2.new(1, -19, 0.5, 0) or UDim2.new(0, 3, 0.5, 0) },
          0.35, Enum.EasingStyle.Back
        )
      end

      f6(function(backgroundColor3)
        if v115 then
          v117.BackgroundColor3 = backgroundColor3
        end
      end)

      if v115 then
        v117.BackgroundColor3 = v2.Accent
        v118.Position = UDim2.new(1, -19, 0.5, 0)
      end

      function v119:Set(p77, p78)
        v115 = p77 == true
        v119.CurrentValue = v115
        f44()

        if not p78 then
          f19(v114.Callback, v115)
        end
      end

      local v120 = f4("TextButton", { Size = UDim2.fromScale(1, 1), ZIndex = 3, Parent = v116 })
      f43(v120, v116)

      v120.MouseButton1Down:Connect(function()
        f10(v118, { Size = UDim2.fromOffset(20, 16) }, 0.12)
      end)

      v120.MouseButton1Up:Connect(function()
        f10(v118, { Size = UDim2.fromOffset(16, 16) }, 0.2)
      end)

      v120.MouseLeave:Connect(function() f10(v118, { Size = UDim2.fromOffset(16, 16) }, 0.2) end)
      v120.MouseButton1Click:Connect(function() v119:Set(not v115) end)

      return f40(v114, v119)
    end

    function v98:CreateSlider(p79)
      local v121 = p79
      v121 = v121 or {}

      local range = v121.Range or { 0, 100 }
      local v122 = range[1]
      local v123 = range[2]
      local increment2 = v121.Increment or 1
      local suffix = v121.Suffix or ""
      local v124 = f2(increment2)
      local v125 = math.clamp(v121.CurrentValue or v122, v122, v123)
      local v126 = f42(56)

      f14({
        Text = v121.Name or "Slider",
        Position = UDim2.new(0, 14, 0, 8),
        Size = UDim2.new(1, -120, 0, 18),
        Parent = v126,
      })

      local v127 = f14({
        Text = "",
        TextColor3 = v2.SubText,
        TextXAlignment = Enum.TextXAlignment.Right,
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -14, 0, 8),
        Size = UDim2.fromOffset(100, 18),
        Parent = v126,
      })

      local v128 = f4("Frame", {
        BackgroundColor3 = v2.Off,
        Position = UDim2.new(0, 14, 0, 37),
        Size = UDim2.new(1, -28, 0, 6),
        Parent = v126,
      })

      f13(v128, 3)
      local v129 = f4("Frame", { Size = UDim2.new(0, 0, 1, 0), Parent = v128 })
      f13(v129, 3)
      f7(v129, "BackgroundColor3")

      local v130 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(0, 0, 0.5, 0),
        Size = UDim2.fromOffset(14, 14),
        ZIndex = 2,
        Parent = v128,
      })

      f13(v130, 7)
      f7(f15(v130, v2.Accent, 2, 0), "Color")
      local v131 = { CurrentValue = v125 }

      local function f45(p80)
        return string.format("%." .. v124 .. "f", p80)
      end

      local function f46(p81)
        local v132 = v123 == v122 and 0 or (v125 - v122) / (v123 - v122)
        local v133 = p81 and 0.08 or 0.3

        f10(v129, { Size = UDim2.new(v132, 0, 1, 0) }, v133, Enum.EasingStyle.Quad)
        f10(v130, { Position = UDim2.new(v132, 0, 0.5, 0) }, v133, Enum.EasingStyle.Quad)

        v127.Text = f45(v125) .. suffix
      end

      function v131:Set(p82, p83, p84)
        local v134 = math.clamp(p82, v122, v123)
        local v135 = v122 + math.floor((v134 - v122) / increment2 + 0.5) * increment2
        local v136 = math.clamp(tonumber(f45(v135)), v122, v123)
        local v137 = v136 ~= v125
        v125 = v136
        v131.CurrentValue = v136
        f46(p84)

        if v137 and not p83 then
          f19(v121.Callback, v136)
        end
      end

      f46(false)

      f25(f4("TextButton", {
        Position = UDim2.new(0, 14, 0, 26),
        Size = UDim2.new(1, -28, 0, 28),
        ZIndex = 3,
        Parent = v126,
      }), function(index19) v131:Set(v122 + (v123 - v122) * index19, false, true) end, function()
        f10(v130, { Size = UDim2.fromOffset(19, 19) }, 0.15, Enum.EasingStyle.Back)
      end, function() f10(v130, { Size = UDim2.fromOffset(14, 14) }, 0.2) end)

      v126.MouseEnter:Connect(function() f10(v126, { BackgroundColor3 = v2.CardHover }, 0.2) end)
      v126.MouseLeave:Connect(function() f10(v126, { BackgroundColor3 = v2.Card }, 0.25) end)

      return f40(v121, v131)
    end

    function v98:CreateColorPicker(p85)
      local v138 = p85
      v138 = v138 or {}

      local color2 = v138.Color or Color3.fromRGB(255, 255, 255)
      local v139, v140, v141 = color2:ToHSV()
      local v142 = v140
      local v143 = v141
      local v144 = false
      local v145 = f42(40)

      f14({
        Text = v138.Name or "Color Picker",
        Position = UDim2.new(0, 14, 0, 0),
        Size = UDim2.new(1, -70, 0, 40),
        Parent = v145,
      })

      local v146 = f4("Frame", {
        BackgroundColor3 = color2,
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -14, 0, 10),
        Size = UDim2.fromOffset(34, 20),
        Parent = v145,
      })

      f13(v146, 6)
      f15(v146, Color3.new(1, 1, 1), 1, 0.75)
      local v147 = f4("TextButton", { Size = UDim2.new(1, 0, 0, 40), ZIndex = 3, Parent = v145 })
      f43(v147, v145)

      local v148 = f4("Frame", {
        BackgroundColor3 = Color3.fromHSV(v139, 1, 1),
        Position = UDim2.new(0, 14, 0, 50),
        Size = UDim2.new(1, -66, 0, 112),
        Parent = v145,
      })

      f13(v148, 8)

      local v149 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        Size = UDim2.fromScale(1, 1),
        Parent = v148,
      })

      f13(v149, 8)
      f4("UIGradient", { Transparency = NumberSequence.new(0, 1), Parent = v149 })

      local v150 = f4("Frame", {
        BackgroundColor3 = Color3.new(0, 0, 0),
        Size = UDim2.fromScale(1, 1),
        Parent = v148,
      })

      f13(v150, 8)
      f4("UIGradient", { Rotation = 90, Transparency = NumberSequence.new(1, 0), Parent = v150 })

      local v151 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Size = UDim2.fromOffset(12, 12),
        ZIndex = 3,
        Parent = v148,
      })

      f13(v151, 6)
      f15(v151, Color3.new(0, 0, 0), 1.5, 0.2)

      local v152 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        Position = UDim2.new(1, -40, 0, 50),
        Size = UDim2.fromOffset(26, 112),
        Parent = v145,
      })

      f13(v152, 8)

      f4("UIGradient", {
        Rotation = 90,
        Color = ColorSequence.new({
          ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)),
          ColorSequenceKeypoint.new(0.16666666666667, Color3.fromRGB(255, 255, 0)),
          ColorSequenceKeypoint.new(0.33333333333333, Color3.fromRGB(0, 255, 0)),
          ColorSequenceKeypoint.new(0.5, Color3.fromRGB(0, 255, 255)),
          ColorSequenceKeypoint.new(0.66666666666667, Color3.fromRGB(0, 0, 255)),
          ColorSequenceKeypoint.new(0.83333333333333, Color3.fromRGB(255, 0, 255)),
          ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 0, 0)),
        }),
        Parent = v152,
      })

      local v153 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(0.5, 0, v139, 0),
        Size = UDim2.new(1, 6, 0, 6),
        ZIndex = 3,
        Parent = v152,
      })

      f13(v153, 3)
      f15(v153, Color3.new(0, 0, 0), 1.5, 0.2)

      local v154 = f4("TextBox", {
        Font = v3.Bold,
        TextSize = 12,
        PlaceholderText = "#FFFFFF",
        PlaceholderColor3 = v2.SubText,
        ClearTextOnFocus = false,
        TextXAlignment = Enum.TextXAlignment.Center,
        BackgroundColor3 = v2.Input,
        BackgroundTransparency = 0,
        Position = UDim2.new(0, 14, 0, 174),
        Size = UDim2.fromOffset(100, 28),
        Parent = v145,
      })

      f13(v154, 6)
      local v155 = f15(v154, v2.Stroke, 1, 0)

      local v156 = f14({
        TextSize = 12,
        TextColor3 = v2.SubText,
        Position = UDim2.new(0, 126, 0, 174),
        Size = UDim2.new(1, -140, 0, 28),
        Parent = v145,
      })

      local v157 = { CurrentValue = color2 }

      local function f47(p86)
        color2 = Color3.fromHSV(v139, v142, v143)
        v157.CurrentValue = color2
        v146.BackgroundColor3 = color2
        v148.BackgroundColor3 = Color3.fromHSV(v139, 1, 1)
        v151.Position = UDim2.fromScale(v142, 1 - v143)
        v153.Position = UDim2.new(0.5, 0, v139, 0)
        local v158 = color2
        v154.Text = "#" .. string.upper(v158:ToHex())

        v156.Text = string.format(
          "R %d   G %d   B %d", math.floor(color2.R * 255 + 0.5),
          math.floor(color2.G * 255 + 0.5), math.floor(color2.B * 255 + 0.5)
        )

        if p86 then
          f19(v138.Callback, color2)
        end
      end

      f47(false)

      function v157:Set(p87, p88)
        local v159, v160
        v139, v159, v160 = p87:ToHSV()
        v142 = v159
        v143 = v160
        f47(not p88)
      end

      f25(f4("TextButton", {
        Position = v148.Position,
        Size = v148.Size,
        ZIndex = 4,
        Parent = v145,
      }), function(p89, p90)
        v142 = p89
        v143 = 1 - p90
        f47(true)
      end)

      f25(f4("TextButton", {
        Position = v152.Position,
        Size = v152.Size,
        ZIndex = 4,
        Parent = v145,
      }), function(p91, p92)
        v139 = math.clamp(p92, 0, 0.999)
        f47(true)
      end)

      v154.Focused:Connect(function() f10(v155, { Color = v2.Accent }, 0.2) end)

      v154.FocusLost:Connect(function()
        f10(v155, { Color = v2.Stroke }, 0.2)
        local v161 = string.gsub(v154.Text, "#", "")

        if #v161 == 6 and string.match(v161, "^%x+$") then
          local v162 = tonumber(v161:sub(1, 2), 16)
          local v163 = tonumber(v161:sub(3, 4), 16)
          local v164 = tonumber(v161:sub(5, 6), 16)
          local v165, v166
          v139, v165, v166 = Color3.fromRGB(v162, v163, v164):ToHSV()
          v142 = v165
          v143 = v166
        end

        f47(true)
      end)

      v147.MouseButton1Click:Connect(function()
        v144 = not v144
        f10(v145, { Size = UDim2.new(1, 0, 0, v144 and 214 or 40) }, 0.45)
      end)

      return f40(v138, v157)
    end

    function v98:CreateKeybind(p93)
      local v167 = p93
      v167 = v167 or {}

      local currentKeybind = v167.CurrentKeybind or Enum.KeyCode.E

      if type(currentKeybind) == "string" then
        local v168, v169 = pcall(function() return Enum.KeyCode[currentKeybind] end)
        currentKeybind = v168 and v169 or Enum.KeyCode.E
      end

      local parent14 = f42(40)

      f14({
        Text = v167.Name or "Keybind",
        Position = UDim2.new(0, 14, 0, 0),
        Size = UDim2.new(1, -130, 1, 0),
        Parent = parent14,
      })

      local v170 = f4("TextButton", {
        Text = currentKeybind.Name,
        Font = v3.Bold,
        TextSize = 12,
        TextXAlignment = Enum.TextXAlignment.Center,
        TextTruncate = Enum.TextTruncate.AtEnd,
        BackgroundColor3 = v2.Input,
        BackgroundTransparency = 0,
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -10, 0.5, 0),
        Size = UDim2.fromOffset(100, 26),
        ZIndex = 3,
        Parent = parent14,
      })

      f13(v170, 6)
      local v171 = f15(v170, v2.Stroke, 1, 0)
      f22(v170, v170, function() return v2.Input end, function() return v2.CardHover end)
      f20(v170, v170, 0.94)
      local v172 = { CurrentKeybind = currentKeybind }
      local v173 = false

      function v172:Set(text7, p94)
        currentKeybind = text7
        v172.CurrentKeybind = text7
        v170.Text = text7.Name

        if not p94 then
          f19(v167.OnChange, text7)
        end
      end

      v170.MouseButton1Click:Connect(function()
        v173 = true
        v19.Listening = true
        v170.Text = "..."
        f10(v171, { Color = v2.Accent }, 0.2)
      end)

      f12(userInputService.InputBegan, function(p95, p96)
        if v173 then
          if p95.UserInputType == Enum.UserInputType.Keyboard then
            v173 = false
            f10(v171, { Color = v2.Stroke }, 0.2)

            if p95.KeyCode == Enum.KeyCode.Escape then
              v170.Text = currentKeybind.Name
            else
              v172:Set(p95.KeyCode)
            end

            task.delay(0.15, function() v19.Listening = false end)
          end

          return
        end

        if not p96 and not v19.Listening and p95.KeyCode == currentKeybind then
          f19(v167.Callback, currentKeybind)
        end
      end)

      return f40(v167, v172)
    end

    function v98:CreateDivider()
      local v174 = f4("Frame", {
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, 14),
        LayoutOrder = f41(),
        Parent = v104,
      })

      local parent15 = f4("Frame", {
        BackgroundColor3 = Color3.new(1, 1, 1),
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.new(1, -8, 0, 1),
        Parent = v174,
      })

      f4("UIGradient", {
        Transparency = NumberSequence.new({
          NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.8),
          NumberSequenceKeypoint.new(1, 1),
        }),
        Parent = parent15,
      })

      local v175 = f4("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromOffset(46, 2),
        Parent = v174,
      })

      f13(v175, 1)
      f7(v175, "BackgroundColor3")

      f4("UIGradient", {
        Transparency = NumberSequence.new({
          NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.15),
          NumberSequenceKeypoint.new(1, 1),
        }),
        Parent = v175,
      })

      return { Destroy = function() v174:Destroy() end }
    end

    function v98.CreateTextBox(p97, p98)
      local v176 = p98
      v176 = v176 or {}

      local v177 = v176.NumbersOnly == true
      local v178 = f42(46)

      f14({
        Text = v176.Name or "TextBox",
        Position = UDim2.new(0, 14, 0, 0),
        Size = UDim2.new(1, -200, 1, 0),
        Parent = v178,
      })

      local v179 = f4("ImageLabel", {
        Image = "rbxassetid://6014261993",
        ScaleType = Enum.ScaleType.Slice,
        SliceCenter = Rect.new(49, 49, 450, 450),
        SliceScale = 0.4,
        ImageTransparency = 1,
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -4, 0.5, 0),
        Size = UDim2.fromOffset(186, 46),
        ZIndex = 1,
        Parent = v178,
      })

      f7(v179, "ImageColor3")

      local v180 = f4("Frame", {
        BackgroundColor3 = v2.Input,
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -12, 0.5, 0),
        Size = UDim2.fromOffset(170, 30),
        ZIndex = 2,
        Parent = v178,
      })

      f13(v180, 8)
      local v181 = f15(v180, v2.Stroke, 1, 0)

      local v182 = f4("TextBox", {
        Text = v176.CurrentValue ~= nil and tostring(v176.CurrentValue) or "",
        PlaceholderText = v176.PlaceholderText or v177 and "0" or "Type here...",
        PlaceholderColor3 = v2.SubText,
        ClearTextOnFocus = false,
        TextSize = 12,
        TextTruncate = Enum.TextTruncate.AtEnd,
        Position = UDim2.new(0, 10, 0, 0),
        Size = UDim2.new(1, -20, 1, 0),
        ZIndex = 3,
        Parent = v180,
      })

      local v183 = { CurrentValue = v177 and tonumber(v182.Text) or v182.Text }
      local text8 = v182.Text
      local v184 = false

      if v177 then
        v182:GetPropertyChangedSignal("Text"):Connect(function()
          if v184 then
            return
          else
            local v185 = string.gsub(v182.Text, "[^%d%.%-]", "")

            if v185 ~= v182.Text then
              v182.Text = v185
              v184 = false
            end

            return
          end
        end)
      end

      v182.Focused:Connect(function()
        f10(v181, { Color = v2.Accent, Thickness = 1.6 }, 0.25)
        f10(v179, { ImageTransparency = 0.5 }, 0.3)
      end)

      v182.FocusLost:Connect(function(p99)
        f10(v181, { Color = v2.Stroke, Thickness = 1 }, 0.3)
        f10(v179, { ImageTransparency = 1 }, 0.35)

        local text9 = v182.Text

        if v177 then
          text9 = tonumber(v182.Text)

          if text9 == nil then
            v182.Text = text8
            return
          end

          if v176.Min then
            text9 = math.max(text9, v176.Min)
          end

          if v176.Max then
            text9 = math.min(text9, v176.Max)
          end

          v182.Text = tostring(text9)
          text8 = v182.Text
          v183.CurrentValue = text9
          f19(v176.Callback, text9, p99)

          if v176.RemoveTextAfterFocusLost then
            v182.Text = ""
          end

          return
        end

        text8 = v182.Text
        v183.CurrentValue = text9
        f19(v176.Callback, text9, p99)

        if v176.RemoveTextAfterFocusLost then
          v182.Text = ""
        end
      end)

      function v183:Set(text10, p100)
        v182.Text = tostring(text10)
        text8 = v182.Text
        v183.CurrentValue = v177 and tonumber(text10) or v182.Text

        if not p100 then
          f19(v176.Callback, v183.CurrentValue, false)
        end
      end

      local v186 = f4("TextButton", {
        Size = UDim2.new(1, -190, 1, 0),
        ZIndex = 3,
        Parent = v178,
      })

      f43(v186, v178)
      v186.MouseButton1Click:Connect(function() v182:CaptureFocus() end)
      return f40(v176, v183)
    end

    function v98.CreateDropdown(p101, p102)
      local v187 = p102
      v187 = v187 or {}

      local options = v187.Options or {}
      local v188 = false
      local v189 = {}
      local v190 = f42(42)

      f14({
        Text = v187.Name or "Dropdown",
        Position = UDim2.new(0, 14, 0, 0),
        Size = UDim2.new(1, -200, 0, 42),
        Parent = v190,
      })

      local v191 = f14({
        Text = "Select...",
        TextColor3 = v2.SubText,
        TextXAlignment = Enum.TextXAlignment.Right,
        TextTruncate = Enum.TextTruncate.AtEnd,
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -40, 0, 0),
        Size = UDim2.fromOffset(160, 42),
        Parent = v190,
      })

      local v192 = f4("Frame", {
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(1, -22, 0, 21),
        Size = UDim2.fromOffset(16, 16),
        Parent = v190,
      })

      local v193 = {}

      for index20, value16 in ipairs({ { 5, 45 }, { 11, -45 } }) do
        local v194 = f4("Frame", {
          BackgroundColor3 = v2.SubText,
          AnchorPoint = Vector2.new(0.5, 0.5),
          Position = UDim2.fromOffset(value16[1], 8),
          Size = UDim2.fromOffset(9, 2),
          Rotation = value16[2],
          Parent = v192,
        })

        f13(v194, 1)
        table.insert(v193, v194)
      end

      local v195 = f4("TextButton", { Size = UDim2.new(1, 0, 0, 42), ZIndex = 3, Parent = v190 })
      f43(v195, v190)

      local v196 = f4("ScrollingFrame", {
        BackgroundColor3 = v2.Input,
        BackgroundTransparency = 0.15,
        Position = UDim2.new(0, 8, 0, 44),
        Size = UDim2.new(1, -16, 0, 0),
        CanvasSize = UDim2.new(),
        AutomaticCanvasSize = Enum.AutomaticSize.Y,
        ScrollBarThickness = 2,
        ScrollingDirection = Enum.ScrollingDirection.Y,
        Parent = v190,
      })

      f13(v196, 8)
      f7(v196, "ScrollBarImageColor3")

      f4("UIListLayout", {
        Padding = UDim.new(0, 3),
        SortOrder = Enum.SortOrder.LayoutOrder,
        Parent = v196,
      })

      f4("UIPadding", {
        PaddingTop = UDim.new(0, 4),
        PaddingBottom = UDim.new(0, 4),
        PaddingLeft = UDim.new(0, 4),
        PaddingRight = UDim.new(0, 6),
        Parent = v196,
      })

      local v197 = { Options = options }

      v197.CurrentOption = type(v187.CurrentOption) == "table" and v187.CurrentOption[1]
        or v187.CurrentOption

      local function f48()
        return math.min(#options * 33 - 3 + 8, 160)
      end

      local function f49()
        v191.Text = v197.CurrentOption ~= nil and tostring(v197.CurrentOption) or "Select..."

        for index21, value17 in ipairs(v189) do
          local v198 = value17.opt == v197.CurrentOption

          f10(value17.btn, { BackgroundTransparency = v198 and 0.8 or 1 }, 0.2)
          f10(value17.lbl, { TextColor3 = v198 and v2.Text or v2.SubText }, 0.2)

          f10(
            value17.mark, { Size = UDim2.fromOffset(3, v198 and 14 or 0) }, 0.3,
            Enum.EasingStyle.Back
          )
        end
      end

      local function f50(p103)
        v188 = p103
        local v199 = p103 and 44 + f48() + 8 or 42

        f10(v190, { Size = UDim2.new(1, 0, 0, v199) }, 0.45)
        f10(v196, { Size = UDim2.new(1, -16, 0, p103 and f48() or 0) }, 0.45)
        f10(v192, { Rotation = p103 and 180 or 0 }, 0.4)

        for index22, value18 in ipairs(v193) do
          f10(value18, { BackgroundColor3 = p103 and v2.Accent or v2.SubText }, 0.3)
        end
      end

      local function f51()
        for index23, value19 in ipairs(v189) do
        end

        table.clear(v189)

        for index24, value20 in ipairs(options) do
          local v200 = value20

          local v201 = f4("TextButton", {
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0, 30),
            LayoutOrder = index24,
            Parent = v196,
          })

          f13(v201, 7)
          f7(v201, "BackgroundColor3")

          local v202 = f4("Frame", {
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0, 3, 0.5, 0),
            Size = UDim2.fromOffset(3, 0),
            Parent = v201,
          })

          f13(v202, 2)
          f7(v202, "BackgroundColor3")
          local text11 = tostring(v200)
          local udim5 = UDim2.new(0, 16, 0, 0)
          local udim6 = UDim2.new(1, -24, 1, 0)

          local lbl = f14({
            Text = text11,
            TextColor3 = v2.SubText,
            TextTruncate = Enum.TextTruncate.AtEnd,
            Position = udim5,
            Size = udim6,
            Parent = v201,
          })

          v201.MouseEnter:Connect(function()
            if v200 ~= v197.CurrentOption then
              f10(v201, { BackgroundTransparency = 0.92 }, 0.15)
            end
          end)

          v201.MouseLeave:Connect(function()
            if v200 ~= v197.CurrentOption then
              f10(v201, { BackgroundTransparency = 1 }, 0.2)
            end
          end)

          v201.MouseButton1Click:Connect(function()
            v197:Set(v200)
            f50(false)
          end)

          table.insert(v189, {
            opt = v200,
            btn = v201,
            lbl = lbl,
            mark = v202,
          })
        end

        f49()
      end

      function v197:Set(p104, p105)
        v197.CurrentOption = p104
        f49()

        if not p105 then
          f19(v187.Callback, p104)
        end
      end

      function v197.Refresh(p106, p107)
        options = p107 or {}
        v197.Options = options
        local v203 = false

        for index25, value21 in ipairs(options) do
          if value21 == v197.CurrentOption then
            v203 = true
          end
        end

        if not v203 then
          v197.CurrentOption = nil
        end

        f51()

        if v188 then
          f50(true)
        end
      end

      f51()
      v195.MouseButton1Click:Connect(function() f50(not v188) end)

      f12(userInputService.InputBegan, function(p108)
        if v188 and f23(p108) then
          local absoluteSize2 = v190.AbsoluteSize
          local position5 = p108.Position
          local absolutePosition2 = v190.AbsolutePosition

          if position5.X < absolutePosition2.X
            or position5.X > absolutePosition2.X + absoluteSize2.X
            or position5.Y < absolutePosition2.Y
            or position5.Y > absolutePosition2.Y + absoluteSize2.Y then
            f50(false)
          end
        end
      end)

      return f40(v187, v197)
    end

    return v98
  end

  local count2 = 0

  function v67:CreateTab(p109, p110)
    count2 = count2 + 1
    local v204 = f38(p109 or "Tab " .. count2, p110, count2)
    v67.LastTab = v204

    if not v67.CurrentTab then
      v204:Select()
    end

    return v204
  end

  for index26, value22 in ipairs({
    "CreateSection", "CreateLabel", "CreateButton", "CreateToggle", "CreateSlider",
    "CreateColorPicker", "CreateKeybind",
  }) do
    local v205 = value22

    v67[v205] = function(p111, ...)
      local lastTab = p111.LastTab or p111:CreateTab("Main")
      return lastTab[v205](lastTab, ...)
    end
  end

  local v206 = f38("Settings", nil, 1000)
  v67.SettingsTab = v206

  v206:CreateSection("Appearance")

  v206:CreateColorPicker({
    Name = "Theme Color",
    Color = v2.Accent,
    Callback = function(value23) f5(value23) end,
  })

  v206:CreateSlider({
    Name = "Background Transparency",
    Range = { 0, 80 },
    Increment = 1,
    Suffix = "%",
    CurrentValue = 0,
    Callback = function(value24) f11(value24 / 100) end,
  })

  v206:CreateToggle({
    Name = "Show Banner Background",
    CurrentValue = v1.ShowBanner,
    Callback = function(value25) v67:SetBannerVisible(value25) end,
  })

  v206:CreateDivider()
  v206:CreateSection("Controls")

  v206:CreateKeybind({
    Name = "Toggle GUI Keybind",
    CurrentKeybind = v67.ToggleKey,
    OnChange = function(value26)
      v67.ToggleKey = value26

      v27:Notify({
        Title = "Keybind updated",
        Content = "Press " .. value26.Name .. " to open or close the GUI.",
        Type = "Success",
        Duration = 3,
      })
    end,
  })

  v206:CreateDivider()
  v206:CreateSection("Interface")
  v206:CreateButton({ Name = "Unload " .. name, Callback = function() v27:Destroy() end })
  v206:CreateLabel(name .. " - built with VelocityHUB UI Library v1.0.0")

  f10(v73, { Scale = v70 }, 0.65, Enum.EasingStyle.Back)

  task.delay(0.25, function() f35(true) end)

  task.defer(function()
    if not v67.CurrentTab then
      v206:Select()
    end
  end)

  return v67
end

local localPlayer = players.LocalPlayer

local function f52(position6, deliveryLocationEffects)
  local v207, v208 = deliveryLocationEffects:GetBoundingBox()
  local position7 = v207.Position
  local vector2 = Vector3.new(position7.X - position6.X, 0, position7.Z - position6.Z)
  local vector3

  if vector2.Magnitude < 0.1 then
    vector3 = Vector3.new(1, 0, 0)
  else
    vector3 = vector2.Unit
  end

  local v209 = position7 - vector3 * (math.max(v208.X, v208.Z) / 2 + 10)
  return Vector3.new(v209.X, position7.Y + 10, v209.Z), position7
end

local velocityHUBWindow = v27:CreateWindow({
  Name = "VelocityHUB",
  ToggleKey = Enum.KeyCode.RightControl,
})

local deliveryTab = velocityHUBWindow:CreateTab("Delivery")
local v210 = false
local v211 = "Baslat"
local count3 = 0
local create2

local function f53()
  if create2 then
    create2:Cancel()
    create2 = nil
  end

  local character = localPlayer.Character
  local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")

  if humanoidRootPart then
    humanoidRootPart.Anchored = false
    humanoidRootPart.Velocity = Vector3.zero
  end
end

local function f54(p112, p113)
  local character2 = localPlayer.Character
  local humanoidRootPart2 = character2 and character2:FindFirstChild("HumanoidRootPart")

  if not humanoidRootPart2 then
    return
  else
    local magnitude = (humanoidRootPart2.Position - p112).Magnitude

    if magnitude < 1 then
      return
    else
      local v212 = magnitude / p113

      if v212 < 0.05 then
        v212 = 0.05
      end

      humanoidRootPart2.Anchored = true

      create2 = tweenService:Create(
        humanoidRootPart2, TweenInfo.new(v212, Enum.EasingStyle.Linear),
        { CFrame = CFrame.new(p112) }
      )

      create2:Play()
      create2.Completed:Wait()

      humanoidRootPart2.Velocity = Vector3.zero
      return
    end
  end
end

local velocityDeliveryPlatform = nil

local function makePart(index27, vector4)
  if velocityDeliveryPlatform then
    velocityDeliveryPlatform:Destroy()
    velocityDeliveryPlatform = nil
  end

  local vector32 = Vector3
  local v213 = (index27 + vector4) / 2

  local magnitude2 = (vector32.new(index27.X, 0, index27.Z)
    - Vector3.new(vector4.X, 0, vector4.Z)).Magnitude

  velocityDeliveryPlatform = Instance.new("Part")
  velocityDeliveryPlatform.Name = "VelocityDeliveryPlatform"

  local v214 = magnitude2 + 60

  velocityDeliveryPlatform.Size = Vector3.new(v214, 1, v214)
  velocityDeliveryPlatform.Position = Vector3.new(v213.X, vector4.Y - 3, v213.Z)
  velocityDeliveryPlatform.Anchored = true
  velocityDeliveryPlatform.CanCollide = true
  velocityDeliveryPlatform.Transparency = 0.5
  velocityDeliveryPlatform.BrickColor = BrickColor.new("Cyan")
  velocityDeliveryPlatform.Material = Enum.Material.Neon
  velocityDeliveryPlatform.Parent = workspace
end

local function f55(position8, vector5, index28)
  local vector6 = Vector3.new(position8.X - vector5.X, 0, position8.Z - vector5.Z)
  local vector7

  if vector6.Magnitude < 0.1 then
    vector7 = Vector3.new(index28, 0, 0)
  else
    vector7 = vector6.Unit * index28
  end

  return Vector3.new(vector5.X + vector7.X, vector5.Y + 10, vector5.Z + vector7.Z)
end

local function f56(vector8, p114)
  local character3 = localPlayer.Character
  local humanoidRootPart3 = character3 and character3:FindFirstChild("HumanoidRootPart")
  local humanoid = character3 and character3:FindFirstChildOfClass("Humanoid")

  if not humanoidRootPart3 or not humanoid then
    return
  else
    humanoid:MoveTo(vector8)
    local count4 = 0

    while count4 < 50 do
      if count3 ~= p114 or not v210 then
        break
      end

      if Vector2.new(
        humanoidRootPart3.Position.X - vector8.X,
        humanoidRootPart3.Position.Z - vector8.Z
      ).Magnitude < 4 then
        break
      end

      task.wait(0.1)
      count4 = count4 + 1
    end

    return
  end
end

deliveryTab:CreateSection("Delivery Farm")
local v215

deliveryTab:CreateToggle({
  Name = "Auto Delivery",
  CurrentValue = false,
  Callback = function(value27)
    v210 = value27
    count3 = count3 + 1
    local v216 = count3

    if value27 then
      local map = workspace:FindFirstChild("Map")

      if map then
        v215 = map
        v215.Parent = nil
        print("[Auto Delivery Log] Harita (Map) tamamen gizlendi.")
      end

      v211 = "Baslat"

      task.spawn(function()
        while v210 and count3 == v216 do
          local character4 = localPlayer.Character
          local humanoidRootPart4 = character4 and character4:FindFirstChild("HumanoidRootPart")

          if not humanoidRootPart4 then
            task.wait(1)
          elseif v211 == "Baslat" then
            print("[Auto Delivery Log] Görev noktasına yaklaşılıyor...")
            local vector9 = Vector3.new(94, 17, -1753)
            local v217 = f55(humanoidRootPart4.Position, vector9, 10)
            f54(v217, 2000)

            if count3 ~= v216 then
              break
            end

            makePart(v217, vector9)
            f53()
            task.wait(0.4)
            f56(vector9, v216)

            if count3 ~= v216 then
              break
            else
              virtualInputManager:SendKeyEvent(true, Enum.KeyCode.E, false, game)
              task.wait(0.1)
              virtualInputManager:SendKeyEvent(false, Enum.KeyCode.E, false, game)
              task.wait(1.5)

              if count3 ~= v216 then
                break
              end

              local playerGui = localPlayer:FindFirstChild("PlayerGui")

              if playerGui then
                local waitForChild = playerGui:WaitForChild("PromptUI", 3)

                if waitForChild then
                  local waitForChild2 = waitForChild:WaitForChild("PromptV2", 3)

                  if waitForChild2 then
                    local waitForChild3 = waitForChild2:WaitForChild("ButtonsFrame", 3)

                    if waitForChild3 then
                      local waitForChild4 = waitForChild3:WaitForChild("HighRiskDelivery", 3)

                      if waitForChild4 then
                        pcall(function()
                          for key3, value28 in pairs(getconnections(waitForChild4.MouseButton1Click)) do
                            value28:Fire()
                          end

                          for key4, value29 in pairs(getconnections(waitForChild4.Activated)) do
                            value29:Fire()
                          end

                          for key5, value30 in pairs(getconnections(waitForChild4.MouseButton1Down)) do
                            value30:Fire()
                          end
                        end)

                        local absolutePosition3 = waitForChild4.AbsolutePosition
                        local absoluteSize3 = waitForChild4.AbsoluteSize
                        local getGuiInset2 = guiService:GetGuiInset()
                        local v218 = absolutePosition3.X + absoluteSize3.X / 2
                        local v219 = absolutePosition3.Y + absoluteSize3.Y / 2 + getGuiInset2.Y
                        virtualInputManager:SendMouseButtonEvent(v218, v219, 0, true, game, 1)
                        task.wait(0.1)
                        virtualInputManager:SendMouseButtonEvent(v218, v219, 0, false, game, 1)
                      end
                    end
                  end
                end
              end

              task.wait(1.5)
              v211 = "Toplayan"
            end
          elseif v211 == "Toplayan" or v211 == "Veren" then
            print("[Auto Delivery Log] Tag Aktif: " .. v211)
            local deliveryLocationEffects2 = workspace:FindFirstChild("DeliveryLocationEffects")

            if not deliveryLocationEffects2 then
              local findFirstChild = workspace:FindFirstChild("DeliveryTargetAnchor", true)

              if findFirstChild then
                f54(findFirstChild.Position + Vector3.new(0, 15, 0), 2000)

                if count3 ~= v216 then
                  break
                end

                local count5 = 0

                while not workspace:FindFirstChild("DeliveryLocationEffects") and count5 < 50 do
                  task.wait(0.1)
                  count5 = count5 + 1
                end

                deliveryLocationEffects2 = workspace:FindFirstChild("DeliveryLocationEffects")
              end
            end

            if deliveryLocationEffects2 then
              local v220, v221 = f52(humanoidRootPart4.Position, deliveryLocationEffects2)
              f54(v220, 2000)

              if count3 ~= v216 then
                break
              end

              makePart(v220, v221)
              f53()
              task.wait(0.4)
              f56(v221, v216)

              if count3 ~= v216 then
                break
              elseif v211 == "Toplayan" then
                task.wait(6)
                v211 = "Veren"
              else
                task.wait(0.3)
                v211 = "Toplayan"
              end
            else
              task.wait(1)
            end
          end
        end
      end)
    else
      f53()

      if velocityDeliveryPlatform then
        velocityDeliveryPlatform:Destroy()
        velocityDeliveryPlatform = nil
      end

      if v215 then
        v215.Parent = workspace
        v215 = nil
        print("[Auto Delivery Log] Harita (Map) geri yüklendi.")
      end
    end
  end,
})

local funTab = velocityHUBWindow:CreateTab("Fun")
funTab:CreateSection("Fun")

local function f57()
  local character5 = localPlayer.Character

  if character5 and character5:FindFirstChild("Humanoid") and character5.Humanoid.SeatPart then
    return character5.Humanoid.SeatPart:FindFirstAncestorOfClass("Model")
  end

  return nil
end

local vehicleFLY = 15
local connect4

funTab:CreateToggle({
  Name = "Vehicle FLY",
  CurrentValue = false,
  Callback = function(value31)
    if value31 then
      connect4 = runService.RenderStepped:Connect(function()
        local v222 = f57()

        if v222 then
          local primaryPart = v222.PrimaryPart or v222:FindFirstChildWhichIsA("BasePart")

          if primaryPart then
            local vFlyBV = primaryPart:FindFirstChild("vFlyBV")
            local vFlyBG = primaryPart:FindFirstChild("vFlyBG")

            if not vFlyBV then
              vFlyBV = Instance.new("BodyVelocity")
              vFlyBV.Name = "vFlyBV"
              vFlyBV.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
              vFlyBV.Parent = primaryPart
            end

            if not vFlyBG then
              vFlyBG = Instance.new("BodyGyro")
              vFlyBG.Name = "vFlyBG"
              vFlyBG.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
              vFlyBG.Parent = primaryPart
            end

            local currentCamera2 = workspace.CurrentCamera
            local vector10 = Vector3.new(0, 0, 0)

            if userInputService:IsKeyDown(Enum.KeyCode.W) then
              vector10 = vector10 + currentCamera2.CFrame.LookVector
            end

            if userInputService:IsKeyDown(Enum.KeyCode.S) then
              vector10 = vector10 - currentCamera2.CFrame.LookVector
            end

            if userInputService:IsKeyDown(Enum.KeyCode.A) then
              vector10 = vector10 - currentCamera2.CFrame.RightVector
            end

            if userInputService:IsKeyDown(Enum.KeyCode.D) then
              vector10 = vector10 + currentCamera2.CFrame.RightVector
            end

            if userInputService:IsKeyDown(Enum.KeyCode.Space) then
              vector10 = vector10 + Vector3.new(0, 1, 0)
            end

            if userInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
              vector10 = vector10 - Vector3.new(0, 1, 0)
            end

            vFlyBV.Velocity = vector10 * (vehicleFLY * 10)
            vFlyBG.CFrame = currentCamera2.CFrame
          end
        end
      end)
    else
      if connect4 then
        connect4:Disconnect()
        connect4 = nil
      end

      local v223 = f57()

      if v223 then
        local primaryPart2 = v223.PrimaryPart

        local basePart = primaryPart2
        basePart = primaryPart2 or v223:FindFirstChildWhichIsA("BasePart")

        if basePart then
          if basePart:FindFirstChild("vFlyBV") then
            basePart.vFlyBV:Destroy()
          end

          if basePart:FindFirstChild("vFlyBG") then
            basePart.vFlyBG:Destroy()
          end
        end
      end
    end
  end,
})

funTab:CreateSlider({
  Name = "Vehicle FLY",
  Range = { 1, 30 },
  Increment = 1,
  Suffix = " hz",
  CurrentValue = 15,
  Callback = function(value32) vehicleFLY = value32 end,
})

local connect5

funTab:CreateToggle({
  Name = "Vehicle NoClip",
  CurrentValue = false,
  Callback = function(value33)
    if value33 then
      connect5 = runService.Stepped:Connect(function()
        local character6 = localPlayer.Character

        if character6 then
          for index29, value34 in ipairs(character6:GetDescendants()) do
            if value34:IsA("BasePart") then
              value34.CanCollide = false
            end
          end
        end

        local v224 = f57()

        if v224 then
          for index30, value35 in ipairs(v224:GetDescendants()) do
            if value35:IsA("BasePart") then
              value35.CanCollide = false
            end
          end
        end
      end)
    elseif connect5 then
      connect5:Disconnect()
      connect5 = nil
    end
  end,
})

local v225 = 100
local connect6

funTab:CreateToggle({
  Name = "Vehicle Speed",
  CurrentValue = false,
  Callback = function(value36)
    if value36 then
      connect6 = runService.Heartbeat:Connect(function()
        local v226 = f57()

        if v226 and userInputService:IsKeyDown(Enum.KeyCode.W) then
          local primaryPart3 = v226.PrimaryPart or v226:FindFirstChildWhichIsA("BasePart")

          if primaryPart3 then
            primaryPart3.Velocity = Vector3.new(
              primaryPart3.CFrame.LookVector.X * v225, primaryPart3.Velocity.Y,
              primaryPart3.CFrame.LookVector.Z * v225
            )
          end
        end
      end)
    elseif connect6 then
      connect6:Disconnect()
      connect6 = nil
    end
  end,
})

funTab:CreateSlider({
  Name = "Vehicle Speed Limit",
  Range = { 50, 500 },
  Increment = 10,
  Suffix = " spd",
  CurrentValue = 100,
  Callback = function(value37) v225 = value37 end,
})

local spinSpeed = 50
local connect7

funTab:CreateToggle({
  Name = "Spin (Drift)",
  CurrentValue = false,
  Callback = function(value38)
    if value38 then
      connect7 = runService.Heartbeat:Connect(function()
        local v227 = f57()

        if v227 then
          local primaryPart4 = v227.PrimaryPart or v227:FindFirstChildWhichIsA("BasePart")

          if primaryPart4 then
            local spinBAV = primaryPart4:FindFirstChild("SpinBAV")

            if not spinBAV then
              spinBAV = Instance.new("BodyAngularVelocity")
              spinBAV.Name = "SpinBAV"
              spinBAV.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
              spinBAV.Parent = primaryPart4
            end

            spinBAV.AngularVelocity = Vector3.new(0, spinSpeed, 0)
          end
        end
      end)
    else
      if connect7 then
        connect7:Disconnect()
        connect7 = nil
      end

      local v228 = f57()

      if v228 then
        local primaryPart5 = v228.PrimaryPart

        local basePart2 = primaryPart5
        basePart2 = primaryPart5 or v228:FindFirstChildWhichIsA("BasePart")

        if basePart2 and basePart2:FindFirstChild("SpinBAV") then
          basePart2.SpinBAV:Destroy()
        end
      end
    end
  end,
})

funTab:CreateSlider({
  Name = "Spin Speed",
  Range = { 10, 200 },
  Increment = 5,
  Suffix = " rot",
  CurrentValue = 50,
  Callback = function(value39) spinSpeed = value39 end,
})